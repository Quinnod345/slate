---
name: "slate-qa"
description: "Check a Slate film and decide what's truly done. Covers every gate (script, voice, timing, hand-in, sound and the film gates from schema and frame counts to glitch, act joins, motion, accessibility and master-against-render PSNR), the five gate states where only PASS counts and unchecked is never passed, triaging failures and glitch flags, a person accepting a REVIEW item, the review checklist and review packets, the separate reviewer agent that grades an autonomous film before it's held, and ponder as an optional QA loop over every shot. Use when running or reading Slate's gates, deciding whether a shot, act, stage or film is done, triaging a failure, reviewing a cut, or grading an autonomous film."
---

> Knowledge-only edition of Slate's `slate-qa` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-qa

Gates, not vibes. Every step with a measurable result is gated by a machine; the look, the hero moments and the final
cut are judged by people; and nothing unchecked is ever reported as passed. "Done" means verified, with the evidence
named.

## 1. The five states

| State | Meaning | Counts as passed? |
|---|---|---|
| **PASS** | checked, and it holds | yes, the only one |
| **FAIL** | checked, and it doesn't | no |
| **REVIEW** | a person has to judge it (a glitch flag, a generated take) | no, until a person accepts it |
| **UNCHECKED** | couldn't run (a tool missing, an input not made yet); its evidence says what to do | no, never |
| **STALE** | an input changed since it was checked | no, until it runs again |

Every result names the engine and version it used (the OCR engine and level, the Whisper model, the ffmpeg build) and
the hashes of what it read, so it turns STALE the moment an input changes. `qa/gates.json` holds the latest result per
gate. See [done means verified](#reference-done-means-verified).

## 2. Running the gates

```
slate qa                      # every film gate, in film order (writes qa/gates.json)
slate qa --quick              # skip the gates that read the whole picture (ocr, readtime, glitch, psnr); it says
                              # which it skipped, and motion, access and stability reuse what a full run read
slate qa loudness sync        # just these gates; a module's name (motion) selects all of its gates
slate qa motion --act 2       # the motion and access gates take their own flags (--act, --render, --only, ...)
slate qa stability baseline --act 3 --by <name> --reason "<why>"   # accept an act's open stability flags
slate qa --list               # the gates, where each comes from, and each one's latest status
slate qa --detach             # queue a full run as a job (it holds the render slot)
```

A narrowed run (`--act`, `--only`, one render) reports what it finds but can't pass the gate.

Exit 0 only when every result is PASS. Each stage has its own gates too, run by its own command (the script build,
the voice checks, the timing build, the hand-in check, `slate verify` for sound). Every gate, what it checks and how to
fix it: [gates](#reference-the-gates).

## 3. Triage

```
slate qa triage               # everything that isn't PASS, most severe first, with the next step for each
```

FAIL first, then STALE, UNCHECKED and REVIEW. Glitch flags within 3 frames of a planned beat are skipped (a smooth fast
move isn't a glitch); the rest are real until a person says otherwise. When a person accepts a REVIEW item:

```
slate qa triage --accept glitch:frame:1166 --by <their name> --reason "<why it's acceptable>"
```

The acceptance is bound to the hashes of the files it was judged on: re-render, and it no longer applies. An agent can't
accept a REVIEW item on an autonomous film. See [triage](#reference-triage).

## 4. People review what machines can't

After the automated checks, look at the contact sheets and the strips yourself: pops, jumps, twisting, overshoot or
bounce; aliasing, clipping, legibility; hand-offs across shot and act joins; interpolation on generated plates; the
brand's look; sync with the voice. Record each shot's status as **pass**, **fixed → pass**, **fail** or **pending**, and
log every defect with measured evidence (a 17.8 px jump at frame 1166; a join jump of 1.36 against 0.13) and its fix.
See [human review](#reference-human-review) and the [review checklist](#reference-the-review-checklist).

Packets carry what the owner reviews: the phone cut, contact sheets, gesture sheets, what changed. See
[review packets](#reference-review-packets).

## 5. Autonomous films: park, don't pass

- A REVIEW verdict on an autonomous film **parks** it with its evidence; it never counts as a pass. Only a person releases
  it (`slate qa unpark --by <name>`).
- **Before a film parks for the owner, a separate reviewer grades it**: the contact sheet and the audio, against the
  brand's references, the owner's taste notes and the visionary bar. If you can run sub-agents, the reviewer is a
  sub-agent given only the packet and the references; otherwise it's a fresh agent session started for the review.
  Never the agent that built the film. See [reviewer agent](#reference-the-reviewer-agent-grading-an-autonomous-film-before-its-held).
- Claims off the brand's approved list park the film with a question.

## 6. Ponder: a QA loop over every shot (optional)

When a single review pass would miss things (a long film, many shots, a fidelity sweep), and the ponder skill is
available, run it as a converging loop: enumerate every shot as a unit, grade each against the review checklist, revise
the grades pass by pass until they stop changing, and never stop while a shot is ungraded. It sharpens review; it never
replaces the gates.

## 7. Before saying anything is done

- Every gate that covers it is PASS, fresh, with its evidence.
- A person has judged what only a person can judge (the look, the voice, the sound, hero moments, the final cut).
- Re-read the requester's original words in GOAL.md and check each ask against what was delivered.
- Never claim every frame is good unless every frame in the range was processed or inspected.

## References

- [gates](#reference-the-gates): every gate by stage, what it reads, how to fix it, trusting a metric.
- [triage](#reference-triage): ordering, glitch flags and their false positives, accepting REVIEW items.
- [done-means-verified](#reference-done-means-verified): what counts as done, and what never does.
- [human-review](#reference-human-review): shot statuses, the defect log, contact sheets.
- [review-checklist](#reference-the-review-checklist): what to look for, shot by shot and film-wide.
- [review-packets](#reference-review-packets): what the owner sees, and how to read it.
- [reviewer-agent](#reference-the-reviewer-agent-grading-an-autonomous-film-before-its-held): grading an autonomous film before it's held.

---

## Reference: Done means verified

The failure this prevents: reporting a shot, a stage or a film as done because it was made, because a proof looked
right, or because a check didn't complain. On the first films the rule became simple: a thing is done when every check
that covers it holds, with its evidence named, and a person has judged what only a person can judge.

### What counts

- **A shot passes only when every check holds.** A failure is fixed, re-rendered and rechecked before a pass is recorded.
- **An act is done** only when it's built, handed in (`slate check` passing), and reviewed on stills, full-rate frame
  sequences and a preview of the final code, with a 0.5-second contact sheet and a flicker scan.
- **A film is done** when every film gate passes, fresh; the final cut is approved by the owner against its exact bytes;
  and every ask in GOAL.md is delivered and verified, re-read against the requester's original words.

### What never counts

- **A proof is not a finished shot.** A proof shows the idea works; the shot still has to be built, rendered, gated and
  approved.
- **UNCHECKED is never passed.** A gate that couldn't run says so, and so do you.
- **REVIEW is never passed** until a person accepts the item, bound to the files they judged.
- **STALE is never passed**: re-run it.
- **"No errors" isn't "checked"**: a gate that didn't look can't pass.
- **"Every frame is good"** is never claimed unless every frame in the range was processed or inspected.
- **A replayed result** (tests, `SLATE_FAKE_VENDORS=1`) is never evidence for a real film.

### Evidence

Every PASS names:
- what was measured and the number (−14.0 LUFS, −1.4 dBTP; worst anchor 24 ms; mean 56.5 dB, worst 51.6 dB);
- the engine and its version;
- the files it read, by hash;
- where the detail is (a report, a strip of frames, a contact sheet).

Statuses in the tracker cite that evidence: **done** means verified, with the evidence named.

### At the end

Before saying the film is done, re-read the requester's original request in GOAL.md, not a summary and not the checklist
alone. Walk every ask. Anything partial or untouched isn't done: keep going, or say plainly what's left and why.

---

## Reference: The gates

Every gate returns a result with a state (PASS, FAIL, REVIEW, UNCHECKED, STALE), a one-line summary, its evidence
(paths and measurements), the engine and version it used, and the hashes of its inputs. Only PASS counts.

### Script (stage 3): `slate script build`

`script.schema`, `script.structure`, `script.pace` (2.6 words a second or less per shot), `script.read_time`,
`script.on_screen` (12 words or fewer), `script.runtime` (within 10% of the target), `script.banned_words`,
`script.claims`, `script.numbers`, `script.quotes`, `script.sources`, `script.first_line`, `script.vo_dashes`,
`script.shot_ids`. A failing build writes nothing (slate-story).

### Voice (stage 4): the voice checks

Policy (the voice may be used), direction (no banned tag; tagged lines strip back to the script), takes (every line has
one), words (Whisper hears every word and every brand word in full, no repeats, no tag spoken), tails (nothing leaking
from the next line), fit (each read fits its shot). Replayed takes are UNCHECKED (slate-voice).

### Timing (stage 5): `slate timing`

`timing.frames` (frame-exact and contiguous: nothing is written unless it passes), `timing.reads`, `timing.words`,
`timing.events`. `slate timing misses` must be empty at hand-in.

### Hand-in (stage 7): `slate check <act>`

Type check, module load, word misses, kit problems, banned words, events, contracts, fonts (slate-build).

### Generation and captures (stages 7 and 8)

A generated shot's takes are REVIEW until a person picks one; a capture's taps must land on their words.

### Sound (stage 9): `slate verify`

`sound.loudness`, `sound.stems_sum`, `sound.gap`, `sound.voice_sync`, `sound.cue_sync`, `sound.repeats`, `sound.glides`,
`sound.drone`, `sound.levels`, `sound.reference`, `sound.clarity`, `sound.music_licence` (slate-sound).

### The film (stages 10 to 12): `slate qa`

| Gate | Checks |
|---|---|
| `schema` | every film data file validates against its schema (a file with no schema yet is UNCHECKED, not passed) |
| `frames` | shots contiguous on the film's clock; every act render and master exactly as long as it should be, at the film's size and rate; the mix as long as the picture |
| `events_complete` | every act has a valid events file, or an explicit silence with a reason; every beat agrees with its span (a draw or count ends on its beat) |
| `sync` | cues within a frame of their beats, takes exactly on their cues, word-anchored beats on their words, every act covered |
| `loudness` | integrated loudness on target, true peak under the ceiling (ffmpeg's EBU R128 meter) |
| `bit_depth` | the mix and every stem are integer PCM at the delivery depth and rate (a 16-bit or float mix fails) |
| `silent_stems` | no stem is silent |
| `stems_sum` | the stems add up to the mix, sample for sample |
| `captions` | one caption rule (the law's 2 lines of 42 characters, 17 characters a second, at least 1 s), tightened by the format at the film's aspect and by film.json, never loosened; ordered, never overlapping, word for word |
| `claims` | every claim approved or sourced; autonomous films use approved claims only |
| `banned_words` | the brand's one list against the script, the captions and the OCR of the picture |
| `ocr` | Apple Vision reads the whole picture every 0.25 s; UNCHECKED (never another engine) when it can't |
| `readtime` | every on-screen statement readable for max(1.5 s, 0.4 s + 0.3 s per word) once fully built; a shot's declared `reading` (below) is honoured |
| `glitch` | one- and two-frame glitches in every act render, triaged against planned beats |
| `boundary` | every join between consecutive act renders: contiguous, no bigger a jump than the picture's own motion either side |
| `psnr` | the master against the act renders: at least 40 dB on every frame, every frame there |
| `motion` | the brand's eases, durations and stagger caps; entrances from 85% scale; speed and acceleration limits; no fast loops; symmetric mark rigs |
| `access` | at most 3 flashes a second; the brand's text colour pairs at 4.5:1 (body) and 3:1 (large); caption rate; 9:16 safe zones by OCR |
| `stability` | every act's render free of pops, whole-pixel snaps, shakes, reversals, wobbles, flicker and shimmer, triaged against planned beats, a reference render and the act's accepted baseline (a reversal always fails) |

Sound's own gates (`sound.*`, the balance gates among them) are `slate verify`'s; they're recorded in the same
`qa/gates.json`, `slate qa triage` shows them, and a delivery with sound needs them to pass.

### Declared reading

Some text isn't meant to be read the usual way, and a shot says so in script/script.json, with its reason:

```json
{"id": "S07", "on_screen": "…", "reading": {"voice_matched": true, "reason": "the voice reads the definition as it lands"}}
{"id": "S19", "on_screen": "…", "reading": {"not_for_reading": ["Q3 detail table"], "reason": "the report sits small as a closing object"}}
```

- **voice_matched**: a definition the voice reads along as it lands. It may run past the on-screen word budget and
  needs only the 1.5 s floor.
- **not_for_reading**: a surface shown too small to read on purpose. Its listed statements (or the whole shot, with
  `true`) aren't timed; its large elements still must read.

A declaration without a reason, or naming text the shot doesn't show, is reported as a problem, never a quiet pass.

### One OCR engine

OCR gates use Apple Vision only. When it's unavailable the gate is UNCHECKED: a second engine would silently change the
results. Logo lockups and stylized marks go to the contact-sheet review (OCR misreads them).

### Validators read the film they validate

Every gate takes the film folder and reads that film's own files: on the first films a validator once read another
film's captions and cue sheets. A read-time checker needs the text as actually drawn: most of one film's read-time
failures were the checker, not the film.

### Trusting a new metric

Before a new measurement gates anything, check it against the owner's ear or eye on takes or shots they've already
judged. The voice's breathiness measures were validated that way before they rejected anything.

### Stale gates

A result records the hashes of what it read. When any input changes, the result turns STALE, and `slate status` places
the stale gate on its stage. Re-run it; never carry a PASS across a change.

---

## Reference: Human review

Machines catch what can be measured. People catch whether it's right: whether a move feels intentional, whether a frame
reads, whether the film is the brand's. Human review is built into the method, not left to the end.

### What each shot gets

- a half-resolution motion preview with sound;
- **cut strips**: every frame from 10 before to 10 after each cut, at full resolution;
- **detail frames** at each planned event: the landing frame and 20 frames after, at full resolution;
- a motion scan (the mean frame-to-frame difference), with spikes that no planned event explains (within 3 frames)
  flagged;
- its gates.

### Statuses per shot

| Status | Meaning |
|---|---|
| **pass** | every check holds, and a person has looked |
| **fixed → pass** | a defect was found, fixed, re-rendered and rechecked |
| **fail** | an open defect |
| **pending** | the final render isn't in yet |

Record them in a per-shot table with notes (the film's QA record), so anyone can see where every shot stands.

### The defect log

Log every defect with measured evidence and its fix:
- what it was, where (shot, frame, film time);
- the measurement (a 17.8 px jump at frame 1166; a join jump of 1.36 against 0.13 inside either side; a read held 2.75 s
  of 3.1 s);
- the cause;
- the fix, and the measurement after it.

"Looks better now" isn't evidence.

### Contact sheets

After the automated checks, look at the contact sheets yourself: 0.5-second sheets of the whole film, labelled with shot
and time. Look hard at hierarchy, emptiness, legibility, the brand's look, and sync with the voice. Review representative
frames the same way the reference films were studied. The review checklist says what to look for.

### A converging loop

For a long film or a wide sweep, one pass misses things. When the ponder skill is available it can run review as a
converging loop: every shot enumerated as a unit, each graded against the checklist, the grades revised pass by pass
until they stop changing, and no shot left ungraded.

### Who reviews what

| Reviewer | Reviews |
|---|---|
| The gates | everything measurable |
| The builder | their own act, before hand-in (stills, previews, strips) |
| The coordinator (or the lead agent) | every act's stills at the changed frames, each fix in its preview, the final renders' gates |
| The owner | the look, the voice, the sound, hero moments, generated takes, the final cut |
| A separate reviewer agent | an autonomous film, before it parks (reviewer-agent.md) |

---

## Reference: The review checklist

What to look for, shot by shot and across the film. The automated gates cover what they can; this is what a person
checks on the contact sheets, the strips and the preview (at full speed and slower, with sound). After the automated
per-shot checks, look at the contact sheets yourself, and look hard: hierarchy, emptiness, legibility, the look, sync.

### Every shot

**Motion**
- [ ] No pops, jumps or twisting; nothing appears from nothing or vanishes in one frame.
- [ ] No overshoot or bounce, except the brand's named settle.
- [ ] Every move has a reason: a word or an idea. One idea per beat.
- [ ] Big moves start and end at rest; nothing smears on one frame and snaps sharp on the next.
- [ ] Characters are still between gestures and calm at the act's ends.

**Image**
- [ ] No aliasing, crawling thin lines, shimmering patterns or moire (check at the smallest delivery size).
- [ ] Nothing clipped that shouldn't be; close-ups don't crop text mid-line.
- [ ] Text is legible: size, contrast, and held long enough.
- [ ] One clear focal object; nothing empty that should be composed.

**Joins**
- [ ] Hand-offs across shot and act joins are carries, with no pop.
- [ ] Contract frames match; nothing decorative is still fading at the cut.

**Footage**
- [ ] No interpolation artifacts on generated plates or captures (haze, thin features, edges).
- [ ] Nothing generated reads as AI.

**Content**
- [ ] No banned words; the on-screen text matches the script.
- [ ] Every product element is true to the product; sample data is labelled.

### The whole film

- [ ] The look is the brand's (against its approved look reference), from the first frame to the last.
- [ ] Each act's signature moment lands, and meets the visionary bar.
- [ ] The voice is always understood; every brand word is said in full.
- [ ] Sound is locked to the picture: every visible beat has its sound within a frame; nothing sounds that the eye
      doesn't follow.
- [ ] The mix is balanced: small accents audible, textures and swells under the voice, no effect louder than it.
- [ ] Planned silences are there (the held breath, the ending on the last frame).
- [ ] Captions are right, and inside the platforms' safe zones.
- [ ] The call to action is on the end card in text as well as in the voice.

### Before a sitting

- [ ] You've watched the phone cut end to end yourself, with sound.
- [ ] Every open REVIEW item is either fixed or waiting for the owner, with its evidence.
- [ ] The packet says what changed and asks only what the owner must decide.

---

## Reference: Review packets

A review packet is what the owner sees of a version. `slate review` builds it (slate-finish); this is what goes in it
and how to review what's there.

### In every packet

- **The phone cut**, with burned-in timecode and shot id, so every note maps to a shot.
- **A 0.5-second contact sheet** of the whole film, labelled with shot and time.
- **What changed** since the last version, in plain words.
- **The open questions**, each one decision, asked as concretely as possible.
- **The gates' status** for what changed (only PASS counts; anything else is named).

### When a packet carries more

| Material | For |
|---|---|
| Voice-only previews | the voice shortlist, or a re-voice |
| Casting reels and tag A/B clips, level-matched | choosing a voice or a direction by ear |
| Per-shot half-resolution previews with sound | hero moments |
| Side-by-side comparisons | two takes, before and after a fix, code against a generated bridge |
| Gesture sheets | a brand character's gestures |
| A sound proof with a labelled spectrogram | sound decisions |
| Generated takes on a contact sheet | picking a take |

### Reviewing a packet (before it's sent)

- **Contact sheets**: review representative frames the way the references were studied: composition, hierarchy, the
  brand's look, legibility, emptiness.
- **Gesture sheets**: every gesture at its smallest and largest size, at full and quarter speed, with sound. Nothing
  shimmers, pops or strobes, and every note lands on something visible.
- **Hero moments**: at full speed and slower, with sound, against the visionary bar.
- **The phone cut**: end to end, with sound, on a small screen if you can: what reads on a laptop can vanish on a phone.

### When the owner answers

Log every note verbatim, numbered, in the tracker; record every approval against its exact file; and turn notes on
approved work into a checklist of changes to that exact artifact (perfect, don't replace).

---

## Reference: The reviewer agent: grading an autonomous film before it's held

An autonomous film is made without the owner watching. Before it parks for the owner's approval, a separate reviewer
grades it, so the owner sees films that already cleared a second pair of eyes, and a weak one comes back with its
problems named.

### Who reviews

A reviewer that didn't build the film. **If you can run sub-agents, the reviewer is a sub-agent** given only the packet
and the references, with no memory of how the film was made; **otherwise it's a fresh agent session** started just for
the review. The builder never grades its own film.

### What it's given

- the contact sheet (0.5-second, labelled) and the phone cut;
- the audio: the mix, and the stems if needed;
- the brand's four approved references (truth, look and motion, voice, sound) and the brand's taste notes;
- the owner's taste notes (sound, motion, the look) and the visionary bar;
- the film's gate results and its brief (GOAL.md).

### What it grades

| Area | Against |
|---|---|
| The look | the brand's approved look and motion reference: palette, surfaces, motion, composition |
| The sound | the brand's sound reference and levels against the voice; the owner's taste (no chimes, nothing buried, sound locked to picture) |
| The voice | the brand's approved voice: every word clear, brand words in full, no whispery or strained delivery |
| Truth | only approved claims; sample data labelled; nothing invented |
| The bar | one signature moment per act that meets the visionary bar; nothing generic |
| The brief | every ask in GOAL.md delivered |

For each, a grade with evidence: the frame, the time, the measurement, the rule.

### What it decides

- It never approves: only the owner approves a film.
- Anything below the bar is a REVIEW item with evidence; on an autonomous film that parks the film with the reviewer's
  notes, and nothing is published.
- A film that clears review still waits, held, for the owner's yes on its exact file. It reaches them by iMessage with
  the phone cut and a push notification.

### Protect the review

- The reviewer reads; it doesn't edit the film.
- It grades what's there, not what the builder intended; the brief and the references are its only context.
- Its notes go into the tracker verbatim, so the owner sees them with the film.

---

## Reference: Triage

`slate qa triage` lists everything that isn't PASS, most severe first (FAIL, STALE, UNCHECKED, REVIEW), each with its
evidence and the one next step. Gates that never ran count as unchecked. Work down the list; fix causes, not symptoms.

### Glitch flags

The glitch gate scans every rendered act for one- and two-frame jumps. A scanner flags anything fast, so:
- **flags within 3 frames of a planned beat are skipped** (listed separately by act), because a planned landing is
  supposed to move;
- **the rest are open** until they're fixed or a person accepts them.

Known false-positive classes, to recognize (and then accept with a reason, not ignore):
- count-ups (the digits change every frame);
- fast write-ons;
- text moving further than its stroke width in a frame;
- periodic strokes moving about half their pitch (double letters, repeated digits);
- deliberate hard edges;
- a UI state cut under motion blur, which renders as one mixed frame (the shutter's samples straddle the cut): expected;
- a one-off renderer flake that doesn't reproduce on a re-render.

Two things a one- and two-frame scan can't see:
- **a pop that stays**: a card that appears in one frame and remains is unlike the frame before but like the frame
  after, so it passes; look for steps (a frame unlike its predecessor that then holds) as well as glitches;
- **fast motion hidden by blur**: the 16-sample master blurs fast moves, so a one-sample preview flags more of them.
  Compare like with like when judging whether a fix reduced the flags.

### When a pop is found

- **Scan the whole act frame by frame** for other one-frame jumps and fix them together.
- **Prove unchanged frames are bit-identical** before and after the fix.
- The lead reviews stills at the changed frames and checks each fix in the builder's preview, then re-runs the shot's
  checks when the final render lands and updates the shot's status to fixed → pass with the measured evidence.
- **Confirm any flicker at full size** before fixing it: half-scale previews can flicker a level or two on slowly drifting
  cards, because the browser picks a different raster scale.
- **And the reverse**: a half-scale, one-sample preview can hide jitter that the 16-sample final shows (type stepping a
  pixel at a time under a slow move). Check risky moves in short 16-sample windows at full size before approving a
  final.
- **Review every transition of a product surface at 2 to 4 frame steps** as well: a one-frame scan can't see a card that
  stays wrong.
- **Pixel-diff every hand-over** at full resolution (a flat card to its 3D twin, a morph to its final component, frames at
  rest), and match shadows to the perspective before the switch.

### Read time

Run a read-time audit on the first full preview, and move lines earlier or give holds more time before the look is
locked; fixing it after the renders costs a re-render (slate-motion, read-time.md).

### Accepting a REVIEW item

Only a person accepts, with a reason:

```
slate qa triage --accept GATE:ITEM --by <name> --reason "<why>"
```

The acceptance binds to the hashes of the exact files judged; re-render, and it has to be judged again. An agent can't
accept a REVIEW item on an autonomous film: the film parks for the owner instead.

### UNCHECKED items

Each one's evidence says what to do: install a tool (`slate doctor` names it), make the missing input, approve a
reference. Never mark one as passed, and never swap in a different engine to make it pass.

### STALE items

Something changed since the check. Re-run the gate; if it now fails, the change broke something, and that's the finding.
