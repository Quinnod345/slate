---
name: "slate-story"
description: "Write and gate a Slate film's story. Covers the treatment and its contextual one signature moment per act recipe, the visionary bar, pinned sources and approved claims, script/script.json as the only hand-edited script source, configurable pace and reading policies, readable on-screen words, and rebuilding the clock from real voice reads. Use when a Slate film needs its idea, treatment, script, claims, on-screen text or VO copy written or revised, when a script gate fails, or when timing needs building after voicing."
---

> Knowledge-only edition of Slate's `slate-story` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-story

The story is data. One hand-edited file, `script/script.json`, holds every act and shot: what the voice says, what's on
screen, what the picture does, and where every claim comes from. `slate script build` checks it through the script
gates and writes the storyboard and a readable SCRIPT.md, and it refuses to write anything while a gate fails. Nothing
downstream is typed by hand: shot lengths, timecodes and frames all come from this file and the voice's real reads.

This skill covers stages 2 (truth), 3 (treatment and script) and 5 (timing) of the production. The front door (the
slate skill) has already made the film folder and the brief.

Read `slate history context --topic story` when a private history is selected. Keep the original direction, the
feedback and the revision together. The latest brief and authorized feedback govern creative choices; the recipes
below do not overrule a requested change in structure, energy or visual language. Drafts can receive feedback before
approval, and an already requested revision does not need another approval of that same choice. Exact source claims,
approved words and the film's real clock remain binding.

## 1. Truth first

Before a line is written, know what's true and who says so.
- The **brand's truth** (from onboarding): its claim authority, sources, approved claims, never-claim list, banned
  words and sample data.
- The **film's truth pack**, `brief/truth.json`: the sources this film relies on, each pinned (a commit, a retrieval
  date or a hash), the researched claims that cite them, what this film never claims, and its sample data.
- The product's own code, read in place at a pinned commit, is the only product truth: it wins over docs, demos,
  prototypes and older films. The owner's rulings win over the code for what's claimed.

Every claim and every number said or shown must be on the brand's approved list or cite a pinned source. Autonomous
films use approved claims only. Research method and templates: [truth](#reference-truth-research-sources-you-can-pin-and-cite). The rules every frame and
line obeys: [truth packs](#reference-truth-packs-the-rules-every-line-and-frame-obeys).

## 2. The treatment

For anything longer than a short ad, write a treatment before the script: the idea as a reframe, why this runtime, act
by act, the emotional arc, the intended memorable moments, the voice and the look and the sound in a line each, what the
film never shows, and the owner's calls so far. Keep it to a page or two. Template and craft:
[treatment](#reference-the-treatment); story shapes that work: [structure](#reference-story-structure-shapes-that-work).

## 3. The script as data

Write `script/script.json`: acts of shots, each with an id, the VO line, the on-screen words, the picture, the
transition out, and its sources and claims. Shape, fields and a worked example: [script as data](#reference-the-script-as-data-scriptscriptjson).

```
slate script build --check      # the gates only; writes nothing
slate script build              # gates, then script/storyboard.json and script/SCRIPT.md
```

The gates: schema, structure, pace (the starter uses 2.6 words a second or less, per shot), read time, on-screen density, runtime
(within 10% of the target), banned words (VO, on screen and picture), claims, numbers, quotes (no invented testimonial),
sources, and the shot-id freeze. A failure lists what to fix; fix the script, never the generated files.
`storyboard.json` and `SCRIPT.md` say "generated: do not edit by hand".

Pace comes from timing defaults, then the selected format, then `script.timing`. Reading defaults come from the format
and `script.rules.read_time`; `script.rules.on_screen_max_words` and `on_screen_max_vo_ratio` can set density limits.
These are supported choices, not reasons to bypass a failing gate. Keep the configured policy with the revision and
rebuild the script; the 2 s number hold and truthful timing still apply.

Shot ids freeze when the build passes; once scenes use them, a renumber is refused. Add shots with new ids instead.

## 4. Writing the voice-over

- **Pace:** start at 2.6 words a second or less per shot unless the format or `script.timing` sets another pace. Plan
  shot lengths from the words, then let the real reads re-time them (section 6).
- **Read time:** the starter holds statements for max(1.5 s, 0.4 s + 0.3 s per word), once fully built; use the chosen
  reading policy and its declared exemptions. Numbers hold 2 s after they land.
- **Density:** the starter uses at most 12 on-screen words per shot and about 40% of the VO word count. Use the
  configured policy for this format; a deliberate voice-matched line or small label has an explicit gate treatment.
  Choose keywords, a transcript or another text treatment for the brief, and verify its actual reading time.
- **Numbers and symbols** are written the way they're spoken or shown consistently; the clock knows how "664" or "&" is
  said, so word lookups find them.
- **Brand words** go in the brand's lexicon, so the voice checks can hear them said in full.
- **The words are final before voicing.** Direction (tone, pauses) is added later as audio tags that never change a
  word (slate-voice).

More craft, with the fixes for each gate: [VO writing](#reference-writing-the-voice-over-and-the-words-on-screen).

## 5. The visionary bar

Make beautiful things that would make someone cry. The earlier product-film recipe used **one signature moment per
act**: the beat people remember. A different brief may need several peaks, one sustained transformation or deliberate
stillness. Set that structure in the treatment. Glows, flares, particles and bounce are creative materials whose use
depends on the current direction and the brand's language; they are not universally banned. A correct but ordinary
animation does not meet the bar. If the visionary skill is available, use it before designing a hero moment: reframe,
go wide across lenses, kill the median and push one idea to a signature. Mark the intended moments in the treatment
and the shot's `notes`, so builders know where the film's weight is. See [signature moments](#reference-signature-moments-and-the-visionary-bar).

## 6. After voicing: the clock

Once the takes are approved (slate-voice):
```
slate script build --from-takes     # every voiced shot re-timed from its approved take
slate timing                        # shots, voice cues, word timings, events, timeline on the film's clock
```
- `slate timing` writes `timing/shots.json`, `vo_cues.json`, `vo_words.json`, `events.json` and `timeline.json`. It
  refuses to write unless the frames are exact and contiguous.
- Word timings come from Whisper by default; a word lookup never throws, it falls back to an estimate and records a
  miss. The miss list must be empty before any act is handed in (slate-build).
- Once an act render is registered the timing locks; only the owner can decide to re-time, with a reason.

## 7. Handing over to the pre-production sitting

When the script builds clean (and the treatment, the truth pack and the voice shortlist are ready), stop. The
pre-production sitting approves the checklist, the claims, the script, the voice shortlist and, when the brand's look
isn't approved, the look test. Say what's ready, where it is (SCRIPT.md, the truth pack, the casting reel), and what
each decision is. Record the owner's calls on the draft (trims, keeps, confirmations) as numbered decisions in the
tracker, with their words.

## Rules that hold everywhere

- One hand-edited source. Never edit storyboard.json, SCRIPT.md or the timing files; change script.json and rebuild.
- Nothing is invented: every UI element, word and number maps to a citation (truth packs).
- No invented testimonials or customer quotes presented as real; quotes carry who said them and a pinned source.
- The runtime gate requires the script to stay within 10% of its declared target. When the requester changes the
  runtime, update that target and rebuild; a tracker justification alone does not change the gate.
- The picture can be restaged freely by builders; the words, beats and timing are the script's.

## References

- [truth](#reference-truth-research-sources-you-can-pin-and-cite): researching truth; pinned sources; product-truth and capability-brief templates.
- [truth-packs](#reference-truth-packs-the-rules-every-line-and-frame-obeys): the rules every line and frame obeys about claims, data and the product.
- [treatment](#reference-the-treatment): the treatment template and how to write each part.
- [structure](#reference-story-structure-shapes-that-work): story shapes that work: bookends, payoffs, journeys, the end card.
- [script-as-data](#reference-the-script-as-data-scriptscriptjson): script.json field by field, a worked example, the gates and fixes.
- [vo-writing](#reference-writing-the-voice-over-and-the-words-on-screen): pace, read time, density, numbers, brand words, a character's own words.
- [signature-moments](#reference-signature-moments-and-the-visionary-bar): the visionary bar and the contextual one signature moment per act recipe.

---

## Reference: The script as data: script/script.json

`script/script.json` is the only hand-edited script file. `slate script build` gates it and writes
`script/storyboard.json` and `script/SCRIPT.md` (both stamped "generated: do not edit by hand"); after voicing,
`slate timing` turns the storyboard and the takes into the film's clock. Change the script, rebuild, never edit what it
generates.

### A worked example

This script builds clean, all ten gates passing, for a 30-second format:

```json
{
 "title": "The new week view",
 "version": "draft-1: the first full draft",
 "language": "en",
 "acts": [
  {
   "name": "The mess",
   "job": "show the week the viewer lives with today",
   "shots": [
    {
     "id": "S01",
     "vo": "Your week lives in six different places.",
     "on_screen": "Six places",
     "picture": "Six plain cards scatter across the page, each a different shape.",
     "transition": "carry: the cards gather into one column",
     "sources": ["site"],
     "events": [{"id": "cards_scatter", "word": "six", "land": "enter:0.5", "note": "the cards land on 'six'"}],
     "dur": 7
    },
    {
     "id": "S02",
     "vo": "Now it lives in one.",
     "on_screen": "One view",
     "picture": "The column folds into a single week card.",
     "transition": "carry: the week card lifts forward",
     "notes": "Signature moment of act 1: six cards become one.",
     "sources": ["app"],
     "dur": 6
    }
   ]
  },
  {
   "name": "The view",
   "job": "show what the week view does",
   "shots": [
    {
     "id": "S03",
     "vo": "Plan a whole week in one view, then share it.",
     "on_screen": ["One view", "Share"],
     "picture": "The week card opens; a share sheet slides out from under it.",
     "transition": "hold, then the end card rises",
     "claims": ["c1"],
     "sources": ["app:src/views/week.tsx:40"],
     "dur": 10
    },
    {
     "id": "S04",
     "vo": "Try the week view today.",
     "on_screen": "Try the week view",
     "picture": "The end card: the logo and the call to action.",
     "act_end": true,
     "dur": 7
    }
   ]
  }
 ]
}
```

The claim `c1` and the sources `app` and `site` are defined in the film's truth pack, `brief/truth.json` (truth.md).

### Fields

**The script:** `title`; `version` (a change note for this draft, in words); `language`; optional `timing` overrides
(`lead`, `tail`, `act_tail`, `speech_rate`, `max_pace`) and `rules` (this film's own extra rules: `vo_dashes`,
`first_line`, `every_shot_sourced`, `on_screen_max_words`); `ids` (`as-written`, or `renumber` for draft ids).

**An act:** `name`, `job` (its one job, in a line), optional `intent`, and its `shots` (or `lines`: the same objects,
for a film that's mostly voice).

**A shot:**

| Field | What it holds |
|---|---|
| `id` | The shot's id (S01, S02 …). It freezes at the first clean build. |
| `vo` | The voice-over line, words only; direction is added later as audio tags that never change a word. |
| `on_screen` | The words on screen: a string, or a list of strings for separate lines. |
| `hero_lines` | The on-screen lines set in the hero role (a string or a list): six words or fewer each, at most two in an act. |
| `reading` | A declaration, with its `reason`, when on-screen text isn't read the usual way: `voice_matched` (the voice reads it as it lands), `not_for_reading` (shown too small to read on purpose), or `labels` (the picture's own words, a product's UI, a Simulator label or an end card, which don't count against the 40% but still count toward the 12-word cap and are timed in full, by the script gates and `slate qa readtime` alike). |
| `picture` | What the picture does, for the builders. They may restage it; the words and beats stay. |
| `transition` | How the shot hands to the next: a carry, a portal, a mask, a whip, a UI state cut (slate-motion). |
| `sources` | Pinned source ids from the truth pack, optionally with where (`app:src/x.tsx:40`); a source that quotes the product's own copy gives the `quote` and `where` (`path:line`), re-read at the pinned commit before every build. |
| `claims` | Claims this shot makes: an approved claim's id or text, or a claim id in the truth pack. |
| `quotes` | Anyone quoted: `{text, by, role, source, real}`. An invented quote presented as real fails. |
| `events` | Beats anchored to words: `{id, word, occ, offset, land, note}`, or a time `t`. `land: "<ease>:<seconds>"` means the event is the move's landing (90% of travel), so it hits the word. |
| `dur` | A planning length in seconds. After voicing, the real take replaces it; `hold` adds picture time after the read. |
| `lead`, `hold` | Where the read starts in the shot, and extra picture time after it. |
| `notes` | Anything builders need: the act's signature moment, a shared object, a restriction. |
| `act_end` | Marks the last shot of an act when acts are split by shot. |
| `generate` | Only for a shot that may be generated (slate-generate): a reason category and what it needs. |

### The gates

| Gate | What it checks | The usual fix |
|---|---|---|
| `script.schema` | the file's shape | the message names the field |
| `script.structure` | acts and shots are there, ids unique | add or rename shots |
| `script.pace` | 2.6 words a second or less per shot | cut words, or give the shot more time |
| `script.read_time` | every on-screen line holds max(1.5 s, 0.4 s + 0.3 s per word) once settled; numbers 2 s | fewer words on screen, or a longer shot |
| `script.on_screen` | at most 12 on-screen words per shot, and at most 40% of the words the voice says in it (words the voice says as they show are read along; a `reading` declaration answers for the rest) | keywords, not a transcript |
| `script.hero_lines` | a hero line has at most 6 words, and an act shows at most 2 | shorten it, or let one of them be body type |
| `script.runtime` | within 10% of the format's target | planning lengths (`dur`), or cut or add a beat |
| `script.banned_words` | the brand's banned words in the VO, on screen and in the picture notes | rephrase |
| `script.claims` | every claim approved or cited to a pinned source; nothing from the never-claim list | cite it, get it approved, or cut it |
| `script.numbers` | every number said or shown has a source | cite it or drop it |
| `script.quotes` | no one quoted without a named person and a pinned source; every quoted product fact still where it says it is at the pinned commit | source it or cut it; fix the `where` the message names |
| `script.sources` | sources exist and are pinned (when the film requires every shot sourced) | add the source to the truth pack |
| `script.first_line`, `script.vo_dashes` | this film's own rules, when set | as the message says |
| `script.shot_ids` | ids freeze at a clean build; a renumber is refused once scenes use them | add new ids instead of renumbering |

`slate script build --check` runs the gates and writes nothing. A failing build writes nothing either, and the last
good storyboard stays as it was.

### After voicing

`slate script build --from-takes` re-times every voiced shot from its approved take (the read plus the lead and tail)
and switches the film to take timing, which later builds keep. Shots without a take keep their planning lengths. Then
`slate timing` builds the clock (SKILL.md, section 6).

---

## Reference: Signature moments and the visionary bar

**The bar:** make beautiful things that would make someone cry. It came from the owner after a logo moment that was
correct but "just isn't enough", and it's the bar for every film since.

### One signature moment per act

- The earlier product-film recipe gave each act one memorable beat. Use it when that structure serves the current
  brief; several peaks, a sustained transformation or stillness can be equally deliberate.
- Build inside the chosen visual language. Glows, flares, particles, confetti and bounce can belong to that language;
  their use is a scoped creative decision, not a universal prohibition. Keep product claims and source evidence true.
- Name it in the treatment, mark it in the script (the shot's `notes`), and give it room: time on either side, and the
  sound's intended landings (slate-sound).
- A correct but ordinary animation doesn't meet the bar. Hero moments are reviewed against it in the packet, and the
  reviewer grades autonomous films against it too.

### How to find one

If the visionary skill is available, use it before designing any hero moment. The method, briefly:
1. **Reframe.** What is this act really about? What would make the viewer feel it rather than be told it?
2. **Go wide.** Generate ideas through different lenses: first principles, a far field's mechanism (print, film,
   hardware, nature), inverting a constraint, a master's taste, the feeling first, the obvious-in-hindsight future.
3. **Kill the median.** Cut the ideas anyone would list.
4. **Push one to a signature.** Specific enough to build, with the insight nameable in one sentence.

Test what survives: is it visceral at first glance, non-obvious, and real enough to build tonight?

### What worked on the first films (as patterns, not recipes)

- **An object that becomes the answer.** The viewer's question ("what does it do for me?") answered by one object they
  can hold, with a page for every door it opens. Keep the object through each view so its marks accumulate; a cover
  hand-over, contact, comparison and audience reveal can give that continuity visible meaning
  ([one object carries the answer](#reference-story-structure-shapes-that-work)).
- **A held breath before a landing.** Everything still, an empty slot, then the key mark drops in and the impact echoes
  through the ground (slate-motion, signature-moments.md in that skill, for the staging).
- **A payoff set up early.** An empty slot shown in the first act, filled in the last.
- **Leaving the decision to the viewer.** The last box stays empty, and nobody on screen touches it.
- **Restraint as the moment.** For a weighty line, everything holds still but a slow focus pull that leaves one element
  standing alone.

### Checking the bar

- Would the owner say "I've never seen that", and want it built tonight?
- Does it say the act's one idea without a word on screen?
- Is it the brand's, or could it be anyone's?
- Does the sound land with it?

---

## Reference: Story structure: shapes that work

Patterns that held up across three films, and the rules behind them. Use them as starting points, never as a template to
fill in regardless of the brief.

### Openings and endings

- **Bookend the film.** The close can play the opening's construction in reverse, or return to the composition the film
  opened on, with the call to action landing where the opening's first word landed.
- **The end card carries the call to action in text** as well as in the voice, and holds long enough to read twice.
- **Open out of silence** and let the first image establish the world before the first word.

### Payoffs

- **Set up a payoff visibly.** Show what's missing now (an empty dashed slot beside the thing nobody measures) and fill
  it later in the film. The viewer remembers the gap.
- **The product's own empty state** (a placeholder before the first reading) is a truthful setup for a reveal that pays
  it off.
- **Answer the viewer's "what does it do for me?"** in one object they can hold, with a page for every door it opens.
- **Leave a decision visibly to the viewer**: the last box stays empty, and nobody on screen touches it.

### One object carries the answer

Give an abstract promise a physical carrier when that makes the promise clearer: a book that gathers evidence, a
record that keeps a choice, or another object the viewer understands at once. Establish it early enough that its
return has meaning. Keep its identity while its contents answer successive questions.

A book can make that progression concrete: a familiar seal resolves into its cover emblem; a contact leaves an
impression; a spread makes a comparison; a later view shows who the result reaches. Each step adds meaning to the
same object. Choose the sequence for the brief, write its claim and payoff in the treatment, and give each settled
idea enough time to read. The mark, copy, data and page design come from the film's own truth and brand pack.

The reusable mechanism is a hinged book with physical pages and continuous shadows. The authored sequence belongs
to the film. See slate-motion's physical-books.md for the craft and slate-build's hinged-books.md for the API.

### Making a process into a story

- Turn a product's steps into a story about one person (the sample user decides, commits, discovers), so a process
  reads as a journey rather than a feature list.
- Follow the product's real journey order; a film that jumps around the product teaches the wrong model of it.
- Stage only what the voice names: three spoken items get three taps, not twelve.

### Remaking or answering an earlier film

- When a film is modelled on an original, follow it topic for topic, then rebuild every graphic in the current craft:
  the original's content in the new film's look.
- Recover the original's exact on-screen content by grabbing its frames (`slate analyze <video>`), not from memory or
  summaries.
- Check every claim in the original against the current product and site; the new film carries only what's still true
  (truth.md).

### Acts

- Every act has one job, one carrier (the object it's about) and one signature moment.
- An act break with no voice for a couple of seconds is a natural breath: the score can open there.
- Hand acts to each other on carries (an object that continues across), never on a cut to a title card.

### Words on screen and words in the voice

- On-screen text is keywords, not a transcript: about 40% of the words the voice says in that shot, or fewer.
- When the script's picture notes and its on-screen column disagree on wording, the on-screen column's words go on
  screen.
- The on-screen word budget (12 per shot) can justify leaving product elements out of a shot; record the omission in the
  act's notes.

---

## Reference: The treatment

A treatment is the film on a page or two, before the script: what it's really about, how it feels, and where its weight
falls. It's what the owner approves in spirit before approving words, and what builders read to know why each act
exists. Write one for anything longer than a short ad; for a reel or an ad, its first four sections are enough.

### Template

1. **The idea, as a reframe.** One or two sentences that say what the film is really about, not what it lists. A good
   reframe changes the question ("a score is a verdict until someone reads it with you").
2. **Runtime rationale.** Why this length and not shorter or longer. Tie it to the format and to what the viewer needs
   to feel or do by the end.
3. **Act by act.** For each act: its job in one line, what the viewer learns, what they feel, and how it hands to the
   next.
4. **The emotional arc.** A small table: act, where the viewer starts, where they end.
5. **Memorable moments.** One signature moment per act is the starting recipe; name the peaks, sustained passage or
   stillness that this brief actually needs (signature-moments.md).
6. **The character's gesture vocabulary** (character-led films only): the few gestures it has, each with one meaning
   (slate-motion).
7. **Voice direction.** Who's speaking, how they sound, what they never sound like (slate-voice).
8. **Look and sound.** A line each, using the current direction and the applicable brand approvals. Record requested
   revisions alongside the earlier look and palette, so a creative change does not erase its history.
9. **What the film never shows.** Features ruled out, words the brand avoids, claims not made. Builders and checks read
   this list.
10. **The owner's calls.** Decisions already made, in their words.
11. **Notes for builders.** Anything a builder needs that isn't in the script: a recurring object, a shared surface,
    where the camera rests.

### Craft

- **Reframe before you write.** State the request as a job to be done, then ask what the real problem behind it is. The
  strongest films solve a better problem than the one stated.
- **The visionary bar.** Give the intended moments enough force to make someone cry, inside the chosen visual
  language. Their number comes from the treatment, not a universal quota. Hero moments are reviewed against the bar.
- **Clear attention per beat.** Earlier films used one carrier per act and one object per phrase. A different brief
  can use parallel action when viewers can still follow the intended idea.
- **Show, then say less.** Keywords were the product-film starting recipe. A transcript or another text treatment can
  serve a different brief when its configured reading policy and actual screen time support it.
- **Name the payoff early.** If the film ends on something, set it up visibly in the first act (structure.md).
- **Keep the baseline and the requested change.** A derived or re-cut film starts from the earlier film and records
  what changes. The latest authorized feedback governs the revision; do not turn a prior approval into a ban on the
  requested redesign or ask for that same creative choice again.

### Handing over

The treatment goes to the pre-production sitting with the script, or earlier on its own if the idea itself needs a yes.
Record the owner's calls on it as numbered decisions in the tracker. When the script contradicts the treatment later,
change one of them on purpose and say so; don't let them drift.

---

## Reference: Truth packs: the rules every line and frame obeys

A truth pack is the brand's truth (from onboarding) plus the film's (`brief/truth.json`). The script gates, the claims
gate and the banned-word gate read it; these rules are what it's for. Builders follow them too: the picture can make
claims just as the voice can.

### Nothing invented

- Every UI element, word and number on screen maps to a citation. Never show UI the product doesn't have.
- A concept screen (something that isn't built) needs the requester's explicit sign-off and a visible "concept"
  treatment.
- Never show a feature the product doesn't have, even if the script asks for it (a download, an integration that reads
  someone else's data). A correction from the requester removes it everywhere it appears.
- Never show as working anything that isn't built, is stubbed, or is off by default.
- Product names follow the product's current code, not older materials.
- When the product won't do something, show the absence (the empty page is the point) and draw nothing that implies
  the missing feature (no dial, gauge or projected number).

### Data

- Data graphics are drawn from the product's real distributions, ranges and clamps, never invented shapes.
- Illustrative graphics that aren't real data carry an "illustration" treatment and never show fabricated percentages.
- Conceptual charts carry no numbers and no axis labels.
- Future or illustrative data points carry no numbers; only real sample readings are labelled.
- A counter for a vague quantity (the voice says "thousands") runs as time and never settles on a precise number.
- Show aggregated data the way the product aggregates it; never single out an individual.
- When sample data must be split in ways the screen never shows, choose the split so every statement on screen stays
  true.

### Sample data

- The film's sample company, people and numbers come from one sample-data record, used everywhere.
- The sample-data label appears on every frame that shows sample data, and only there (not on frames showing product
  facts).
- The label sits in one corner for the whole film, a corner no character or UI element uses (when one does, move the
  label once, film-wide), and it lives at the act's top level, fading in with the first sample data: inside a sub-layer
  it goes missing for whole shots and then pops in. The kit's `CornerLabel` takes the corner.
- When real content isn't available (assessment questions, customer records), abstract it (word-shaped bars, blurred
  rows) rather than inventing copy.
- A quote from a sample persona is film copy built from a real source line and the voice's words, shown only inside a
  clearly labelled sample context, never as a real testimonial.

### Quotes and testimonials

- No invented testimonials or customer quotes presented as real; that's also the law.
- A quote in the script names who said it and cites a pinned source, or it doesn't run.

### Partners, press and third parties

- Partner mentions stay inside what's true and approved: a statement in type, with no partner logos or terms the brand
  isn't licensed to use. A seal or stamp reads as an endorsement: set a partnership in type instead.
- Press and research artefacts are drawn as paper with their real titles and dates; for logos you don't hold as licensed
  assets, set the publisher's name as text.
- An analogy to a third-party product carries no bureau name, logo or score range.

### Numbers from older sources

- A figure taken from an older source that can't be verified is flagged to the claim authority before it's used.
- Recheck an original's statistics against a current public source, and cut or correct any that don't match.

### When sources disagree

- The code wins over demos, docs and old films; the owner wins over the code for what's claimed.
- When the voice and the product disagree on a figure, re-voice the line to match the product.
- When the product-truth file doesn't quote the exact copy (a label, a limit, a status), don't write it: show the
  structure without the words and note the gap.
- When the product's code doesn't specify a detail, the brand's own official product mock may fill it, with the source
  noted; the code still wins wherever it speaks.
- A film device that isn't product UI (a fanned hand of cards) carries only names and marks the film has already shown.
- Metaphor devices (a company's week, a playbook) are abstract paper (skeleton bars, numbered rows), never fake product
  UI with invented copy.

### Words the brand avoids

The brand's banned words live in its pack, one list, read by every check: the script gates, the text in the act files,
the captions, the OCR of the rendered picture and the transcript of the mix. Add a film-specific word to the film's
never-claim list rather than editing the brand's list.

---

## Reference: Truth research: sources you can pin and cite

A film is only as trustworthy as the sources behind it. Truth research finds what's actually true about the product
and the brand, pins each source so it can be re-checked, and records who rules on what's claimed.

### The order of authority

1. **The owner's rulings** on what's claimed. A feature can exist in the code and still be ruled out for the film
   ("that's not true" means it doesn't appear).
2. **The product's code**, read in place at a pinned commit and cited `path:line`. It wins over everything below.
3. **The brand's website, live product pages, public demos and guidelines**, read and cited with the date.
4. **Docs, prototypes, demos and older films**: layout references only. They drift: names change, numbers move,
   features are retired. When they disagree with the code, the code wins; when a product demo's wording disagrees with
   the product's code, the code wins.

For a brand the owner doesn't own, the brand's **claim authority** (a named person there) rules on claims and brand use.

**Nothing is invented**: every UI element, word and number in the film maps to a citation in the truth pack. A concept
screen (something not built) needs the requester's explicit sign-off and a visible "concept" treatment. The rules that
follow from this are in [truth packs](#reference-truth-packs-the-rules-every-line-and-frame-obeys).

### Pinning a source

Every source in `brief/truth.json` has an id and a pin: a commit, a retrieval date or a SHA-256. A claim cites a pinned
source by id, with where in it (`path:line`, a page, a section). A number with no pinned source doesn't go in the film.

```json
{
 "claim_authority": "the person who rules on this brand's claims",
 "sources": [
  {"id": "app", "title": "The product's source", "pin": "commit 3f2a9c1", "note": "read in place, never copied"},
  {"id": "site", "title": "The public website", "url": "https://example.com", "retrieved_at": "2026-09-30", "pin": "2026-09-30"}
 ],
 "claims": [
  {"id": "c1", "text": "Plans a week in one view", "source": "app", "where": "src/views/week.tsx:40"}
 ],
 "never_claim": ["works offline"],
 "sample_data": {"company": "an invented sample company, always labelled as sample data"}
}
```

### Reading company code

- Read it in place, on the machine that holds it, with read-only commands (`git show`, `git grep` at the pinned
  commit). Never copy it to another machine, into Slate, or into a prompt for a generator.
- Quote the exact copy the product uses (labels, statuses, limits) with `path:line`, and re-verify quotes before the
  build: a first pass once had to correct line numbers on about a hundred quotes.
- A voice brief or research note that quotes company code stays with the company's material; it never travels into a
  personal or public package.

### Templates

#### Product truth

For a product film, write one product-truth document the builders work from:
- the pinned commit;
- the product in one paragraph;
- the journey order (how a person really goes through it);
- every screen the film shows, with its exact copy;
- the product's agent or character, if it has one;
- secondary views (partners, admins, settings);
- the product's own motion (its CSS easing tokens or its springs);
- the palette and type the film takes;
- **live versus not built**: what's shipped, what's stubbed or off by default (never shown as working);
- numbers and words to get exactly right;
- where the product disagrees with itself.

#### Capability brief (for a product character or agent)

How it was checked; sources; what it knows; how it synthesizes and explains; what it suggests next; its guardrails;
**what is not true about it**; where this film differs from the product; and what the film uses. Every line carries a
source. Describe a character only with capabilities the owner treats as true.

#### Reference analysis claims

When a film remakes or answers an earlier film, list every claim in the original that conflicts with the brand's
current website or product, and decide each with the claim authority before writing.

### Checking numbers

- Recheck an original's statistics against a current public source; cut or correct any that don't match.
- A figure from an older source that can't be verified goes to the claim authority before it's used.
- Percentiles, ranges and derived numbers are computed from the product's own model, not eyeballed.
- One company, one set of numbers: every shot that shows the sample reads from one sample-data record, so the same
  company never shows two different weeks.

---

## Reference: Writing the voice-over and the words on screen

The earlier product-film recipe gave the voice the story, the screen the keywords and the picture the rest. Choose
those roles for the current brief. The script gates check the configured pace, reading and density policies; their
defaults came from measured failures and do not prohibit another supported policy.

### Pace

- **The starting pace is at most 2.6 words a second per shot.** A faster read rushed the earlier film. The format and
  `script.timing` can set another pace; measure the actual read instead of treating a planned rate as voice evidence.
- Plan shot lengths from the words. A deliberate narrator reads 1.5 to 3.2 words a second; the real takes re-time the
  shots after voicing (`slate script build --from-takes`), so the plan only has to be close.
- Leave air: a read starts a short lead into its shot and ends a short tail before the cut. Heavy lines get their air
  from the edit (a longer hold), not from pause tags.

### Read time

- The starting reading policy holds statements, once fully built, for max(1.5 s, 0.4 s + 0.3 s per word). Format
  settings and `script.rules.read_time` can choose the policy. A declared label, voice-matched line or non-reading text
  uses its explicit gate treatment and reason where required, not an undeclared exemption.
- A number holds at least 2 s after its count lands; a label of three words or fewer, at least 1 s.
- A line the voice also says stays up at least as long as the voice takes to say it, and never leaves before the voice
  finishes it.
- The master is checked by OCR as well: an on-screen line that looked long enough in the script can still fall short if
  the camera leaves early. Fix that in the picture (slate-motion, read-time.md).

### Density

- The starting limits are 12 on-screen words per shot and about 40% of its VO word count. Format settings and
  `script.rules.on_screen_max_words` / `on_screen_max_vo_ratio` can change these limits.
- Keywords, a transcript or another treatment can serve the brief. Voice-matched lines and small labels have explicit
  gate handling; choose it accurately and verify the rendered reading time.
- Body text on screen is at least 28 px at a 1080-line frame (scale with the frame); the kit's type scale does this.

### Numbers, symbols and brand words

- Write numbers the way the film shows them and let the clock work out how they're said: word lookups know that "2026"
  is said "twenty twenty-six" and "&" is said "and", so beats can key to them.
- Every number said or shown needs a source (truth packs).
- Put the brand's own words (names, product terms) in the brand's lexicon; the voice checks confirm each one is heard in
  full on every take.

### The words are final before voicing

- Direction (warmth, a smile, a pause) is added later as audio tags that never change a word. A tagged line must strip
  back to the script exactly (slate-voice).
- If a line doesn't land when voiced, change the direction first; change the words only on purpose, in the script, and
  rebuild.
- When the voice and the product disagree on a figure, re-voice the line to match the product.

### A character's own words

When a product character or assistant speaks or writes on screen, its words follow the product's own content rules (for
example: lead with the answer, no dashes or emoji, every number from the report). Describe it only with capabilities
the owner treats as true (truth.md).

### Style that helps the voice

- Short sentences, one idea each; the stress where the meaning is.
- Punctuation is direction: a full stop gives a beat, an ellipsis a trailing pause, a question lifts.
- Avoid words that trip a synthetic voice: stacked consonants at a line's end, homographs whose reading changes the
  meaning, abbreviations the voice would spell out.
- If the avoid-ai-writing skill is available, run the script through it for phrasing that reads as machine-written.
