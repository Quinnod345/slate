---
name: "slate-finish"
description: "Render, master, derive and deliver a Slate film. Covers final renders with true motion blur (chunked, resumable, patched and spliced with proof, queued), masters (After Effects for supervised films on the owner's go, ffmpeg for autonomous and draft films), derived films (cut-downs, new aspects, new languages), captions and thumbnails at delivery, the delivery manifest (written last, never approved for publishing until the owner approves that exact file), and review packets and versions. Use when a Slate film needs rendering or re-rendering, a master, a cut-down or another aspect, a delivery set, or a review packet for the owner."
---

> Knowledge-only edition of Slate's `slate-finish` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-finish

The last mile is where most time and disk go, and where a film is either proven or quietly broken. Every render is
counted, every splice is proven, every master is compared frame by frame with what it was made from, and nothing leaves
until the gates pass and a person approves the exact file.

This covers stages 10 (render), 11 (master), 12 (deliver) and 13 (review and correct) of the production. The gates
themselves are slate-qa's.

## 1. Render

```
slate render                          # every act, one at a time, 16 motion-blur samples, ProRes 422 HQ
slate render --act 3                  # one act; registering it locks the film's timeline
slate render --act 3 --from 120 --to 260
                                      # re-render a range and splice it in, proven by frame hashes and PSNR
slate render --resume                 # pick up renders that didn't finish, keeping every good chunk
slate render --detach                 # queue it and return a job id at once
```

- Renders are chunked and resumable: a chunk with the right frame count and hash is kept; a short or missing one is
  rendered again. Long renders always go through the job queue (`slate job status <id>` follows one).
- Each frame is drawn 16 times across a 180-degree shutter and averaged in 16-bit (4 in draft), into ProRes 422 HQ,
  10-bit, BT.709. Never fake motion blur, never render on another machine, one heavy render at a time.
- Every render reserves its disk first and removes its bundle when it ends.
- `slate render list` shows what's rendered, stale or unfinished; `slate render stills --frames <f,…>` makes review
  stills; `slate render clean` removes leaked bundles and finished chunks.
- After Effects acts render with `--engine ae --go`, only on the owner's go and never for autonomous films.

See [renders](#reference-renders).

## 2. Master

- **Supervised films are finished in After Effects**, on the owner's go: an editable AE project built from the film's
  data, then chunked aerender masters. `slate master --ae --go` builds the project; ask the owner to save and quit AE;
  then the masters render. Never quit AE for them. See [AE finish](#reference-the-after-effects-finish).
- **Autonomous and draft films are mastered with ffmpeg** (`slate master --ffmpeg`), and held for the owner. The owner
  can start the AE finish when they approve a held film.
- Every master is compared with the act renders frame for frame (at least 40 dB PSNR on every frame, exact frame counts),
  and the AE project is audited. That check caught both a colour shift and a one-frame lag on the first films.

See [masters](#reference-masters).

## 3. Derived films: cut-downs, aspects, languages

```
slate variant <parent-id> <child-id> --aspect 9:16      # or --cut 15, or --language fr
```

A derived film reuses its parent's approved takes, timings, beats and assets by reference, keeps its clock, re-stages
its layout for its own type scale and safe zones, re-plans its sound, runs every gate and needs its own approval. Hero
placements are derived at master quality; social cut-downs can take a faster route once one is proven. See
[derived films](#reference-derived-films-cut-downs-aspects-and-languages).

## 4. Deliver

`slate deliver` writes the delivery set, and the manifest last:
- the masters (and derived films' masters), the mix and its four stems;
- the format's platform files (`deliver/vN/platform/`);
- captions as SRT and WebVTT (burned in too, where the format asks);
- a review cut, a phone cut and 0.5-second contact sheets;
- thumbnails;
- the AE project, for supervised films;
- internal flags for which voices and shots are synthetic (never published);
- the manifest: every file with its size, SHA-256 and probe, anything missing listed, and **"not approved for
  publishing"** until the owner approves that exact file's SHA-256.

A delivery refuses replayed plates or captures, plates without an approved take, and draft films. A delivered version is
never overwritten. See [delivery](#reference-delivery).

## 5. Review and correct

`slate review` builds the packet for the current version: a phone cut with burned-in timecode and shot id, a 0.5-second
contact sheet, what changed since the last version, and the open questions. It goes to the owner's Downloads for their
own productions, or by iMessage with the phone cut and a push notification for an autonomous agent's films. Notes come
back verbatim, numbered; fixes are targeted (re-voice only changed lines, re-render and splice only the affected range,
re-mix, re-run the gates); versions are numbered, and every approval records the SHA-256 of what was approved.
`slate notes add|list|plan` logs and plans them; `slate review grade` records a separate reviewer's verdict on an
autonomous film; `slate approved <file>` says whether a file may be posted. See
[versions and review](#reference-versions-and-review-packets).

## Rules that hold everywhere

- Renders are local, one heavy job at a time, through the queue; never on another machine.
- A final render replaces an act's render only when its frame count is exact and its proof passes.
- After Effects steps start only on the owner's go; autonomous films never touch AE.
- Nothing publishes itself: posting needs the owner's approval of that exact file.
- A delivered version is never overwritten, and superseded material is archived with a note.

## References

- [renders](#reference-renders): chunks, resuming, patches and splices, engines, the queue, disk.
- [masters](#reference-masters): what a master is, the checks against the renders, loudness targets.
- [ae-finish](#reference-the-after-effects-finish): the AE project from data, aerender masters, colour, frame placement, the cache.
- [derived-films](#reference-derived-films-cut-downs-aspects-and-languages): cut-downs, aspects, languages, and faster variant routes.
- [delivery](#reference-delivery): the delivery set, thumbnails, captions, the manifest, publishing.
- [versions-and-review](#reference-versions-and-review-packets): review packets, notes, targeted fixes, versions.

---

## Reference: The After Effects finish

Supervised films are finished in After Effects: an editable AE project built from the film's own data, and masters
rendered by aerender. It's the owner's, so it starts on their go.

### The rules

- **Only on the owner's go.** Every AE step refuses without `--go`, refuses for autonomous films, and refuses while AE is
  busy (exit 5). Adobe's enterprise terms bar operations a person didn't start; Slate treats that as the rule.
- **Never quit AE for the owner**, and never "without saving": ask them to save and quit. Open projects are preserved
  before any rebuild.
- **AE's preferences are changed only by Slate's byte-safe tool**, with AE closed, one key at a time, line endings kept,
  and the scripting-security preference never touched. A text-mode rewrite once reset every preference AE had.
- **The disk cache is off while masters render**, and the owner's setting is restored afterwards, even on a failure or a
  kill. It once filled 60 GB. Emptying the cache is the owner's job, in AE's own settings.

### The steps

1. `slate master --ae --go` builds the project from data: one comp per shot showing its slice of the act render, the act
   comps in order, and the master comp with the final mix, a marker per shot and its words.
2. The project is audited (settings, comps against the shots, footage, fonts, render format) and the results recorded as
   gates.
3. The owner saves and quits AE.
4. The masters render with aerender in chunks: each chunk in a fresh process, with two outputs from one pass (H.264, and
   a high-quality intermediate conformed to ProRes 422 HQ), up to three tries, resuming by skipping chunks already at the
   right frame count, with a disk watchdog that stops under a floor of free space. Chunks are joined by stream copy and
   the mix is muxed in.
5. Every master frame is compared with the act renders (masters.md).

### Settings that matter

- **Working space Rec.709 Gamma 2.4**: the act renders are BT.709-tagged, and AE reads that tag as Rec.709 Gamma 2.4.
  With an sRGB working space AE converted them, and the darkest brand colour came out about 8 code values dark. With the
  matching space, the difference is under half a code value. Footage colour profiles and output-module colour settings
  can't be set by script in AE, so the working space is the lever.
- **16 bits per channel, linear blending off.**
- **A sampling bias on nested comps**: every nested layer starts a tenth of a frame early, so AE samples inside each frame.
  Placed at exact fractional-rate times, slices showed the previous frame and the picture ran a frame behind the sound;
  AE's own half-frame tolerance couldn't see it.
- **AE's stock "High Quality" output is ProRes 422, not 422 HQ**, and neither ExtendScript nor the AE bridge can pick
  the codec inside an output module's format options: render the stock lossless-with-alpha output and conform it to
  422 HQ.

### Rendering facts

- aerender renders without AE's interface (in its render-only mode it reportedly doesn't need an Adobe sign-in, which
  is unconfirmed); several aerender instances can't write one movie file, so parallel AE renders write image
  sequences, and plug-ins on extra render machines carry their own licences.
- Long aerender runs swap and abort under memory pressure: chunk them, in fresh processes, with a memory cap.
- ffprobe lists AE's movie streams twice; count frames from the first.
- Adobe Media Encoder comes with AE, but the pipeline doesn't need it.

### Proven end to end

Before the first film, a toolchain proof imported a generated clip into an AE comp, titled it on a brand ease, saved the
project and rendered it with aerender, end to end, and measured the ease in pixels. `slate connect aftereffects` repeats
that kind of proof as a one-second smoke test, on the owner's go.

### When AE isn't there

Finishing works without the AE bridge's file-write preference (the osascript route reports through AE's own settings).
If AE isn't installed or licensed, supervised films can still be mastered with ffmpeg on the owner's say-so, and the
manifest records it.

---

## Reference: Delivery

`slate deliver` assembles the delivery set in the film's `deliver/` folder and writes the manifest **last**, so a
manifest only ever describes a complete set.

### The delivery set

| Item | Notes |
|---|---|
| Masters | ProRes 422 HQ (archival) and H.264 (everyday), per derived film too |
| The mix and its stems | 48 kHz, 24-bit; four stems (dialogue, effects, ambience, music) that sum to the mix |
| Captions | SRT and WebVTT sidecars; burned in as well where the format asks (reels) |
| Review cut, phone cut, contact sheets | a half-resolution review copy, a small phone copy, 0.5-second contact sheets |
| Thumbnails and covers | per platform, at the platform's size |
| Platform files | the format's per-platform encodes (size, clock, bitrate, length limits), in `deliver/vN/platform/`; `slate formats show <format>` lists them |
| The AE project | for supervised films finished in AE |
| Synthetic-media flags | which voices and shots are synthetic: internal only, never published |
| The manifest | every file with its bytes, SHA-256 and probe; anything missing listed; the approval status |

### Thumbnails and covers

- The strongest single frame, not a new design: a still from the film at a signature moment (`slate render stills`),
  with the title set in the brand's own type if the platform wants text.
- Truthful: the thumbnail shows what the film shows.
- Sized per platform, inside its safe areas.
- A vendor's thumbnail tool can make covers when its credits are funded; it's optional, and its output follows the same
  truth rules.

### What a delivery refuses

- A draft film (drafts are never delivered as final).
- Plates or captures made in replay (tests), and plates without an approved take.
- A film whose gates don't all pass: only PASS counts; REVIEW items need a person's decision first (slate-qa). That
  includes the sound gates `slate verify` records, the balance gates among them, whenever the master carries sound.
- A platform file over its platform's size or length limit.
- Overwriting a delivered version: the next delivery is a new version.

### Publishing

Every output is marked **"not approved for publishing"** in its manifest until the owner approves that exact file's
SHA-256. Then:
- the requester (or their agent) posts **that exact file**, and never another version;
- an autonomous agent posts through its own committing path, after the owner's yes;
- Slate itself never posts, uploads or publishes anything.

A request to post a film without that approval is refused with what's missing (slate, routing.md).

### Where copies go

The owner's own productions: copies in their Downloads (the full master, a smaller share copy, the phone cut). An
autonomous agent's held films: the phone cut by iMessage and a push notification, with the question of approval. Never a
public link, never a platform upload.

### AI labels

None unless the law requires one. The manifest's synthetic-media flags make it clear when a law applies; a platform's own
labelling rule is the owner's call per platform.

---

## Reference: Derived films: cut-downs, aspects and languages

One film often needs to exist in several shapes: a 6-second cut, a 9:16 reel from a 16:9 film, a square cut for a feed,
a version in another language. Each is a **derived film**: its own folder, with a parent.

### Making one

```
slate new launch-reel --brand <brand> --format <format> --parent launch-film --derivation '{"aspect": "9:16"}'
slate new launch-15 --brand <brand> --format <format> --parent launch-film --derivation '{"cut_s": 15}'
slate new launch-fr --brand <brand> --format <format> --parent launch-film --derivation '{"language": "fr"}'
```

### What it reuses, and what it owes

- **Reuses by reference** (nothing is copied): the parent's approved takes, timings, beats, plates and score takes. It
  keeps the parent's clock.
- **Re-stages its layout**: its own type scale and safe zones for its aspect and platforms. A new aspect is never a crop:
  titles, faces and UI are re-placed inside the new frame's safe areas, and the camera's framing is rethought where it
  must be.
- **Re-plans its sound**: a cut-down needs its own score edit and joins; a new aspect keeps the mix; a new language needs
  new voice takes.
- **Runs every gate** again: no gate carries over from the parent.
- **Needs its own approval**, at its own final cut.

### Channels

| Channel | Route |
|---|---|
| Hero placements: website, App Store, a video platform's master | derived at master quality, through the whole pipeline |
| Social cut-downs: reels, shorts, feeds | can take a faster route, once one is proven faster at acceptable quality |

### A faster route for social cut-downs (not adopted yet)

A cloud timeline editor can make fast, timing-exact variants (cut-downs, re-timed or re-voiced versions, animatics)
driven by the same events and word timings. It's to be benchmarked against a kit-built cut-down of the same film and
kept only if it's genuinely faster at acceptable quality. What's known about it:
- it suits variants, not the flagship: no 3D, limited motion blur, no visual editing;
- it refuses tracks with a single key, zero-width masks, and shader code that paints outside its box;
- motion blur on frames whose children have shadows makes hard, fringed halos: skip blur there;
- it rasterizes a node's mask at canvas size from the node's own origin, and mask width grows from the mask's centre;
- its 16-sample blur cap shows steps on whips: ramp the blur instead;
- its upload slots expire in under an hour: upload right before use;
- sandbox runs cost no credits and rendered about 67 ms a frame at 1080p, but a 100-second render took 94 to 577 seconds
  end to end;
- its workflow docs sit behind the vendor's connector: record the version used with every variant;
- per-character type animated outside a browser needs real glyph shaping to keep kerning.

### Checking a derived film

Everything in slate-qa, plus: the safe zones for its platforms on the contact sheet, captions re-flowed for its width,
and a side-by-side against the parent at the moments that matter (the signature moments, the call to action).

---

## Reference: Masters

A master is the film as delivered: the act renders joined, with the final mix, at the delivery bar. Two routes make one.

| Film | Master | Who starts it |
|---|---|---|
| Supervised | After Effects: an editable project built from the film's data, and aerender masters (ProRes 422 HQ and H.264) | the owner, with `slate master --ae --go` |
| Autonomous, draft | ffmpeg: the act renders joined by stream copy, with the mix | Slate, with `slate master --ffmpeg`; the film is then held for the owner |

The owner can start the AE finish for an autonomous film when they approve it. The AE route in detail:
[AE finish](#reference-the-after-effects-finish).

### The checks every master passes

- **Master against renders, frame for frame**: every frame at least 40 dB PSNR against the act render it came from, and
  every frame there. On the first films this check caught AE converting the colour (the darkest brand colour 8 code
  values off, 33 dB) and a one-frame lag from the third act on (the picture 33 ms behind the sound). Neither showed up in
  any other check.
- **Exact frame counts**, for the master and every act.
- **The mix** is exactly as long as the picture; never trim to the shortest stream (it cut the last four frames once).
- **The AE project audit** (supervised films): the project's settings, comps, footage and render format, as gate results.
- **Loudness** of the master's audio on target.

`slate qa frames loudness psnr` runs them (slate-qa). To compare any two pictures or videos directly,
`slate qa psnr <a> <b>` prints their PSNR, frame for frame.

### Formats inside a master

- ProRes 422 HQ, 10-bit, BT.709, with the mix as 48 kHz, 24-bit PCM: the archival master.
- H.264 with AAC at a high bitrate: the everyday master.
- Colour tags stamped on every stream (primaries, transfer, matrix), so the next tool doesn't guess.

### Loudness targets

The film's format sets its loudness target (−14 LUFS integrated, true peak at or under −1 dBTP, is the common web
target). Platforms differ: some normalize to −14, broadcast wants −23 (EBU R 128) or −24 (ATSC A/85), and one large
platform's −14 is reported but not documented. Choose each destination's target deliberately, verify it with a meter, and
derive a separate mix for a destination that needs a different one rather than re-mastering by hand.

---

## Reference: Renders

### What a final render is

- Each act is rendered on its own, one at a time, with **true motion blur**: every frame drawn 16 times across a
  180-degree shutter centred on the frame, the samples averaged in 16-bit, then encoded as ProRes 422 HQ, 10-bit 4:2:2,
  BT.709, at the film's own rate and size.
- Draft renders use 4 samples (`--draft`).
- Every output is written beside its destination, its frames counted, and only an exact count replaces the act's render;
  a short render is kept aside for a look and reported as refused.
- Renders register in `renders/registry.json` (act, engine, file, frames, samples, SHA-256, when, the bundle's hash).
  The first registered act render locks the film's timeline: after that, re-timing needs the owner's decision.

### The commands

| Command | Does |
|---|---|
| `slate render` | every act, one at a time |
| `slate render --act 3` | one act |
| `slate render --act 3 --from 120 --to 260` | re-render that range (the act's own frames, inclusive) and splice it into the registered render, with proof |
| `slate render --from 900 --to 960` | the same with film frames; Slate finds the acts |
| `slate render --act 3 --out <path>` | a range or act to a file of your choosing, not registered (a review copy) |
| `slate render --resume` | pick up renders that didn't finish, keeping every good chunk |
| `slate render --fresh` | ignore kept chunks |
| `slate render --detach` | queue it and return a job id at once |
| `slate render --engine ae --act 2 --go` | an After Effects act, on the owner's go only |
| `slate render list [--verify]` | what's rendered, moved, missing or unfinished |
| `slate render splice <patch> --act 3 --from F --to T` | splice a patch you rendered yourself, with proof |
| `slate render stills --frames 120,240 --act 3` | review stills from one bundle |
| `slate render stills --frames 120,240 --act 3 --engine web` | the same for an act made with the open web renderer |
| `slate render clean` | leaked bundles, caches, finished chunks, safety copies |

### Chunks and resuming

A render is split into chunks of lossless frames. A chunk with the right frame count, hash and settings is kept; a short
or missing one is rendered again. Chunks are joined into one encode with each join proven by a PSNR scan either side.
So a render interrupted by a dying agent, a sleeping Mac or a crash resumes where it stopped: `slate render --resume`.

### Patches and splices

When one range of an act changes (a fix after review), render only that range and splice it in:
- ProRes is intra-frame, so the splice is a stream copy: nothing else is re-encoded;
- the proof: the frame count, frame hashes at the frames either side of the patch, and PSNR at the edges;
- the previous render is kept aside until the new one is proven and registered.

On the first films, splice joins measured 54 to 93 dB, and untouched frames were bit-identical.

### Engines

| Engine | When | Notes |
|---|---|---|
| `remotion` (default) | acts built with the kit | pinned Remotion; one bundle per film per source hash, reused, then deleted |
| `web` | the open web renderer, where a film uses it | no Remotion licence needed; a local page rendered frame by frame |
| `ae` | acts built in After Effects | whole acts only, `--go` only, never autonomous, AE closed otherwise |

### The queue and the machine

- Any render longer than a small foreground limit goes through the job queue automatically, holding the render slot and
  its disk reservation; `--detach` sends any render there. Follow it with `slate job status <id>` and `slate job log
  <id>`.
- The queue waits while the machine is overloaded (the first films once drove the load to 293 on 14 cores).
- Renders reserve their disk first (ProRes is large: a 6-minute master is about 10 GB) and remove their bundles when they
  end, success or failure. Temporary bundles once filled 14 GB.
- **Renders run on this machine only.** Never on a borrowed machine or the owner's work computer.

### After a render

Run the gates that read the picture: `slate qa frames glitch boundary motion` (slate-qa). Triage every glitch flag;
review the contact sheet yourself.

### For whoever changes the renderer

The default test run never renders. The real end-to-end render tests (Remotion and the web renderer, about 25 seconds
each) run only when asked: `SLATE_TEST_RENDER=1` with the render tests. Run them on a quiet Mac, one at a time.

---

## Reference: Versions and review packets

### The packet

`slate review` builds a review packet for the current version, in the film's `review/` folder:
- **a phone cut** with burned-in timecode and shot id, so a note like "at 1:28, the V sound" maps straight to a shot;
- **a 0.5-second contact sheet** of the whole film, labelled;
- **what changed** since the last version, in plain words;
- **the open questions**, each one decision.

Review cuts can be made straight from the act renders, before the masters, so the owner sees the film early. Other
useful review material: voice-only previews, per-shot half-resolution previews with sound, side-by-side comparisons (two
takes, before and after a fix), and gesture sheets for a character (slate-qa, review-packets.md).

### Where it goes

- The owner's own productions: their Downloads.
- An autonomous agent's films: an iMessage with the phone cut, and a push notification. Never in tests or replay.

### The grade (autonomous films)

An autonomous film is held only after a separate reviewer has graded it: `slate review grade-brief` writes the brief the
reviewer works from, and `slate review grade --verdict pass --notes "…" --by NAME` records the verdict. A revise verdict
holds nothing and feeds the fix plan.

### Notes

1. Log every note **verbatim**, numbered, with who said it and what it supersedes (the tracker's direction changes):
   `slate notes add "the card lands a beat late" --at 00:00:12:05`.
2. Map each timecode to its shot, beat and stage (`slate notes list`, and `slate notes plan` for the targeted fixes).
3. Decide the targeted fix for each (slate, review-and-correct.md): re-voice only changed lines with their neighbours;
   redraw, re-render the range and splice it with proof; re-mix; re-run the gates on what changed; rebuild the master.
4. A note on approved work is a perfecting note: change that exact artifact, keep the rest, and measure the revision
   against the approved version.

### Versions

- Versions are numbered in film.json; each starts with a note of what it's for.
- Each approval records the SHA-256 of exactly what was approved (`slate approve final_cut <file> --by NAME`; a draft
  delivery is never the final cut). Before anything is posted, `slate approved <file>` exits 0 only for those exact
  bytes.
- A delivered version is never overwritten. Superseded material (old takes, old renders, old mixes) goes to the film's
  `archive/` with a line saying what it was and what replaced it; earlier deliveries' copies stay as they were.
- The packet always names its version and what changed since the last one.

### Before sending a packet

- The gates for everything that changed have been re-run, and their status is in the packet (only PASS counts).
- You've watched the phone cut yourself, start to finish, with sound.
- The questions are ones only the owner can answer; everything else is decided and noted.
