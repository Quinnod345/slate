---
name: "slate"
description: "Slate's front door for any video work. Use for any request to make, edit, plan or review a video or film, including explainers, ads, social reels, promos, launch and product videos, brand films, product demos, teasers, logo stings, kinetic type and character-led pieces, cut-downs or new aspects of a film, and delivering or posting a finished Slate film (posting always needs the owner's approval of that exact file). An open request such as \"make a video\" gets one question first (a full production or a quick generated clip?), and a scoped brief goes straight to production. Also use it to pick up a film already in progress. Not for screen-recording an app to check its UI or motion (use video-verifier), styling or embedding a video element in a web page, or making a single still image."
---

> Knowledge-only edition of Slate's `slate` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# Slate

Slate is a film studio any agent can run. Every stage of a film is a `slate` command, every check is a gate, and
everything a film knows lives in its own folder, so any agent in any session can pick up exactly where the last one
stopped. This skill is the front door: it routes the request, runs intake, keeps the goal whole and hands each stage to
its craft skill.

Two words used throughout:
- **The owner** is the person Slate works for. They approve spend, the two sittings, the look, and anything published.
- **The requester** is whoever asked for this film: often the owner, sometimes someone they work with, sometimes an
  autonomous agent working for them.

## 1. Route the request before you run anything

| The request | What you do |
|---|---|
| **Open**: "make a video", "a short video of a paper boat in a storm", no length, format or brand named ("short" isn't a length), and no lane picked | Ask exactly one question, alone in its message: *"Do you want a full production or a quick generated clip?"* Run nothing and write nothing until they answer. Brand, length and format come after. |
| **Scoped**: a length, a format, a brand or a destination is named ("a 45-second launch video for …", "a 15-second 9:16 reel for …'s spring sale, captions burned in") | Straight to production (section 3). Don't ask the lane question. |
| **The quick clip, picked** (at your question, or up front: "a quick generated clip, not a full production") and no brand involved | The fast lane: hand over to Higgsfield's own skills (higgsfield-generate for a clip, higgsfield-video-explainer for a narrated explainer). No `slate new`. Mind the credits (below). |
| **Brand work**, even when it asks for "a quick Higgsfield clip" | Never the fast lane. It's a Slate production (a short express film suits it), and any generated shot runs through `slate gen` on the Cloud API: estimated, ledgered and judged against the brand's references. Say why in one line. |
| **Recording an app** to check its UI, transitions or motion (screen recordings, frame-by-frame QA, jank, flicker) | Not Slate: use video-verifier. Its web path goes through Aside, never another browser. |
| **Not a film**: web work that mentions video (a `<video>` tag, a hero video's CSS), an email, a single image | Not Slate. Do the task as the ordinary job it is. |
| **Post or publish a film** | Only a file the owner approved: its SHA-256 matches their approval and the delivery manifest marks it approved for publishing. Otherwise say which approval is missing, and stop. Slate never posts anything itself. |
| **Live action to shoot, or audio description** | Out of scope in this version. Say so, and offer what Slate can make instead. |

**Credits.** Higgsfield's skills stay installed globally because the owner uses them directly, but outside Slate they
generate on Higgsfield's app credits, a separate pool from the Cloud API balance, and that pool isn't funded by
default. If the fast lane stops for credits, say so plainly and offer a Slate production instead. Inside Slate every
generation runs on the Cloud API. Details and edge cases: [routing](#reference-routing-getting-every-video-request-to-the-right-place).

## 2. Every working session starts the same way

1. **`slate status` first.** In a film folder (or with `--film <id>`) it lists every stage as fresh, stale, missing,
   locked or skipped, the sittings, open questions, locks and the one next command. Outside a film it lists the films
   on this machine. Trust it over your memory and over any summary.
2. **Snapshot the balances**, with one label for the whole session: `slate ledger snapshot --all --session <label>`.
   At the end, run the same `slate ledger snapshot --all --session <label>` again, then
   `slate ledger reconcile --session <label>`, so spend made through the chat connectors is caught. Slate can't read
   Higgsfield's balance itself: if a Higgsfield connector or its skills ran in the session, record that balance at
   both ends too, `slate ledger snapshot --provider higgsfield --balance <n> --session <label>`, with the number from
   the connector or the dashboard.
3. **Read `brief/GOAL.md` and `brief/PRODUCTION.md`.** After any summary or compaction, re-derive the checklist from the
   verbatim request in GOAL.md, never from memory, and assume something was lost until you've checked.
4. **Do the next thing** `slate status` names, with the skill for that stage (section 4).

## 3. Starting a film: intake

Goal fidelity comes first. The dropped requirement is never the headline; it's the aside, the "and also", the second
message.

1. **Capture every ask** in the requester's own words: split on every "and", list, comma and follow-up. Vague asks
   become intent items rather than disappearing. Restate the list back if anything is ambiguous.
2. **Check the brand**: `slate brand validate <brand>`.
   - No pack for the brand: onboarding comes first, before any script (`slate brand init <brand>`, then the
     slate-brand skill). A film looks right only when its look is built from the brand's own design system and a
     motion law measured from reference films; generic looks were rejected four times on the first film.
   - A pack whose four references (truth, look and motion, voice, sound) aren't all approved: finish onboarding with
     `slate brand onboard <brand>` before the script. The neutral `demo` pack is the exception: it exists for trials,
     tests and demos, and its look test rides in the film's pre-production sitting.
   - Autonomous films refuse any brand without all four references approved.
3. **Choose the format** from Slate's templates (reel, ad, explainer, brand film and the rest: [formats](#reference-formats-what-any-video-means-in-practice);
   each is a JSON file in Slate's `formats/` folder, named for the format). The format sets runtime, aspect, pace,
   structure, loudness, captions and safe zones.
4. **Settle mode, generation and budget** ([modes](#reference-the-four-modes), [budgets](#reference-budgets-and-spend)): supervised
   unless the requester says otherwise; generation `rarely` unless they ask for more or none.
5. **Make the film**, with the request verbatim:
   ```
   slate new <film-id> --brand <brand> --format <format> --request "<the request, word for word>" --source "<who asked>"
   ```
   Add `--mode`, `--generation`, `--runtime` or `--aspect` when the brief sets them; `--request-file` takes a long
   request from a file. This writes film.json (clock, size, budget, mode), `brief/GOAL.md` (the request and a checklist
   of every ask) and `brief/PRODUCTION.md`, and starts the film's git history.
6. **Record later messages** the same way, verbatim. GOAL.md names the commands that add a message and mark an ask
   done; done always needs evidence.
7. **Go as far as asked.** When the requester says how far to take it ("as far as the script"), stop there and name
   what comes next, usually the pre-production sitting.

Intake in depth: [intake](#reference-intake-the-brief-in-the-requesters-own-words).

## 4. The production, stage by stage

| # | Stage | Skill | Commands | Who approves |
|---|---|---|---|---|
| 0 | Brand onboarding (once per brand) | slate-brand | `slate brand init`, `slate brand onboard`, `slate analyze`, `slate brand approve` | the owner approves four references |
| 1 | Brief | slate (this) | `slate new` | pre-production sitting |
| 2 | Truth: sources, claims, sample data | slate-story | `brief/truth.json`, `slate script build` | pre-production sitting (claims) |
| 3 | Treatment and script | slate-story | `script/script.json`, `slate script build` | pre-production sitting |
| 4 | Voice: cast or design, then every line | slate-voice | `slate voice cast`, `slate voice design`, `slate voice tts` | shortlist at the sitting |
| 5 | Timing | slate-story | `slate timing` | none: frame-exact or nothing is written |
| 6 | Look test (skipped when the brand's look is approved) | slate-motion, slate-brand | `slate render` of a short test | pre-production sitting |
| 7 | Kit, builders' brief, acts, captures | slate-build | `slate emit-events`, `slate check`, `slate capture ios` | hero moments, in the packet |
| 8 | Generated shots (only where allowed) | slate-generate | `slate plates plan`, `slate gen run` | takes, in the packet |
| 9 | Score, sound and mix | slate-sound | `slate score plan`, `slate mix`, `slate verify` | sound proofs, in the packet |
| 10 | Render with true motion blur | slate-finish | `slate render` | none: gates |
| 11 | Master | slate-finish | `slate master --ae` (supervised, on the owner's go) or `slate master --ffmpeg` | the owner starts the AE finish |
| 12 | Validate and deliver | slate-qa, slate-finish | `slate qa`, `slate deliver` | final-cut sitting |
| 13 | Review and correct | slate-finish, slate-qa | `slate review`, the same gates again | the owner's notes |

`slate make <target>` rebuilds only what's stale, in order. The method behind the table, with every machine gate, is in
[orchestration](#reference-orchestration-running-a-production); the stages are one clock, so a re-voice re-times everything downstream.

**Parallel work.** If you can run sub-agents, build acts in parallel, one builder per act under one brief; otherwise
build them in order. Either way a builder owns only its act's files, gets a first working version of every shot onto
disk fast, and keeps its NOTES.md current (slate-build).

## 5. Sittings, packets and approvals

- **Two sittings block a supervised film.** The pre-production sitting approves the checklist, the claims, the script,
  the voice shortlist and the look test. The final-cut sitting approves the film. Stop and hand over at each one:
  finish the packet, say plainly what's waiting for them, and don't start the next stage.
- **Packets don't block.** Hero moments, generated takes and sound proofs arrive in review packets the owner answers
  when they like; keep working on everything that doesn't depend on them.
- **An approval is bound to exact bytes.** Record each one with the command `slate status` names for it: it stores
  the SHA-256 of what was approved, so a changed file is no longer approved. Approved takes, score takes, plates and the
  final cut are locked by hash and never regenerated without an explicit force and a spend approval.
- **Only a person approves.** Never record an approval on anyone's behalf, never read approval into silence, and never
  treat a REVIEW verdict as a pass. Voices, sound and looks are picked by ear and eye; your measurements only shortlist.
- **Asking for a decision:** name it in one line, then ask a few concrete sub-questions whose answers settle it (their
  situation, their preference in practice, the edge case). If your agent has an interactive question tool, use it.
  Then say which way the answers point, and read free-text answers literally.

More: [approvals](#reference-approvals-sittings-packets-and-the-owners-yes).

## 6. Budgets and spend

- Every paid call goes through Slate's ledger: estimate, budget check, an in-flight row with its request id, then the
  result. `slate budget show` has the month and each film's budget; `slate ledger list` has every paid call.
- A film's budget is a hard stop. 1.5 times is allowed only for marked rework. Spending past it needs the owner's
  recorded yes, and an autonomous film can never raise its own.
- **Slate never buys credits, upgrades a plan or starts a licence.** When a balance runs out, the work stops and asks.
- Replay is the default for tests and demos (`SLATE_FAKE_VENDORS=1`); `--live` spends for real.

Default budgets by format: [budgets](#reference-budgets-and-spend).

## 7. Modes

- **Supervised** (the default): both sittings block; spend past the film's budget asks first; After Effects finishes
  it on the owner's go.
- **Express**: a short film runs straight to a review cut, and every approval is batched into the final-cut sitting.
- **Draft**: no generated plates, a library voice, fewer motion-blur samples. For animatics and quick variants. Never
  delivered as final.
- **Autonomous** (agents working for the owner): approved brands and approved claims only, every generation waits for
  the owner's yes, no After Effects, a separate reviewer grades the cut before it parks, and every output stays "not
  approved for publishing" until the owner approves that exact file.

The full rules: [modes](#reference-the-four-modes).

## 8. The tracker

`brief/GOAL.md` holds the request verbatim and the checklist of every ask; `brief/PRODUCTION.md` holds the asks,
every direction change (numbered and quoted exactly), open questions, revisions, approvals and the status table. Slate
keeps the blocks between its markers current; write anything else around them. Status words mean one thing each:
**done** is verified with named evidence; a proof is not a finished shot. `slate status --write` refreshes the table.
See [tracker](#reference-the-production-tracker-goalmd-and-productionmd).

## 9. Perfect, don't replace

When the owner approves something and adds notes, the notes are perfecting notes. Apply them to that exact artifact,
keep everything else as it was, and check the revision against the approved version by measurement (levels against
the voice, sync, palette). A note that seems to need a new approach gets a question first. Research only fixes a named
flaw; it never becomes a redesign. (One film's sound went off the rails exactly this way: small notes were answered
with a new sound system, and the effects that had stood out ended up buried.) Slate's revise stage, listed in
`slate --help`, turns notes into a checklist of changes to that file and refuses to close while anything else moved.
See [review and correct](#reference-review-and-correct).

## 10. Resilience

A production can run for days and outlive every agent that works on it.
- Everything a film knows is in its folder; `slate status` tells any agent where it stands.
- Long work (renders, masters, word timings, score composition, generation batches) runs as detached jobs in the
  queue: `--detach` returns a job id at once; follow it with `slate job status <id>` and `slate job log <id>`. A dying
  agent, a sleeping Mac or a rate limit doesn't lose it.
- **Nothing prompts.** Research slices are killed after ten minutes with stdin as a pipe, so never start anything that
  waits for input. Keys are typed by a person in their own Terminal with `slate connect`, never in chat.
- Save early and often: a session can end without warning.

See [resilience](#reference-resilience-work-that-outlives-the-agent-doing-it).

## 11. Protections

- **Voices:** designed or library voices by default; the owner's own voice only as a professional clone they verified
  themselves; anyone else's only as a real recording, never a clone, and never a public figure's.
- **People and claims:** no invented testimonials or customer quotes presented as real, and no claim without a source.
- **AI labels:** none unless the law requires one. Slate still records which voices and shots are synthetic, internally,
  and platform rules on realistic AI voices or people are the owner's call per platform.
- **Company material:** company source code is read in place and never copied; brand material goes to a generator only
  when the brand owner allows it.
- **Spend:** never buy, never upgrade, never call a vendor's tool that uploads a user's skills or profile.
- **Browsers:** never open a web browser. Read the web with fetch and search tools; any page that must be driven goes
  through Aside.

The why behind each: [protections](#reference-protections).

## 12. Helpers, vendor skills, licences

- **Optional helpers:** ponder as a QA loop over every shot; visionary for hero moments; goal-fidelity for the
  checklist; asset-creator (vector drawing), canvas-design (frames), frontend-design (component looks) and
  avoid-ai-writing (script polish). None is required; Slate works without them.
- **Vendor skills:** Remotion's and ElevenLabs' skills live inside Slate's engine folder, not globally, and Slate's
  rules override theirs where they disagree. Higgsfield's stay global. Slate never deletes a vendor skill; if one keeps
  winning a request Slate should get, adjust Slate's own trigger with the owner's one-time permission.
- **Code you never copy:** OpenMontage is AGPL, and copying its code would force that licence on Slate. Ideas only.
  Licences in depth: [licences](#reference-licences-what-slate-may-use-and-how).

## Reference files

- [routing](#reference-routing-getting-every-video-request-to-the-right-place): every routing case, the one question, the fast lane and its credits.
- [intake](#reference-intake-the-brief-in-the-requesters-own-words): capturing the brief, re-deriving the checklist, the brand check.
- [formats](#reference-formats-what-any-video-means-in-practice): the format templates and derived films.
- [modes](#reference-the-four-modes): supervised, express, draft and autonomous, rule by rule.
- [approvals](#reference-approvals-sittings-packets-and-the-owners-yes): sittings, packets, what counts as approval, asking for decisions.
- [budgets](#reference-budgets-and-spend): default budgets, the ledger, never buying.
- [tracker](#reference-the-production-tracker-goalmd-and-productionmd): GOAL.md, PRODUCTION.md, status words, direction changes.
- [orchestration](#reference-orchestration-running-a-production): the method as a workflow, parallel builders, production routes.
- [review-and-correct](#reference-review-and-correct): review packets, notes, targeted fixes, versions.
- [resilience](#reference-resilience-work-that-outlives-the-agent-doing-it): detached jobs, sessions that end, files agents read.
- [protections](#reference-protections): voices, claims, labels, company material, spend, browsers.
- [agents-and-connectors](#reference-agents-the-cli-and-connectors): the agents, the CLI, MCP, the chat lane.
- [dependencies](#reference-dependencies-tools-vendor-skills-and-helpers): tools, vendor skills, optional helpers, checking a tool first.
- [licences](#reference-licences-what-slate-may-use-and-how): Remotion, Adobe, Eleven Music, ElevenLabs plans, AGPL code, fonts, sounds.
- [research](#reference-research-sources-you-can-cite-later): reading vendor docs, dated sources, the web without a browser.

`slate guide <topic>` prints these same files for an agent that can't read the skill folder.

---

## Reference: Agents, the CLI and connectors

Slate has one source of truth and many front doors. The same skills, CLI and MCP server serve every agent on the
machine, so behaviour doesn't depend on which agent picked up the request.

### CLI first

Every stage is a command, and every command has `--json` (one object on stdout, logs on stderr) and the same exit
codes: 0 ok, 1 a gate failed or a refusal, 2 usage, 3 a missing prerequisite, 4 spend refused (budget or approval),
5 busy (After Effects open, a job running). Every agent can run a shell command; not every agent can see MCP servers,
so the CLI is the contract and MCP is a convenience. `slate --help` lists the commands and `slate <command> --help`
explains each.

### The agents

| Agent | How it reaches Slate | Worth knowing |
|---|---|---|
| Claude Code | skills in its skills folder, the MCP server, the CLI | It can run sub-agents; when the agent can, acts are built in parallel, otherwise in order. |
| Codex | skills in its agents skills folder, `codex mcp add`, the CLI | Loads AGENTS.md files from its home and from the git root down, concatenated, with a size cap. |
| OpenClaw (and the agents it deploys) | skills in the shared agents folder, its MCP settings, the CLI | Its gateway's PATH may not include the user's local bin, so the CLI is linked where it can see it. Skill env and API-key values reach host runs only, not the sandbox. |
| Research slices (`codex exec` with the user config ignored) | skills and the CLI only; no user MCP servers | Killed after ten minutes, stdin a pipe: everything long is a detached job the slice submits and polls, and nothing ever prompts. |
| A Claude chat or Cowork | a knowledge-only skill; the Slate desktop extension submits jobs | Plans, writes and voices; starts renders only through the extension. |

`slate doctor` checks each agent's context (`--context`) and names anything missing, including a skill listed twice.

### MCP

`slate mcp` is a thin stdio server over the CLI and the job queue. Use it where the agent has it; the CLI does
everything it does.

### Connectors: the chat lane

- **ElevenLabs** and **Higgsfield** each have a hosted MCP connector for chat clients. Both sign in with OAuth in a
  browser, so they're for people in chat, never for pipelines or headless agents, which call the APIs with keys.
- Generations made through a chat connector bypass Slate's ledger. The ledger catches them by reconciling balance
  snapshots at the start and end of each session (budgets.md).
- The ElevenLabs connector also exposes third-party image and video models; generations there bill ElevenLabs credits
  and bypass the ledger too.
- Higgsfield points agents such as Claude Code and OpenClaw to its CLI and skills rather than its hosted connector; its
  CLI bills app credits, the unfunded pool (routing.md).

### On claude.ai

A plugin's skills load in chat and Cowork; agents and hooks load only in Cowork and Code; remote MCP servers appear on
the Connectors tab (authenticated by OAuth, not editable after adding), and local servers load only in a locally
running Cowork session. The claude.ai copy of Slate's skills has its references inlined (`slate skills build`).

### Keys

Keys come from the environment first, then the macOS Keychain. They are set by a person in their own Terminal with
`slate connect`, never typed into chat, never printed, logged, written to a file or put in a URL. A missing key stops
the command with exit code 3 and says which `slate connect` to run.

### Off-limits

Company operations servers (ticketing, internal dashboards, company databases) are not part of Slate and are never
used for film work.

---

## Reference: Approvals: sittings, packets and the owner's yes

People judge what machines can't: the look, the voice, the sound, the hero moments and the final cut. Slate's job is to
put the right thing in front of them at the right time, record their decision against the exact bytes they judged, and
never mistake anything else for a yes.

### The two sittings (they block)

| Sitting | What it approves | What you prepare |
|---|---|---|
| **Pre-production** | the checklist of asks, the claims, the script, the voice shortlist, and the look test when the brand's look isn't approved yet | GOAL.md with every ask; the truth pack and the claims list; SCRIPT.md; a casting reel (slate-voice); a moving 10 to 15 second look test with sound (slate-motion) |
| **Final cut** | the film itself (in express mode, everything above too) | the review packet (`slate review`): the phone cut, the contact sheet, what changed, open questions; every gate's status |

At a sitting: finish the packet, say plainly what's waiting for them and why, and stop. Don't start the next stage
"to save time"; it will be rebuilt if they change their mind.

### Packets (they don't block)

Hero moments, generated takes, sound proofs, voice takes and score takes go into review packets the owner answers when
they like. Keep working on everything that doesn't depend on them. When they answer, record it.

### What an approval is

- **Bound to exact bytes.** Record each approval with the command `slate status` names for that stage. It stores the
  SHA-256 of the file approved, who approved it and their words. Change the file and it's no longer approved.
- **Kinds Slate records:** checklist, claims, script, voice shortlist, look test, final cut (the sittings); hero,
  plate, sound proof, take, score take (packets); and spend (a yes to spend again on something already paid for).
- **Locks follow.** Approved takes, score takes, plates and the final cut are locked by content hash. Regenerating one
  needs an explicit force and a recorded spend approval.
- **Only a person approves.** Never record an approval on someone's behalf, never read approval into silence or a
  thumbs-up on something else, and never treat a REVIEW gate as a pass.
- **By ear and by eye.** Voices, sound and looks are chosen by the owner listening and watching. Measurements shortlist
  and catch faults; they never decide.

### Human approval points across a production

1. The goal and its checklist, in the requester's words.
2. The source of truth for product claims, and later corrections to claims.
3. The script.
4. The production route, when there's a real choice (code, After Effects, generation).
5. The voice, by ear, from a reel or a proof.
6. The sound palette and sound proofs, by ear.
7. The look, from a moving test (stills don't count), grounded in the brand.
8. Hero moments, against the visionary bar.
9. Generated takes, by eye.
10. Spend beyond a balance or a budget.
11. The scope of a fidelity pass: ask "is this the pressing stuff?" before widening one, and record the ruling.
12. The final cut, and each re-delivery after corrections.

An autonomy grant ("don't ping me, just decide") covers creative decisions. It never covers purchases, upgrades,
licences or publishing.

### Asking for a decision

- Name the decision in one short line.
- Ask a few concrete sub-questions whose answers settle it: facts about their situation, what they'd do in practice,
  the edge case. Don't ask the decision itself in the abstract.
- If your agent has an interactive question tool, use it, one screen per decision.
- Afterwards, say in a few lines which way the answers point, flag any conflict between them and how you'll resolve it,
  and invite a correction. Read free-text answers literally; they often carry the real intent.

### Approved work stays approved

- **Work the owner approved is not rebuilt.** Build around it. When something next to it changes, keep its outer
  geometry and timing so it still fits.
- **Perfect, don't replace.** Notes on approved work are perfecting notes. Write them as a checklist of changes to that
  exact artifact, keep everything else as it was, and check the revision against the approved version by measurement.
  If a note seems to need a new approach, ask first. Research only to fix a specific named flaw, never to redesign.
- **How it goes wrong:** notes on an approved sound (a tonal layer that sounded cheap, glides that read as a siren, more
  variation wanted) were answered by replacing the design: a new composed layer, a researched vocabulary, and effects
  pushed from about 11 to 17 LU under the voice down to 25 to 28 LU under it, where they stopped standing out. The owner
  had to point back at the approved proof.
- **A latent bug in approved work** that produced the look they approved stays: record it rather than fix it and change
  approved frames.
- **Retiring a direction:** delete nothing, stop every watcher, leave the files in place, and write a short handover
  listing only the plumbing worth reusing.

---

## Reference: Budgets and spend

Spend is explicit. Every paid call goes through Slate's ledger: an estimate, a budget check, an in-flight row with its
request id written before waiting, then the result. A restart polls the row instead of paying twice.

### The rules

- **Estimate first.** Generations are priced with the vendor's free estimate before anything is submitted; voice and
  music are priced from the registry's per-character and per-second rates.
- **A film's budget is a hard stop.** 1.5 times is allowed only for rework that's marked as rework. Going past it needs
  the owner's recorded yes (`slate budget film --film <id> --raise <n> --approved-by <name>`), which an autonomous film
  can never give itself.
- **Monthly caps per mode** live in Slate's own budget file and are changed only by a person in their own Terminal.
  `slate budget show` has the month and every film's budget.
- **Never buy.** Slate never buys credits, upgrades a plan, tops up a balance or starts a licence. It can say when a
  plan would pay for itself (smallest plan, one month first) and let the person decide. When a balance runs out, the
  work stops and asks.
- **Replay by default in tests and demos** (`SLATE_FAKE_VENDORS=1`); `--live` spends for real.

### Default budgets by format

Hard stops, from what the first three films actually spent. Prices live in `registry.json` with verified-on dates and
move often, so re-check them before a big spend.

| Format | ElevenLabs credits | Higgsfield (Cloud API) | Notes |
|---|---|---|---|
| Reel or ad (6 to 45 s) | voice 500 to 3,000; score 1,000 to 2,000 | $0 by default | Generation only when it's allowed and adds something. |
| Explainer (60 to 120 s) | voice 1,000 to 5,000; score 2,500 to 5,000 | $0 to 60 | 0 to 2 generated shots at about $15 to 30 each, including one reject. |
| Brand film (2 to 6 min) | voice 4,000 to 12,000 (tag A/Bs included); score 9,000 to 28,000 | $40 to 85 | |
| Brand onboarding (once) | Voice Design about 5,000 | $15 to 20 for look tests | The sound reference is made locally. |

For scale: a code-only film spends nothing on generation; a hybrid film with about 40 seconds of generated plates, a
few takes each, spent roughly $8 to 30; an all-generated six-minute cut would be roughly $55 to 95.

### Spend Slate can't see

Generations made in a chat through the hosted connectors (Higgsfield's or ElevenLabs') bypass the ledger. The ledger
catches them by comparing balance snapshots:

```
slate ledger snapshot --all --session <label>        # at the start of a working session
slate ledger snapshot --all --session <label>        # at the end, with the same label
slate ledger reconcile --session <label>
```

`--all` records every balance Slate can read by itself (ElevenLabs'); it skips Higgsfield, which has no balance
endpoint. When a Higgsfield connector or Higgsfield's own skills ran in the session, record its balance at both ends
from the connector's balance tool or the dashboard:

```
slate ledger snapshot --provider higgsfield --balance <n> --session <label>
```

A reconcile that finds unexplained spend is REVIEW, for the owner to look at. A provider with only one snapshot in the
session is UNCHECKED, never a pass.

### Two wallets at Higgsfield

The **Cloud API** balance pays for every Slate generation and is the one funded lane. **App credits** pay for
Higgsfield's CLI, app and hosted connector, including its own skills; that pool isn't funded by default, so the fast
lane may stop for credits. Neither is ever topped up by an agent.

### Watching spend during a film

- `slate ledger list --film <id>` has every paid call for the film; `slate ledger inflight` shows calls still waiting.
- Before a batch (a full voicing, a score, several takes), say what it will cost and what's left of the budget.
- Before spending past an approval (a recomposition, a re-voice of approved lines), try what's on hand first: an unused
  take often measures better than a new one, and costs nothing.

---

## Reference: Dependencies: tools, vendor skills and helpers

What Slate depends on, what it keeps inside its own engine folder, what's optional, and how to check a new tool before
anyone installs it.

### What Slate needs on the machine

`slate doctor` checks all of it and names anything missing; `slate doctor --install` installs the free prerequisites,
asking first. The five connect steps are `slate connect claude`, `slate connect higgsfield`, `slate connect elevenlabs`
and `slate connect aftereffects` (the person runs the sign-ins in their own Terminal).

| Thing | Why | Who sets it up |
|---|---|---|
| ffmpeg and ffprobe, Rubber Band (arm64), uv, Node | encoding and QA, voice pacing, the Python and Node runtimes | the installer, asking first |
| The Whisper model, the Remotion engine and its headless Chrome | word timings, rendering | the installer, asking first |
| GarageBand's sound library | the sampled instruments the sound's tonal roles play | the person, from GarageBand |
| Xcode command-line tools | iOS app captures only | the person |
| After Effects | the AE finish and AE-built scenes | the person |
| ElevenLabs (Creator works; Pro or higher for lossless voice) | voice and score | the person |
| A Higgsfield Cloud API balance | generated shots, when a film allows them | the person |
| Brand fonts | licensed per brand, referenced by name, never shipped | the brand |

### Vendor skills

- **Remotion's and ElevenLabs' skills** are installed inside Slate's engine folder, not globally. Where they disagree
  with Slate, Slate's rules win: Remotion's voice-over skill uses an old multilingual TTS model and settings, its sound
  effects skill points at meme sounds, and its caption skill wants a GPU Whisper; Slate's voice, sound and caption
  stages replace all three. Remotion's Studio never opens a browser.
- **Higgsfield's skills** stay global, because the owner uses them directly, and are installed for Codex and OpenClaw
  too. Outside Slate they generate on app credits (routing.md).
- **The After Effects bridge's skills** are served by the bridge and used as AE looks by name; they're referenced, never
  copied.
- Slate never deletes, edits or copies a vendor skill.

### Optional helpers

None is required; each helps where it fits.

| Helper | Use it for |
|---|---|
| ponder | a converging QA loop over every shot, when a single review pass would miss things |
| visionary | pushing a hero moment past the correct-but-ordinary (the bar in slate-story) |
| goal-fidelity | keeping every ask of a big brief on the checklist |
| video-verifier | recording and checking an app's UI (not film-making); its web path goes through Aside |
| asset-creator | vector drawing: an SVG character, arrows, a diagram |
| canvas-design | static frames and posters |
| frontend-design | component looks for a brand without a design system |
| avoid-ai-writing | polishing a script so it doesn't read as machine-written |

### Checking a tool before anyone installs it

When a tool, MCP server or skill is suggested (by a person, a listing or a search result):
1. Confirm its repository exists and is what the listing says: one listing pointed at a repository that doesn't exist.
2. Check what it really does: does it write files or only play live, does it open a browser, does it need system
   permissions?
3. Check its licence (licences.md): anything copyleft stays out of Slate's code.
4. Record the verdict with reasons in the tracker. Installs that need system permissions go to the owner.

### Pinning

Slate pins what it depends on (Remotion exactly, the AE bridge's version, model ids per film) and upgrades only after a
parity check proves nothing changed. Current model picks live in `registry.json` with verified-on dates, overridable per
film or per user.

---

## Reference: Formats: what "any video" means in practice

A format is a template in Slate's `formats/` folder. It sets the runtime, aspect and size, frame rate, pace, structure,
loudness target, caption defaults, per-platform safe zones and the default budget. `slate new --format <name>` copies
its values into film.json, which is then the one source of the film's clock and size. Nothing downstream assumes a
frame size or rate; everything reads film.json.

| Format | Runtime | Aspect | Notes |
|---|---|---|---|
| Brand film | 2 to 6 minutes | 16:9 | The long form: several acts, a composed score, the AE finish when supervised. |
| Explainer | 60 to 120 seconds | 16:9 (or 9:16) | One idea, told clearly; 0 to 2 generated shots at most. |
| Product demo | 30 to 120 seconds | per destination | Real app captures through `slate capture ios` or `slate capture web`. Capture for truth and speed; rebuild in code when a shot needs camera moves, restaging, motion blur or exact type. |
| Social reel | 15 to 45 seconds | 9:16 | Captions burned in by the renderer in the brand's font. Instagram, TikTok, YouTube Shorts. The autonomous default. |
| Ad | 6, 15 or 30 seconds | 16:9, 1:1 or 9:16 | Every second counts: one idea, one call to action. |
| LinkedIn cut | 15 to 60 seconds | 1:1 and 4:5 | Usually derived from a larger film. |
| Website hero loop | per page | per page | Loops seamlessly; no voice; to the platform's spec. |
| App Store preview | to the store's spec | device | The store's size, length and safe areas. |
| Launch teaser or feature announcement | 10 to 45 seconds | any | A single reveal, often a signature moment and a sting. |
| Kinetic type or logo sting | 3 to 15 seconds | any | Type-led; the editorial look or the logo build. |
| Character-led | any | any | The brand's motif or mark as a character (slate-motion, character-and-motif-motion). |

The format files are the source of truth for exact values; this table is the overview.

### Derived films: cut-downs, aspects and languages

A cut-down, a new aspect or a new language is a **derived film** with a parent. It reuses the parent's approved takes,
timings, beats and assets by reference (nothing is copied), keeps the parent's clock, re-stages its layout with its own
type scale and safe zones, re-plans its sound, runs every gate, and needs its own approval:

```
slate new <child-id> --brand <brand> --format <format> --parent <parent-id> --derivation '{"aspect": "9:16"}'
```

Other derivations: `{"cut_s": 15}` for a cut-down, `{"language": "fr"}` for a new language (v1 speaks English; the
code carries no English literals, so languages arrive as data). See slate-finish, derived-films.md.

### Variants by channel

- **Hero placements** (website, App Store, YouTube masters) are derived films at master quality, through the whole
  pipeline.
- **Social cut-downs** (Instagram, TikTok, Shorts, LinkedIn) can take a faster route. A faster engine is kept only if a
  benchmark on the same film shows it's genuinely faster at acceptable quality.

### Choosing when the requester didn't say

- A length and an aspect usually settle it; a destination ("for our App Store page") settles the rest.
- If only the destination is known, ask the one missing thing (length, or who it's for).
- An autonomous run with no format gets the 15 to 45 second 9:16 reel.
- Broadcast destinations (film, TV, radio) flag the composed score: Eleven Music's terms need an Enterprise plan there
  (licences.md).

---

## Reference: Intake: the brief, in the requester's own words

Intake turns a request into a film folder with the goal written down exactly as it was asked. Everything later is
checked against that record, so it has to be complete and verbatim.

### 1. Capture every ask

Big requests get half-delivered when one ask quietly drops out. It's almost never the headline; it's the aside, the
subordinate clause, the "oh, and also" at the end, the second message an hour later.

- Split the request on every "and", "also", "plus", list item and comma-separated clause.
- Write implied deliverables out: "a reel with captions for Instagram and TikTok" is a reel, burned-in captions, and
  two platforms' safe zones.
- Keep vague asks as intent items ("make it feel less corporate") instead of dropping them because they aren't crisp.
- Carry open threads: a question the requester asked that nobody has answered yet is an ask too.
- If anything is ambiguous, restate the list back so they can correct it.

### 2. Write it down verbatim

```
slate new <film-id> --brand <brand> --format <format> --request "<the request, word for word>" --source "<who asked>"
```

- `--request` takes the words exactly as they arrived, typos included. `--request-file <path>` reads a long one.
- `brief/GOAL.md` then holds the request, a checklist row per ask (auto-split rows are flagged for you to check) and the
  settings rows (format, brand, budget, mode). `brief/PRODUCTION.md` is the live tracker (see tracker.md).
- Every later message that adds or changes an ask goes in verbatim too, with who sent it. GOAL.md names the command.
- If the original request was cut off or summarized away, say so in the tracker, and mark any ask you rebuilt from
  follow-ups as reconstructed.

**After any summary or compaction, re-derive the checklist from the verbatim request, never from memory.** Summaries
drop sub-requirements; assume something was lost and go find it.

### 3. Check the brand

`slate brand validate <brand>` reports the pack and which of its four references are approved.

| What you find | What happens |
|---|---|
| No pack for this brand | Onboarding first (`slate brand init <brand>`, then slate-brand). No script before it. |
| A pack with references still unapproved | Finish onboarding (`slate brand onboard <brand>`) before the script. |
| The neutral `demo` pack | Go ahead: it's for trials, tests and demos; its look test rides in the film's pre-production sitting. |
| All four references approved | Go ahead. The film's look test is skipped; later work is checked against the references. |

For a brand the owner doesn't own, onboarding names a claim authority there: the person who rules on claims and brand
use for that company. "A video for <company>" means that company's film, with their approvals.

### 4. Choose the format and the settings

- **Format** (formats.md): it sets runtime, aspect, pace, structure, loudness target, caption defaults and each
  platform's safe zones. The runtime stays within 10% of the target unless the requester asks otherwise or you justify
  it in the tracker.
- **Mode** (modes.md): supervised unless the requester chose otherwise. Autonomous runs are for agents working for the
  owner, on approved brands only.
- **Generation**: the requester decides how much generated footage they want: `none`, `rarely` (the default) or
  `where-it-helps`. Code builds anything designed either way.
- **Budget**: the format's default (budgets.md) unless the requester set one. It's a hard stop.
- **Language**: English in this version. The clock, captions and transcripts carry no English literals, so other
  languages come later as derived films.

### 5. Inputs

Copy attachments (an original film to remake, reference films, a script, brand files) into the film folder, for example
`brief/inputs/`, so later stages have stable paths. Record where each came from. Never move or edit the originals, and
never copy company source code: read it in place (slate-story, truth.md).

### 6. Before the first stage

- Run `slate status`: it names the next command (usually the script).
- The script comes from slate-story. The pre-production sitting waits for the checklist, the claims, the script, the
  voice shortlist and, when the brand's look isn't approved, the look test.
- When the requester says how far to go ("take it as far as the script"), stop there and say what's next.

### Asking what intake can't proceed without

Ask as few questions as the work allows, one decision at a time. For a real decision, name it in one line and ask a few
concrete sub-questions whose answers settle it: facts about their situation, what they'd prefer in practice, the edge
case. If your agent has an interactive question tool, use it. Then say which way the answers point, flag any conflict
between them, and read free-text answers literally: they often carry the real intent.

---

## Reference: Licences: what Slate may use, and how

Facts as researched on 2026-09-30. Terms change, so re-check before a film is published commercially, and say which
terms you checked and when.

### Remotion

- Free for individuals, for for-profit organisations of up to three people, for non-profits and for evaluation,
  commercial use included. It's source-available, not open source, and it forbids selling a derivative of Remotion.
- Company tiers: Creators (per seat, per month), Automators (per render, with a monthly minimum) and Enterprise.
- Remotion's own FAQ puts a person writing Remotion code, directly or through agentic tools, under Creators, and
  automated pipelines, prompt-to-video tools and the Player under Automators. An unattended agent rendering on its own
  looks like Automators.
- For licensing, one render is one successful video, audio, GIF, still or PDF; Studio previews and the Player don't
  count.
- Remotion's coming v5 terms require a licence once the people operating it, across all involved parties (contractors
  included), reach four; receiving finished media isn't use.
- It allows a service that generates Remotion code with AI and renders it, but not one where end users upload their
  own Remotion code to be rendered.
- **How Slate uses it:** installed through npm, pinned exactly, never redistributed. Each organisation that runs it
  needs its own licence status, and Slate is never sold as a Remotion derivative. Companies of four or more should get
  their own licence or use the open web renderer or After Effects, which need none.

### After Effects (Adobe)

- Adobe's enterprise terms bar operations a person didn't start. Until the owner's own licence terms are checked, Slate
  treats that as the rule: every AE step starts on a person's go, and autonomous films never touch AE.
- Unlimited render engines are allowed on an intranet with one full AE install; Media Encoder can't serve as a hosted
  encoder.

### ElevenLabs and Eleven Music

- Output from paid plans is licensed for commercial use; free-plan output can't be used commercially at all, and output
  from beta services can't be used commercially on any plan.
- Eleven Music: online commercial use is fine on paid plans; film, TV and radio need an Enterprise plan. Slate flags a
  score on any broadcast format.
- Designed voice ids belong to the account that made them and don't transfer.

### Higgsfield

- Cloud API output is for the account holder's use under Higgsfield's terms. Record the model, request id and cost of
  every generation in the film's records.

### Sounds and fonts

- **Apple's sound content** (GarageBand, Logic, Final Cut Pro libraries) is licensed for productions made with Apple's
  apps. Slate builds from each machine's installed content and never redistributes a sample or a bank.
- **Brand fonts** are licensed per brand. Reference them by installed name, kit or Google Fonts family, with the licence
  noted; never commit font files, and never fetch a brand's licensed fonts from its web kit into a third-party sandbox.
  A web font kit may serve only allowed domains and load online during renders; in After Effects the same fonts must be
  activated or installed separately.

### Code Slate never copies

- **OpenMontage** is AGPL-3.0: copying its code would force the AGPL on Slate. Ideas only.
- Any other copyleft code the same way; permissive code (MIT, Apache-2.0) only with its notice kept.
- Company source code is never copied at all (protections.md).
- Vendor skills are depended on and pinned, never vendored into Slate.

### Recording what you checked

When a film's use of something depends on terms (a broadcast score, a company film on Remotion, a platform's AI-label
rule), write the terms you relied on and the date into the tracker, and flag it to the owner rather than deciding it.

---

## Reference: The four modes

A film's mode is in film.json (`slate new --mode`). The CLI enforces each mode's rules whatever an agent intends:
refusals come back with exit code 1 (refused) or 4 (spend refused) and say why.

### Supervised (the default)

- **Two sittings block:** pre-production (the checklist, the claims, the script, the voice shortlist, the look test)
  and the final cut. Stop at each and hand over.
- **Packets don't block:** hero moments, generated takes and sound proofs arrive in review packets the owner answers
  when they like.
- **Spend past the film's budget asks first.** The budget is a hard stop; the owner can record a raise.
- **After Effects finishes the film**, as an editable project plus the masters, and only on the owner's go. Ask them
  to save and quit AE before masters render; never quit it for them.

### Express

- A short film runs straight through to a review cut.
- Every approval that would have blocked earlier (checklist, claims, script, voice, look) is batched into the final-cut
  sitting. Nothing is skipped; it's just asked once, at the end.
- Use it for short pieces where the requester wants to see something before deciding anything.

### Draft

- No generated plates, a library voice, fewer motion-blur samples (4 instead of 16).
- For animatics, quick variants and trying an idea.
- **Never delivered as final.** A draft that becomes the real thing leaves draft mode and goes through the gates again.

### Autonomous (agents working for the owner, such as Oneiro's pursuits)

- **Brands:** only brands whose four references are approved.
- **Claims:** only from the brand's approved-claims list. A new claim parks the film with a question for the owner.
- **REVIEW verdicts park the film** with their evidence, and never count as passes. Only a person releases it.
- **Spend** is capped monthly in Slate's own budget file, which the CLI enforces whatever film.json says, and backed by
  vendor caps: a separate ElevenLabs key for autonomous work, with its own credit quota. An autonomous film can't raise
  its own budget.
- **Every generation waits for the owner's yes**, asked by iMessage, recorded, and passed to the run as an approval id.
- **No After Effects.** Autonomous films are mastered with ffmpeg and held. The owner can start the AE finish when they
  approve a held film.
- **Voices:** the owner's own professional clone is the only clone it may use.
- **Default output:** a 15 to 45 second 9:16 reel.
- **Before parking,** a separate reviewer agent grades the contact sheet and the audio against the brand's references,
  the owner's taste notes and the visionary bar (slate-qa, reviewer-agent.md).
- **Not approved for publishing:** every output says so in its manifest until the owner approves that exact SHA-256.
  After their yes, the agent posts that exact file through its own committing path, and never any other version.
- **Denied tools:** publishing through a vendor connector (TikTok, website publishing) and any tool that uploads the
  user's skills or a personality profile to a vendor.
- **Held films and questions** reach the owner by iMessage, with the phone cut, and as a push notification.

### Choosing a mode

| Situation | Mode |
|---|---|
| The owner (or someone they work with) is making a film and wants to steer it | supervised |
| A short piece, and they'd rather react to a cut than approve a script | express |
| Trying an idea, an animatic, a variant to compare | draft |
| An agent working on the owner's behalf, on an approved brand | autonomous |

---

## Reference: Orchestration: running a production

The production method is a workflow with blocking human approvals. docs/METHOD.md in the Slate repo has the full table;
this is how to run it well.

### The shape that worked

1. **Goal first.** The request verbatim and a checklist of every ask (intake.md).
2. **Toolchain proven** before anything expensive: `slate doctor` goes green, or names what's missing.
3. **Reference analysis** when there's an original film or reference films: `slate analyze <video>` (transcript,
   scenes, measured eases).
4. **Truth**: pinned sources, the claims list, sample data (slate-story).
5. **Motion law**: the brand's, from onboarding (slate-brand, slate-motion).
6. **Treatment and script as data**, through the script gates (slate-story).
7. **Voice by ear**, then every line, then timing from the real reads (slate-voice, slate-story).
8. **Look test** if the brand's look isn't approved (slate-motion).
9. **Kit first, then the builders' brief**, then the acts (slate-build).
10. **Generated shots** only where allowed and code can't do the job (slate-generate).
11. **Sound and score**, then the mix (slate-sound).
12. **Central finals**: renders, the AE assembly and masters (slate-finish).
13. **Validation** (slate-qa), **delivery**, and **the review loop**.

### Parallel production

If you can run sub-agents, build acts in parallel; otherwise build them in order. The parallel shape that worked:
- act builders who each own only their act's files, under one layered brief;
- one sound designer working in parallel from the builders' exported beats;
- a separate, timeboxed track for any alternative approach being tested;
- finals and sound done centrally, one at a time, never by the builders.

Research can be delegated the same way (if you can run sub-agents; otherwise do it in turn): a character's philosophy
into a voice brief, a motion spec from real references, a capability brief where every line carries a source. Every
delegated brief says what to return and where every claim came from.

### Choosing the production route

Before building, compare the candidate routes for the film (built in code with the Remotion kit, built in After
Effects, the open web renderer, generation for real-world shots), recommend one, and timebox a test of the strongest
alternative if it's a close call. Record the choice and the owner's approval. The engine can be chosen per brand or per
act during look development.

### One clock

Every beat is keyed to the voice's words, and picture and sound read the same resolved timeline. So a full re-voice
re-times the film automatically; the renders and the mix still have to be rebuilt, and `slate make <target>` rebuilds
only what's stale, in order. `slate make all` goes through to delivery; `slate make --list` shows each node's state
without running anything.

### Keeping intention across parallel versions

Intentionality degrades when several films or acts are built at once. Tie every move to a word or an idea, prefer fewer
and better moves, and judge new work against the best earlier film's code and notes. Hold masters until the pass is
done.

### Machines

- Render locally, one heavy job at a time, through the queue. Never on a borrowed machine or the owner's work computer.
- Too much parallel rendering thrashes a Mac: six builders plus finals once drove the load to 293 on 14 cores. The
  queue's per-resource locks and its load guard exist for this.
- Keep heavy media out of cloud-synced folders; films live in `~/Movies/Slate/` by default for that reason.
- Never edit a shell script while a job is running it (zsh reads scripts incrementally).
- One copy of any MCP client at a time: two copies ran every action twice.

### Evaluating a suggested tool

When someone suggests a library, an MCP server or a skill, check it quickly and record the verdict with reasons: does
the repository exist, does it do what it claims, does it write files or only play live, would it open a browser, does
it need system permissions (those installs go to the owner)? See dependencies.md.

---

## Reference: Protections

These hold in every mode, for every brand, whatever a request says. Most are enforced in code, so a refusal is the CLI
doing its job: read the message, tell the person, and don't look for a way around it.

### Voices

- **Designed or library voices by default.**
- **The owner's own voice** may be an ElevenLabs professional clone, which the owner verifies with ElevenLabs
  themselves. An agent never does that verification step and never enters their credentials.
- **Anyone else's voice** only as a real recording, never a clone, and never a public figure's.
- Autonomous agents may use the owner's own clone; their films are still held for the owner.
- Never ship audio of a brand's character voice as a demo outside its films.

### People and claims

- No invented testimonials or customer quotes presented as real. That's also the law.
- No claim without a source, and no number on screen or in the voice without one (slate-story).
- Generated people on screen need the requester's sign-off, and a generated shot never implies a claim or testimonial.
- Sample data is labelled as sample data on every frame that shows it.

### AI labels

- None unless the law requires one.
- Slate still records which voices and shots are synthetic in each film's manifest (internal only), so it's clear when
  a law does apply.
- Platforms such as TikTok, YouTube and Meta have their own rules that can require labels on realistic AI voices or
  people. Mention that once when it's relevant; whether to follow them is the owner's call per platform.

### Company material

- Company source code is read in place, on the machine that holds it, and never copied anywhere else. Cite `path:line`
  at a pinned commit instead.
- Brand, UI and video material goes to a generator only when the brand's owner allows it (the pack's grounding
  setting). Credentials are never uploaded, printed or written to a file.
- Only generic design queries go to third-party inspiration services; no brand or product material leaves that way.
- Company brand packs never enter Slate's repository; they live in a separate brand store on the owner's machine.
- Company-internal tools and servers are off-limits to Slate.

### Spend and uploads

- Slate never buys credits, upgrades a plan, tops up a balance or starts a licence.
- Slate never calls a vendor tool that uploads a user's skills or builds a personality profile from them.
- Autonomous runs never publish through a vendor's connector (TikTok, website publishing).

### Publishing

Nothing publishes itself. Every output is marked "not approved for publishing" in its manifest until the owner approves
that exact file's SHA-256. After their yes, the requester (or their agent) posts that exact file and never another
version.

### Browsers

- Never open a web browser: no `open <url>`, no Safari, Chrome, Dia or Arc, no Playwright, no browser pane.
- Read the web with fetch and search tools. Any page that must be driven (a web capture, a live check) goes through
  Aside, the one approved browser.
- Every child process Slate starts runs with `BROWSER=none`; the Remotion engine never opens its Studio in a browser.
- Vendor sign-ins that open a browser are run by the person in their own Terminal (`slate connect higgsfield` prints
  the command for them).

### After Effects

- AE steps start only on a person's go, and autonomous films never touch AE.
- AE's preferences are changed only by Slate's byte-safe tool, with AE closed, and the scripting-security preference is
  never touched. Never quit AE for the owner (and never "without saving"); ask them to save and quit.

### Machines

Renders run locally. Never on a borrowed machine or the owner's work computer, and never on a shared render farm the
owner hasn't set up for it.

---

## Reference: Research: sources you can cite later

Slate's craft rules came from research that cited its sources, and the rules held because the sources could be
re-checked. Do research the same way.

### Reading the web

- Read pages with fetch and search tools. Never open a web browser. When a page must be driven (a login, a script that
  only renders in a browser, a capture), use Aside.
- Read vendor documentation as its official Markdown when the vendor offers it (a docs site's `llms.txt` usually says
  how: often the page path plus `.md`), so quotes are verbatim.
- Keep a dated source list with every research note: title, URL, when you read it, and a short label to cite it by.
- Quote sparingly and exactly; paraphrase the rest in your own words.

### Checking claims about tools and models

- Check the best current models against the live API (its models list or schema) at the start of a project; model
  catalogues and prices move weekly.
- Check that a tool's repository exists and does what the listing claims before recommending it (dependencies.md).
- Re-check a vendor catalogue before assuming a gap still exists (a model family that was missing last month may be
  there now).
- Measure before trusting a new metric: check it against the owner's ear or eye on takes they've already judged.

### Research that feeds a film

- **Truth research** (claims, the product's real screens, numbers and words) lives in the film's truth pack and cites
  a pinned source for everything (slate-story).
- **Reference films** are analyzed with `slate analyze <video>`: a method table, what ran, what came out, so the results
  can be re-derived (slate-brand).
- **Motion and voice research** (how good marks move, how a voice should sound) produces a sourced spec or brief, cited
  by label; the sources stay with it.

### When research is the wrong move

Research fixes a specific, named flaw. It is never a way to redesign approved work. When the owner approves something
and adds notes, apply the notes to that exact thing; if a note seems to need a new approach, ask first
(review-and-correct.md).

---

## Reference: Resilience: work that outlives the agent doing it

A production can run for days. Agents get cut off by rate limits, sessions end without warning, Macs sleep, and
research slices are killed after ten minutes. During the first films one rate limit stopped eight agents at once, and
a builder lost work that wasn't on disk yet. Slate is built so none of that loses anything.

### The film folder is the memory

- Everything a film knows is in its folder: film.json (clock, size, pins), film.lock.json (what made each file, from
  which inputs), approvals, the brief, the gates' results, the renders registry.
- `slate status` reads only the folder, so any agent in any session sees the same truth. Start every session with it.
- Pins make week three match week one: the voice, model, settings, seeds and request ids are recorded at first use, and
  a registry refresh never changes a pinned film. Re-pinning is explicit, tested and approved.

### Long work runs as detached jobs

- Renders, masters, word timings, score composition, generation batches and full QA passes go through the machine-wide
  job queue. `--detach` returns a job id at once; the job runs under caffeinate, in its own session, and resumes by
  frame, line or act after a crash.
- Follow a job with `slate job status <id>` and `slate job log <id>`; stop one with `slate job cancel <id>`.
- The queue holds one lock per resource (render slots, After Effects, each vendor's concurrency, disk), and supervised
  films outrank autonomous ones. Never work around it by running a second heavy process yourself.
- Every paid call writes an in-flight ledger row with its request id before waiting, so a restart polls that request
  instead of paying twice.
- Each job reserves its disk first and stops safely before the disk fills.

### Nothing prompts

- Some agents run with stdin as a pipe and are killed after ten minutes. Never start anything that waits for input, and
  never leave a command running in the foreground that outlives your turn; queue it.
- Keys are typed by a person in their own Terminal (`slate connect elevenlabs`, `slate connect higgsfield`), never in
  chat and never by an agent. A missing key is exit code 3 with the command for the person to run.
- A vendor rate limit sends the job back to the queue to retry later, not into a loop.

### Save early and often

- Get a first working version of every shot onto disk fast, then refine. A placeholder act renders from day one, so the
  whole film always plays.
- Keep NOTES.md current as you go (slate-build): decisions, restaging, what's left. The next agent reads it.
- Commit small, often: the film folder is a git repository for its small files (heavy media is ignored).

### When a decision changes, change the notes too

When a standing decision changes (where renders run, which voice, which sound design), update or retire every memory
note, tracker line and doc that states the old rule. On the first films, two notes still sent renders to a machine that
had been retired, and an agent that trusted them would have followed them.

### Don't pull the floor out from under other agents

- Never move, rename or archive files that running agents read. Clean up only after the builders finish, and archive
  with a note.
- Give each parallel builder its own scratch folder; they overwrite each other's otherwise.
- One heavy process at a time on a machine; the queue enforces it.

### Handing over

When you stop (a sitting, the end of a session, a blocker):
- run `slate status --write` so PRODUCTION.md shows where things stand;
- take the closing ledger snapshot and reconcile (budgets.md);
- say plainly what's done (with evidence), what's in progress (with job ids), and what's waiting on whom.

---

## Reference: Review and correct

Every version gets a review packet, every note gets logged verbatim, and every fix is targeted: change what the note is
about, prove nothing else moved, and re-run the same gates.

### The review packet

`slate review` builds a packet for the current version:
- a phone cut with burned-in timecode and shot id, so a note like "at 1:28" maps to a shot;
- a 0.5-second contact sheet of the whole film;
- the list of what changed since the last version;
- the open questions.

It goes wherever the owner watches: their Downloads for their own productions; for an autonomous agent's films, an
iMessage with the phone cut plus a push notification.

### Logging notes

- Every note is logged verbatim as a numbered direction change, with who said it and what it supersedes (tracker.md).
- Map each timecode to its shot, beat and stage before touching anything, and say where the fix lands.
- A note on approved work is a perfecting note: it becomes a checklist of changes to that exact artifact (below).

### Targeted fixes

| The note is about | The fix |
|---|---|
| A line's words or delivery | Re-voice only the changed lines, with their neighbouring lines as context, at the same delivery (slate-voice). Every beat is keyed to words, so timing follows. |
| A picture detail | Redraw it in its act, re-render only the affected range and splice it in with proof: frame hashes and PSNR at the edges (slate-finish). |
| Sound | Adjust the sound itself, re-mix, re-verify (slate-sound). |
| A claim or a word on screen | Correct the script and the truth pack first, then the picture and the voice, then re-run the claims and banned-word gates. |

After every fix: re-run the gates on what changed (`slate qa` with the gates that cover it), rebuild the master when
picture or sound changed, and rebuild the packet.

### Perfect, don't replace

When the owner approves something and adds notes:
1. Write the notes as a checklist of changes to that exact artifact. Slate's revise stage (in `slate --help`) records
   them, snapshots the approved version and hashes everything else.
2. Keep everything else as it was.
3. Check the revision against the approved version by measurement: levels relative to the voice, sync, palette, and
   that nothing outside the checklist changed.
4. A note that seems to need a new approach gets a question first. Research only fixes a named flaw.

### Versions

- Versions are numbered. Each approval records the SHA-256 of what was approved.
- A delivered version is never overwritten: the next one is a new version, and superseded material goes to the film's
  `archive/` with a line saying what replaced it.
- The review packet always says which version it is and what changed since the last.

### Scope

Before a wide fidelity pass ("make everything match the product"), propose its scope and ask whether it's the pressing
stuff. Core surfaces must match exactly; secondary ones only need to feel right unless something is plainly wrong.
Record the ruling in the tracker.

---

## Reference: Routing: getting every video request to the right place

Slate claims any request to make, edit, plan or review a video. Higgsfield's skills also claim "make a video", so the
front door has to win the request and then send it to the right lane. Routing evals check this in every agent (Claude
Code, Codex, a pursuit slice, OpenClaw): open requests get the question, scoped briefs load Slate, UI recordings still go
to video-verifier, and unrelated requests never load Slate.

### What counts as a video request

Explainers, ads, social reels, promos, launch and feature announcements, teasers, product demos, brand films, website
hero loops, App Store previews, kinetic type, logo stings, character-led pieces, cut-downs and new aspects of a film,
voice-overs and captions for a film, a review of a cut, and delivering or posting a finished film.

What doesn't count, even when the word "video" appears:
- styling, embedding or debugging a `<video>` element or a hero video's CSS (ordinary web work);
- recording an app or site to verify its UI, transitions or motion (video-verifier's job);
- an email, a document, a single still image, a standalone thumbnail for someone else's video.

### The one question

An **open** request names no length, no format, no brand and no destination, and doesn't pick a lane: "make a video",
"can you make me a short video of a paper boat in a storm?", "I need a video about our app".

- Ask exactly one question, and nothing else in that message:
  *"Do you want a full production or a quick generated clip?"*
- Don't run any command and don't write any file before the answer. Not `slate new`, not a draft script.
- Don't bundle the brand, length or format into the same message; they come next, once the lane is chosen.
- One line of context is fine if it helps them choose: a full production is scripted, voiced, designed, scored and
  checked, and takes sittings; a quick clip is one generated shot in minutes, with no script or brand checks.

After the answer:
- **Full production:** intake (SKILL.md section 3). Now ask what's missing: the brand, the length or format, where it
  will be shown.
- **Quick clip:** the fast lane (below), unless a brand turns out to be involved.

### Scoped briefs go straight to production

A request is scoped when it names any of: a length ("45-second"), a format or aspect ("a 9:16 reel", "a 6-second ad"),
a brand ("for the demo brand", "for our company"), a destination ("for our App Store page", "for LinkedIn"), or when it
comes with a script, storyboard or approved plan. Examples:
- "make a 45-second launch video for <brand>";
- "cut a 15-second 9:16 reel for <brand>'s spring sale, with the captions burned in";
- "turn this script into an explainer".

Don't ask the lane question for these, and don't mention a quick clip at all. Go to intake. Ask only what intake can't
proceed without, and ask it as its own question.

### The fast lane

The fast lane is Higgsfield's own skills: **higgsfield-video-explainer** (a narrated, non-photoreal explainer built from
10-second blocks with one style key) or **higgsfield-generate** (a single generated clip). Use it only when:
1. the requester picked it, at the question or up front ("a quick generated clip please, not a full production"); and
2. no brand is involved.

Once picked, don't ask the question again and don't make a Slate film (no `slate new`). Hand over to the Higgsfield
skill and let it run.

**Credits.** Outside Slate, Higgsfield's skills generate through its CLI, which bills app credits: a separate pool from
the Cloud API balance Slate uses, signed in by the owner in their own Terminal. That pool isn't funded by default. If the
CLI reports no credits or no sign-in, don't try to fix it (never buy credits, never run a browser sign-in from an agent):
tell the requester, and offer the same shot as a small Slate production, where a generated shot runs on the Cloud API
with an estimate first.

**Never for brand work.** A brand's film goes through Slate even when the ask says "a quick Higgsfield clip for
<brand>'s launch". Stylized generated clips aren't the brand's type, colour or real UI, and the fast lane skips truth,
claims, the ledger and take judging. Say that in one line, then run a short production: express mode suits it, with
`--generation where-it-helps` when the requester wants generated footage.

### UI recordings go to video-verifier

"Screen-record the sign-up flow in the Simulator and check the transitions frame by frame" is QA of an app, not a film.
Load video-verifier, not Slate. Its web recordings go through Aside, never another browser.

A **product demo film** that uses real app footage is Slate's: the footage comes from `slate capture ios` or
`slate capture web`, conformed to the film's clock and beat-mapped to the voice (slate-build).

### Editing and reviewing

- **Editing a Slate film:** notes on approved work are a revision of that exact artifact (perfect, don't replace); a
  cut-down, a new aspect or a new language is a derived film (slate-finish).
- **Editing an outside video:** `slate analyze <video>` breaks it down (transcript, scenes, measured eases); then either
  rebuild it as a Slate film or, for a trivial trim, make the trim and say that's all it was.
- **Reviewing a cut:** a Slate film's review packet comes from `slate review`; an outside film gets `slate analyze` and
  the review checklist in slate-qa.

### Posting and publishing

Nothing publishes itself. A request to post a film is refused unless the owner approved that exact file: its SHA-256
matches their approval, and the delivery manifest marks it approved for publishing. When either is missing, say exactly
which approval is missing and stop. Don't upload it anywhere, don't open a site to post it, and don't take any other
committing action on the requester's behalf.

### Out of scope in this version

Shooting live action, and audio description. Say so, then offer what Slate can make: a film from real app captures,
generated real-world shots where the generation setting allows, or captions and a transcript.

### When a vendor skill keeps winning

If Higgsfield's (or any vendor's) skill keeps taking requests Slate should get, adjust Slate's own trigger (the skill
descriptions), with the owner's one-time permission, and re-run the routing evals. Never delete or edit a vendor skill.

---

## Reference: The production tracker: GOAL.md and PRODUCTION.md

Two files in every film's `brief/` folder keep the goal whole across days, sessions and agents. They're written in the
requester's own words, so nobody has to remember what was asked.

### brief/GOAL.md: the goal

- **The verbatim request**, exactly as it arrived, with who sent it and when.
- **The checklist**: one row per ask, in the requester's words, with its status and evidence; plus the brief's settings
  (format, brand, budget, mode, generation).
- **Later messages**, verbatim, each with what it added or changed.
- The rule at its top: if a conversation is summarized, re-derive the checklist from the verbatim request, not from
  memory.

### brief/PRODUCTION.md: the live tracker

- **Asks**, in the requester's words, with status and evidence.
- **Direction changes**, numbered and quoted exactly, each saying what it supersedes. The latest approval governs:
  when a direction change contradicts the plan, the change wins, and the tracker says so.
- **Questions waiting for a person**, and their answers.
- **Revisions** (perfect, don't replace): each note on approved work, as a checklist of changes to that artifact.
- **Approvals**, with who approved what and its SHA-256.
- **Status**: one row per stage from `slate status` (`slate status --write` refreshes it).

### Keeping them current

- Slate keeps the blocks between its `slate:` markers current. Write your own notes around the markers, never inside
  them; anything inside is regenerated from the film's records.
- GOAL.md names the commands that record a later message, mark an ask done (with evidence) and log a direction change.
  Use them rather than editing the tables by hand, so the records and the Markdown agree.
- Record the owner's calls on each script draft (trims, keeps, confirmations) as numbered decisions, with their words.

### Status words mean one thing each

| Word | Meaning |
|---|---|
| **done** | verified, with the evidence named (a gate result, a file, a measurement, the owner's words) |
| **built** | made, but not through its gates yet |
| **in progress** | being worked on now |
| **open** | not started |
| **blocked** | waiting on something, with the reason |

A proof is not a finished shot. A shot is done only when it's built, rendered, through its gates and, where a person
judges it, approved.

### Before you say the film (or a stage) is finished

Re-read the requester's original words in GOAL.md, not your summary and not the checklist alone. Walk every ask: is it
genuinely delivered and verified? Anything partial or untouched isn't done; keep going, or say plainly what's left and
why. Report the result against each ask.

### Other records worth keeping

- **Notes on each act** live with the act (slate-build): decisions, restaging, what couldn't be done.
- **Superseded material** stays in the film's `archive/` with a line saying what it was and what replaced it; a
  delivered version is never overwritten.
- **When a decision changes** (say, where renders run), update or retire every note and doc that states the old rule,
  so nobody follows it later.
