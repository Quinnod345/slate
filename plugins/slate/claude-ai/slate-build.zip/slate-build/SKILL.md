---
name: "slate-build"
description: "Build a Slate film's scenes with the kit, act by act. Covers kit-first foundations, act scaffolds and placeholders (a first working version of every shot, fast), beats keyed to the voice's words, frame-exact contracts between acts, exporting visual events, the hand-in check, stills and previews, briefs for parallel act builders, real app captures for a film, product UI drawn truthfully, and acts built in After Effects. Use when writing or fixing an act's scene code under scenes/, briefing act builders, capturing an app for a film, handing an act in, or when a render shows a renderer-specific glitch."
---

> Knowledge-only edition of Slate's `slate-build` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-build

Scenes are code: a pure function of film time, drawn in the brand's tokens on the brand's motion law, keyed to the
words the voice says. The shared kit (`@slate/kit`) knows no brand, frame size or frame rate of its own; the film's data
(`@film/data`) and the brand pack supply them. Builders write only their act's files; everything they import is
read-only.

This is stage 7 of the production. Before it: the script, the voice and the timing exist (slate-story, slate-voice), and
the brand's look and motion law are approved (slate-brand, slate-motion).

## 1. Kit first

Nothing is built act by act until the shared foundation is ready: the brand's tokens (from its own code), its eases and
duration scale, the clock, cameras and surfaces in the brand's look, UI parts, charts, logos compiled from SVG, fonts,
and the film's sample data. Most of that is the kit plus the brand pack; anything film-specific that several acts share
(a report surface, a recurring card, a named rest state) is built once, before the builders start, and then read-only.
Reuse surfaces already matched to the product rather than redrawing them. See [kit](#reference-the-kit-slatekit).
Choose the representation for the transformations the scene needs. An object that opens, folds, reshapes, splits or
travels into another screen needs parts whose geometry, content and identities can survive that move. React/SVG,
DOM surfaces, meshes, footage and plates each have uses. A faithful screenshot can establish visual truth without
being the scene's animation structure. Keep product values, states and hierarchy truthful while staging the film.
For a recurring physical book, use the kit's `HingedBook` with shared caller-owned faces:
[building hinged books](#reference-building-hinged-books).

## 2. The act scaffold

```
<film>/scenes/act<N>/index.tsx   the act; its component is the default export
<film>/scenes/act<N>/beats.ts    every beat, computed at module level from the voice's words (React-free)
<film>/scenes/act<N>/NOTES.md    decisions, restaging, contracts, what couldn't be done
<film>/scenes/contracts.tsx      the named rest states acts meet on
<film>/public/                   files scenes load (plates, captures): linked, never copied
```

- **Placeholders first.** An act with no scene renders as the kit's placeholder (its shots, on-screen text and voice)
  in the brand's look, so the whole film plays from day one.
- **Get a first working version of every shot onto disk fast**, then refine. Sessions end without warning; what isn't
  on disk is lost. Keep NOTES.md current as you go.
- Scenes import only `@slate/kit`, `@film/data` and packages, never a relative path out of the film.
- Every beat comes from the voice's words through lookups that never throw (a miss is estimated and recorded, and must
  be empty at hand-in). Moves register with `defineMotion`, sound beats with `defineEvent`.
- **Tell the motion gate what moves**: a move whose name doesn't say it gives its `class` (rig, ui, carry or whip), and
  an exempt move gives `exempt` (`reading_sweep` or `steady`) with its `reason`. Long carries and camera drifts can use
  the kit's `even` curve. The rules are slate-motion's (eases.md).

The pattern, file by file, with a worked act: [act scaffolds](#reference-act-scaffolds-from-placeholder-to-finished-act).

## 3. Contracts between acts

Acts meet on **contract frames**: a named rest state drawn by one shared component, rendered by both builders on their
boundary frames and held still for at least 6 frames each side, so the joins are bit-identical and a splice or bridge
has clean frames. Everything decorative settles out over the last 0.6 s before a contract. The simplest contract is
the brand's empty ground. See [contracts](#reference-contracts-between-acts).

## 4. Events: tell the sound what each beat is

Every beat that lands exports as a visual event: shot, id, time, **kind** (tap, type, land, snap, count, draw, data,
page, stamp, whoosh, swell, character, impact), **size** (s, m, l) and a plain note. The sound is designed from this
list, one sound family per kind, so every beat must say what it is. An act with no beats says so explicitly, with a
reason. **`t` is always the beat**, never the start: a sustained motion also gives its span (`start` and `dur`,
together), a draw or a count ends on its beat, and a whoosh or a swell peaks on it. See [events](#reference-visual-events-telling-the-sound-what-each-beat-is).

## 5. Hand in

```
slate emit-events --act <N>     # the act's visual events and motion trace, from its scenes
slate check <N>                 # the hand-in check
slate timing misses             # word lookups that fell back to an estimate: must be empty
```

`slate check <N>` runs, as gates: the type check from the film folder; the act module loading in Node without throwing;
an empty word-miss list; what the kit had to assume; the brand's banned words in the act's strings; the events file
matching the act; the contracts at its boundaries, bit-identical and held; and the brand's motion law on the act's
trace, so a broken law fails here, before a render. A web act hands in through the open web
renderer the same way, plus its page loading and drawing, no network, and its fonts. Only PASS counts. The full
hand-in checklist, and how to check your work with stills and previews: [hand-in](#reference-handing-an-act-in).

Passing the technical hand-in establishes the checked properties; it does not establish beauty. Review the intended
transformations in motion with sound, then improve the choreography from the requester's specific feedback. Keep
the comparison versions and feedback so the next builder can understand what changed and why (slate-motion).

Builders make stills and half-scale previews only, in their own scratch folder. Finals render centrally, one at a time
(slate-finish).

## 6. Parallel builders

If you can run sub-agents, build acts in parallel, one builder per act under one brief; otherwise build them in order
with the same brief. Each builder owns only its act's folder, reads the kit and everyone else's work read-only, writes
kit requests into its NOTES.md, and exports its events. Briefs are layered (a base brief plus the film's differences)
and end with the hand-in checklist. See [builder briefs](#reference-running-act-builders) and the fill-in template,
[builder's brief](#reference-a-builders-brief-fill-in-template).

## 7. The product on screen

- **Real app footage**: `slate capture ios --spec <file>` records a pinned build on an isolated Simulator with a demo
  account and a 9:41 status bar; `slate capture web --spec <file>` captures a page through Aside at a fixed viewport,
  frame by frame. Both conform to the film's frame rate and map taps onto the voice's words. Capture for truth and
  speed; choose code when the intended move needs independently transforming product objects, restaging,
  motion blur or exact type. A camera move alone can also work with a capture. See
  [captures](#reference-app-captures-real-footage-on-the-films-clock).
- **Product UI drawn in code** follows the product exactly: its copy, its states, its order, its hierarchy. See
  [app UI](#reference-product-ui-on-screen) and [charts](#reference-data-on-screen-charts).

## 8. Web scenes: the open web renderer

A brand whose look needs what the browser does best (GSAP timelines, three.js and React Three Fiber, live DOM) can build
an act as a **web scene** instead: a local page that draws its act at any time t, rendered frame by frame with the same
motion blur, clock, events and gates (`look.engine: "web"` in the brand pack makes it the default for new acts).
`slate engine scaffold --act <N>` starts one from the neutral template (`--engine web` for a brand whose look doesn't
pick it; `--force` to replace a scene that's there); `slate render --act <N> --engine web` renders it. The page can't
reach the network, its clock is frozen to the frame, and its fonts must pass the font gate. Everything else (beats keyed
to words, events, contracts, hand-in with `slate check <N>`) is the same as a kit act. The page contract and its traps
are in the engine's own `engine/web/README.md`; its hand-in gates are in [hand-in](#reference-handing-an-act-in).

## 9. Building in After Effects

After Effects is a second way to build acts, on the same film clock and through the same gates, when a look calls for
it (the AE bridge's looks, or a brand whose motion lives in AE). Every AE step needs the owner's go, never runs for an
autonomous film, and never touches AE's preferences outside Slate's byte-safe tool. See [AE scenes](#reference-acts-built-in-after-effects)
and [the AE bridge](#reference-higgsfields-after-effects-bridge).

## 10. Renderer traps

Headless Chrome snaps text to whole pixels under slow motion, races its 3D sorting when planes stack, fails some clip
paths silently, and can't see locally installed web-kit fonts. Know them before you build:
[Remotion gotchas](#reference-remotion-and-headless-chrome-rendering-traps), [headless Chrome](#reference-headless-chrome-css-and-assets-that-fail-quietly). Slate's rules
override Remotion's own skills where they disagree: [Remotion overrides](#reference-where-slate-overrides-remotions-own-skills).

## Rules that hold everywhere

- Keep the script's beats, words, timing and on-screen text; restage the picture freely, and say so in NOTES.md.
- Preserve the approved baseline, exact feedback and revised version. Follow requested redesigns within their scope;
  keep outer geometry or other parts unchanged when the brief calls for that continuity.
- Never fake motion blur in scene code: the renderer averages sub-frame samples.
- One heavy process at a time; never a full-resolution final from a builder; never render on another machine.
- Nothing opens a browser: web pages are captured through Aside only.

## References

- [kit](#reference-the-kit-slatekit): what the kit reads and draws, the rules it keeps for you, review sheets.
- [hinged-books](#reference-building-hinged-books): physical book surfaces, page coordinates, state, raster rules and review.
- [act-scaffolds](#reference-act-scaffolds-from-placeholder-to-finished-act): the act's files, beats at module level, a worked act, NOTES.md.
- [contracts](#reference-contracts-between-acts): named rest states, holds, settling out, checking joins.
- [events](#reference-visual-events-telling-the-sound-what-each-beat-is): the beat vocabulary, sizes, silent acts, captures' taps.
- [hand-in](#reference-handing-an-act-in): the check, stills and previews, the checklist.
- [builder-briefs](#reference-running-act-builders): running parallel builders; ownership; conflicts; notes.
- [builders-brief](#reference-a-builders-brief-fill-in-template): a fill-in builder's brief.
- [app-ui](#reference-product-ui-on-screen): drawing product UI truthfully.
- [charts](#reference-data-on-screen-charts): data on screen.
- [captures](#reference-app-captures-real-footage-on-the-films-clock): iOS and web captures, conforming, beat maps.
- [remotion-gotchas](#reference-remotion-and-headless-chrome-rendering-traps): raster stability, depth sorting, stacking.
- [headless-chrome](#reference-headless-chrome-css-and-assets-that-fail-quietly): CSS that fails silently, fonts, performance.
- [remotion-overrides](#reference-where-slate-overrides-remotions-own-skills): where Slate overrides Remotion's own skills.
- [ae-scenes](#reference-acts-built-in-after-effects): acts built in After Effects.
- [ae-bridge](#reference-higgsfields-after-effects-bridge): Higgsfield's AE bridge, its looks and its limits.

---

## Reference: Act scaffolds: from placeholder to finished act

### The files

| File | What it holds |
|---|---|
| `scenes/act<N>/index.tsx` | the act: its default export is a component that receives `{sub, act, firstFrame}` |
| `scenes/act<N>/beats.ts` | React-free: every beat, computed at module level from the voice's words; motions and events registered here |
| `scenes/act<N>/events.ts` | optional: the act's events, when you keep them apart from the beats |
| `scenes/act<N>/NOTES.md` | the builder's notes (below) |
| `scenes/act<N>/*.tsx` | scene files per shot or per world, helpers |
| `scenes/contracts.tsx` | the named rest states acts meet on (shared, read-only to act builders once written) |
| `public/` | footage and captures scenes load with `staticFile()`, linked into the bundle, never copied |
| `.slate/`, `tsconfig.json` | generated by the engine; never edit |

The engine reads an act's modules in order (`events.*`, then `beats.*`, then `index.*`) for three exports: `events` (a
list, or a function returning one; `defineEvent` registrations count too), `silent` (a string saying why the act has no
beats) and `contracts` (`{in, out}`: the rest states its first and last frames match).

### Start with the placeholder

Until an act's scene exists, it renders as the kit's `PlaceholderAct`: its shot ids, on-screen text and voice, in the
brand's look, inside its `ActRoot`. The whole film plays from day one, and every act can be reviewed against the voice
before it's built.

**First working version of every shot, fast.** Block out every shot of the act roughly (the right objects, landing on
the right words) before refining any one of them. A session can end without warning; an act with every shot roughed
in is worth more than one perfect shot and nothing else.

### Beats at module level

```ts
// scenes/act2/beats.ts: React-free, so the engine can load it in Node
import {word, landOn, roleEase, defineMotion, defineEvent} from '@slate/kit/core';

// When the voice says "report" in shot S03 (film seconds). Never throws: a miss is estimated and recorded.
export const REPORT = word('S03', 'report');

// The card rises and lands (90% of its travel) on the word, on the brand's entrance ease and base duration.
export const cardUp = defineMotion({
  id: 'card-up', shot: 'S03', prop: 'y', from: 40, to: 0, entrance: true,
  ...landOn(REPORT, 'base', roleEase('entrance')),
});

// Tell the sound what happened, and when.
defineEvent({shot: 'S03', id: 'card_lands', t: REPORT, kind: 'land', size: 'm', note: 'the report card lands on "report"'});
```

```tsx
// scenes/act2/index.tsx
import {ActRoot, Card, useFilmTime} from '@slate/kit';
import type {SceneProps} from '@film/data';
import {cardUp} from './beats';

function Scene() {
  const t = useFilmTime();
  return <Card style={{transform: `translateY(${cardUp.atTime(t)}px)`}}>…</Card>;
}

export default function Act2({sub}: SceneProps) {
  return (
    <ActRoot act={2} sub={sub}>
      <Scene />
    </ActRoot>
  );
}
```

- **Everything is a function of film time.** No state carried between frames, no timers, no randomness: the renderer
  draws each frame up to 16 times across the shutter, and every sample must agree.
- **Use the brand's names** (`roleEase('entrance')`, the duration tokens), never literal curves or seconds. In a
  short act or a small frame, `durFit(seconds)` takes the longest step on the brand's scale that fits, and
  `maxTravel(duration, ease, class)` the longest travel the law's speed limits allow; the hand-in's motion gate
  (`handin.act<N>.motion`) holds every act to them.
- **Say what moves** when the name doesn't: `defineMotion({..., class: 'carry'})` for a page, card or camera carried
  across the frame (`rig`, `ui` and `whip` are the others), and `exempt: 'reading_sweep'` or `'steady'` with a `reason`
  for a move whose constant speed is the point. A long carry or a camera drift can run on `ease: 'even'`, the kit's
  curve that covers a third of the travel in each third of the time. The motion gate holds each class to its own speed
  limits (slate-motion, eases.md).
- **Gate each element's entrance on the first word it shows**, not a later one.
- **Numbers are spoken words**: `word('S05', '2026')` finds "twenty twenty-six"; `word('S05', '&', 2)` finds the second
  "and".
- For a word stressed on a later syllable, `slate timing stress <shot> <word>` measures where the stressed
  syllable starts and prints the beat's `stress_start` and `stress_end`; put them on the gesture in the beats file.

### NOTES.md

Every act keeps one, current from the first hour:
- **Checklist**: each ask from the brief and the script, re-read against the brief's own words, with evidence.
- **Files**: what each file holds.
- **What each shot shows**: a paragraph per shot, keyed to its words.
- **Decisions**: every judgement call and why (a rule conflict resolved with the smallest judgement that honours both;
  a law ease used where the brief's note disagreed).
- **Restaged**: every departure from the script's picture notes (the words and beats never change).
- **Contracts**: which rest states the act meets, and the proof (bit-identical boundary frames).
- **Character moves and score cues** for the sound pass (where the score drops, where one sound plays alone).
- **Truth pass**: every product element checked against the truth pack; omissions recorded.
- **Open, or couldn't do**: kit requests, gaps, anything left.
- **Log**: superseded cuts stay recorded, never silently erased.

Record deviations on surfaces outside your act instead of fixing them; facts several acts show (a tally, a standing)
come from one shared source, and a change to a shared surface goes to every act that shows it.

### Before calling it finished

Re-read the brief's original words against the act's checklist. Then hand in (hand-in.md).

---

## Reference: Higgsfield's After Effects bridge

Higgsfield publishes a free, local bridge that drives the owner's own After Effects through ExtendScript and serves a
set of motion-design skills (its "looks"). Slate depends on it, pinned, as a core lane for building scenes in AE; it
never vendors or copies it.

### What it is

- A local MCP server that talks to AE through files, so it needs AE's "Allow Scripts to Write Files and Access Network"
  preference on. Only the owner turns that on, in AE's own settings; Slate never changes it.
- It returns live project state and rendered frames, which Slate's own osascript route can't while that preference is
  off.
- Its recipes cost nothing until they generate media. Generating inside its recipes spends Higgsfield's app credits (the
  unfunded pool); for Slate films, media comes from the Cloud API through `slate gen` and is imported instead.
- Its project export and import use its own JSON schema, not Lottie.

### What it's good for

AI-driven motion design through After Effects is strongest for logo reveals, product promos, explainers and
presentation animation, and weakest for complex character animation, intricate rigging and tightly art-directed
performance.

### Its looks

The bridge serves thirteen skills that Slate's looks library lists as AE looks by name: the clean rig (its entry
point), native AE authoring, bridge realities, build orchestration, animation principles, design first, UI mastery,
depth and space, liquid glass, the transition kit, cleanup, matte painting, and Figma transfer. They're referenced, never
copied: there's no redistribution grant. The clean-rig references are worth reading during look development.

### Working with it safely

- **Its batches aren't transactional.** If a batch fails part-way, read the project's state before retrying; never
  blindly re-run a batch that may have half-applied.
- **Take Slate's AE lock** around bridge work, so the bridge and Slate's own scripts never drive AE at once. Slate takes
  the lock in every place the bridge might look for it.
- **Its frame render handles colour-managed projects** with a temporary display transform and warns when it falls back;
  its frames aren't colour evidence unless that warning is clear.
- **Acceptance tests on every version bump**: the bridge is pre-1.0 and moves fast. Where it fails, fall back to Slate's
  own ExtendScript library, which needs no preference change.
- Don't call a bridge tool that runs code inside AE without the owner's go: it launches After Effects.
- **Its arbitrary-code tool stays off, and its categories stay limited** to the ones Slate's scenes use. Slate registers
  and starts the bridge that way every time, and the environment can't loosen it.
- **Its mailbox is a trust boundary**: anything that can write there runs code in After Effects, so Slate creates it
  0700 and nothing else writes to it.
- Each call waits a little longer than the bridge's own limit for that tool (a minute by default, longer to render a
  frame or import), so a long import is never cut off on Slate's side and left in an unknown state.

### Alternatives, for the record

Community AE MCP servers (panel-based) and data-driven template renderers exist as untested fallbacks. Adobe's own AI
features can't drive AE from an agent; connecting to AE means a local bridge plus aerender.

---

## Reference: Acts built in After Effects

After Effects is a full second engine: a look can call for it (the AE bridge's looks, a brand whose motion lives in AE),
and an AE-built act runs on the same film clock and through the same gates as a Remotion act. The engine is chosen per
brand or per act during look development.

### The rules that never bend

- **Every AE step starts on a person's go.** Adobe's enterprise terms bar operations a person didn't start, and Slate
  treats that as the rule until the owner's own terms are checked. The CLI refuses AE steps without `--go`.
- **Autonomous films never touch After Effects.**
- **AE's preferences are changed only through Slate's byte-safe prefs tool**, with AE closed, one key at a time, line
  endings kept. The file uses old Mac line endings; a text-mode rewrite once made AE reset every preference and switched
  off the scripting-security setting. That setting ("Allow Scripts to Write Files and Access Network") is the owner's
  choice and is never changed by Slate.
- **Never quit AE for the owner**, and never "without saving". Ask them to save and quit.
- **One lock**: AE runs one script at a time, and Slate's AE lock is shared with the AE bridge's own busy lock.

### Building an act in AE

- Timing comes from the film's clock: comp markers and keyframes from `timeline.json` and the word timings, never typed
  by hand.
- The brand's motion law is converted to AE speed and influence (slate-motion, motion-law.md): the same eases, the same
  durations, read back after they're set.
- Brand tokens, fonts (activated in AE, by PostScript name) and logo shapes come from the brand pack.
- The act exports its visual events and its motion trace like any act, and meets its neighbours on the same contract
  frames.
- It renders through `slate render --engine ae --act <N> --go`, whole acts only, conformed to the film's delivery codec,
  registered like any render, and gated like any act: the glitch scan, the motion checks, the act joins.

### ExtendScript

AE's scripting language is ES3: `var` only; no JSON object, `indexOf`, `forEach`, `map`, `trim` or `Object.keys`; no
trailing commas; each script an immediately invoked function returning a string; properties addressed by match name;
ease arrays sized to the property (one for spatial properties, three for scale); every ease read back after it's set.

- Build on ExtendScript, which Adobe's move to UXP doesn't affect; avoid CEP-panel routes for anything long-lived (CEP
  leaves the flagship apps in the coming years).
- Nested comps need a sampling bias: every nested layer starts a tenth of a frame early, so AE samples inside each
  frame. Without it, slices at exact fractional-rate times showed the previous frame, and the picture ran a frame behind
  the sound.
- The working space matches the footage's tag (Rec.709 Gamma 2.4 for BT.709-tagged renders), or AE converts the colour.

### When AE is the right engine

AE-driven motion design is strongest for logo reveals, product promos, explainers and presentation animation, and
weakest for complex character animation, intricate rigging and tightly art-directed performance. Choose it when the
look needs what AE does best; keep character work in the kit.

### Routes into After Effects

- **Slate's own route**: ExtendScript run through osascript, with reports read back through AE's own settings, and
  aerender for output. It needs no preference change. The first films' native AE act builders (event-timed carriers
  from the film clock) proved AE can build scenes; they're the basis for AE-built acts.
- **Higgsfield's local bridge** (ae-bridge.md): live project state and rendered frames, and its looks. Its frame render
  handles colour-managed projects with a temporary display transform and warns when it falls back, so its frames aren't
  colour evidence unless that warning is clear. Its clean-rig references are worth reading during look development.
  Its project export and import use its own JSON schema, not Lottie; it has no HTML-to-scene, cloud preview or Lottie
  converter.
- **The vendor's AE panel and cloud bridge** generate footage into an AE project through a CEP panel: a different route
  from the local bridge, aimed at repeated structured assignments rather than art-directed scenes.
- **Adobe's own AI** (the in-app assistant, its chat connectors) can't drive After Effects for an agent: connecting to
  AE means a local bridge plus aerender.
- **Community AE MCP servers** (panel-based) and data-driven template renderers built on aerender exist as untested
  fallbacks.

---

## Reference: Product UI on screen

When a film shows a product, the product is the truth. Its copy, its states, its order and its hierarchy come from its
code at a pinned commit (slate-story's truth pack), and the film shows it the way it really behaves, only bigger and
better staged.

### Show the product as it is

- **At the size and form factor its code lays it out.** Don't invent a device hand-off (a phone) for a product that
  ships at desktop size.
- **Ground UI in the product's real code**, read in place, never copied into Slate. Captions, chips and wording are the
  product's own.
- **Show only statuses the product really has**: no invented intermediate state before the real one.
- **Show UI in the state the data implies**: a feature that needs two readings isn't visible on the first.
- **Simplify only by choosing states it really has** (a real toggle turned off), never by deleting parts arbitrarily.
- **Keep the product's typographic hierarchy**: an eyebrow stays an eyebrow, not a big heading.
- **Show UI state changes with the product's own state styles** (a disabled button waking from its disabled opacity on
  the word) and highlight items on their spoken word with the product's own hover or selection state.
- **Load surfaces the way the product loads them**: the curve draws, the numeral counts, the marker settles, the
  statement lands.
- **Redraw the product's icons from their source geometry** (the icon library's own paths, at the product's pinned
  version), never approximations. The kit's generic icons are for brands without a set of their own.
- **Figures in the voice match the data state on screen.** One constant in the act picks which reading the film shows
  (the first reading or the second), and every surface that depends on it (the report, the chart, the character's line)
  reads that constant, so a sentence about the old score never sits beside a report showing the new one.

### Interactions

- **Show interactions as the product behaves.** Whether a question is typed, chosen from a chip or already sent
  comes from the actual screen and the requested staging. Stream an answer only when the product does.
- **Never show a password being typed or a sign-in link being sent**; show sign-in the way the product really does it.
- **Keep conversation continuity readable**: a follow-up occupies its actual place in the thread. Use the product's
  scrolling behavior when the shot needs it, with enough context to understand what changed.
- **UI belongs to the card that owns it**: print a button on its card so it moves and clips with the card; never float
  it in front at a fixed position (a floating button was once left behind on a bare page).

### Film copy and product copy

- The script's on-screen lines and the product's copy are separate layers. Show the product's copy as the product
  writes it (emphasizing the script's words), and set the script's line as film type beside it rather than rewriting
  the product.
- Don't dress plain concepts as UI chips: chips read as invented UI. Use plain type.
- The on-screen word budget can justify leaving product elements out of a shot; record the omission in NOTES.md.

### Restaging for film

- When a product surface would vanish on the film's ground (a light-grey panel on a light-grey page), set it as its own
  card and note the restaging.
- On a fidelity pass, correct the surfaces shown in the film against the selected source. Keep the requested scope
  and accepted work visible; a local correction can preserve the rest of a scene. Record deliberate omissions,
  restaging and any remaining mismatch instead of treating a secondary surface as automatically accurate.

### Native geometry and type

Use `AppViewport` from `@slate/kit` for a reconstruction whose product layout uses points. Supply its `profile`
from private product data: width, height, capture pixel ratio and safe areas. Children lay out at that native size;
the completed viewport scales into the film. Film dimensions and camera scale must not change native wrapping.
The ordinary `Field`, `Text` and other film primitives keep their existing film scale; they are not native matches.

Keep control rectangles in one exported layout object. `AppBox` draws those native rectangles; `appLayout` from
`@slate/kit/core` maps the same rectangles and anchors into viewport pixels for camera and interaction targets.
Its mapping is local to the viewport; apply the scene's world or camera transform afterward. Safe areas describe
content bounds and do not insert padding automatically. Nested AppBox rectangles establish child coordinate frames;
use `appLayout(...).within(parentRect)` for the same local frame outside React. The hook inherits that frame inside
AppBox and rect-bearing AppText. AppBox paints borders separately so they do not shift the child origin; express
padding and margins in the native child rectangles. Additional CSS transforms must be represented in the staging
before using an anchor. AppText anchors describe its box; baseline adjustments move glyphs inside that box.
AppText children are text and inline content. Place positioned icons, AppBox elements, additional AppText boxes and
AppViewport elements in sibling native rectangles, outside its baseline-adjusted span. Native primitives reject
placement inside AppText so a glyph offset cannot silently move a geometric target. Custom inline components must
also keep their content inline; their arbitrary CSS is not included in the native geometry map.
Use `snapAppPoint` only where the product needs source-grid
rounding; camera scaling does not redefine that grid.

Use `AppText` with explicit product typography: family, point size, line height, weight, tracking and any calibrated
optical size, variable-font axes or baseline adjustment. Optical size stays at its authored point value as the screen
scales. AppText disables synthesized faces; declare and load the actual faces through the brand's font plan so a
missing font cannot pass as a match. Keep the film's type roles separate. Platform font aliases, metrics, palettes
and device profiles belong to the private brand or film, never the shared kit.

Source code and captures answer different questions. Record the selected source revision and the capture's
build/device/runtime; identify version differences before deciding which appearance governs. Compare the flat
reconstruction with real captures using side-by-side frames, overlays, crops and named regional measurements.
Similarity scores are measurements, not percentages of overall fidelity. A source-only screen remains unmeasured
until its actual comparison exists. Inspect the staged film at the intended viewing size separately for legibility.

For translucent UI, preserve the relationship between the material and what lies beneath it. A clipped redraw of
the underlying screen with blur can work under a three-dimensional camera where browser backdrop filtering does
not; document the approximation and compare it with the actual product material. Avoid shared mutable material
settings that let one screen alter another screen's result.

### Capture or rebuild?

Real app captures (`slate capture ios`, `slate capture web`) provide appearance and behavior evidence. Choose the
scene's representation for its intended transformations: a capture can move as a whole surface, while an unfolding
card, a reshaping chart or a label carried into another screen needs independently controllable parts. Use the
product's actual components or source geometry where practical, and measure source and destination seats in the
same camera space. Keep the owning surface and its contents together through the change.

A film transformation can connect truthful product states without claiming the app offers that transition as an
interaction. Record that editorial restaging in NOTES.md. Compare the reconstruction with captures for appearance,
then judge the staged transformation in motion. The same truth rules apply to captures and reconstructions
(captures.md); neither representation is a universal default for every shot.

---

## Reference: Running act builders

A film's acts can be built by several builders at once, each owning one act, all working from one brief. On the first
films, five builders built one film's acts overnight, five built the next, and three built the third, with one sound
designer working in parallel from their exported beats.

**If you can run sub-agents, build acts in parallel, one builder per act; otherwise build them in order**, one act at a
time, with the same brief and the same hand-in check. The discipline below matters either way.

### What a builder's brief names

- **The approved script and shot list** (`script/SCRIPT.md`), and the treatment's signature moment for the act.
- **The product truth**: every screen, label, number and flow the act may show, cited from the product's code
  (slate-story's truth pack).
- **The motion law** (the brand's) and the look.
- **The reference sequence and representation**: the selected version and time window, which object carries the
  change, its source and destination geometry, and how its content, camera and sound stay connected. Read the source
  when available and identify any gap between that source and the rendered reference. Choose scene objects that can
  express the intended transformation rather than assuming an image of the whole screen supplies its moving parts.
- **The locked timing**: shot lengths and word timings, generated; never edited by builders.
- **Files and ownership**: who owns which act folder, and what's read-only.
- **The contracts** at each boundary, specified exactly.
- **The event vocabulary** for sound.
- **How to check and hand in**, ending with the hand-in checklist.
- **The owner's words** where they shaped the brief, quoted.

Briefs are layered: a base brief for the film (or for Slate's defaults) plus a short delta for this film's differences.
A variant film's builders read the base brief first; its own brief lists only what's different. Keep briefs in sync with
what was built: one brief still said two shots were built in After Effects after they'd been rebuilt in code, and a
builder followed it.

### Ownership

- A builder owns only its act's folder (`scenes/act<N>/`). The kit, the shared contracts, other acts, generated files
  and docs are read-only.
- **Kit changes go through NOTES.md**: a builder who needs one writes it up and works around it locally; the coordinator
  changes the kit.
- **Each builder has its own scratch folder**: parallel builders overwrite each other's scratch otherwise.
- **Builders make stills and half-scale previews only**, never full-resolution finals, never inside the film folder.
- **Preserve reviewed comparisons before cleaning scratch.** Give the coordinator the comparison previews, their
  source revisions and exact feedback for the film's versioned iteration history. After that handoff, remove disposable
  scratch and keep the final preview and its contact sheet.
- **Facts several acts show** (a tally, a standing, a sample value) come from one shared source; an act that picks a
  value records it for the coordinator, and a change to a shared surface goes to every act that shows it.

### Judgement calls

- **Keep the script's beats, words, timing and on-screen text; restage the picture freely**, and say so in NOTES.md.
- When the script's picture notes and its on-screen column disagree on wording, the on-screen column wins.
- When a brief's ease note conflicts with the motion law's ease for that job, use the law's and record the deviation.
- Gate each element's entrance on the first word it shows, not a later one, or it appears already part-way through its
  move.
- When two rules conflict (a no-logos-over-footage rule against a brief that wants the corner mark throughout), make
  the smallest judgement that honours both, and record it.
- Record deviations on surfaces outside your act rather than fixing them.
- Work the owner approved is not rebuilt; build around it.

### Save early and often

A builder session can end without warning, and anything not on disk is lost; it happened on the first film. Get a first
working version of every shot onto disk quickly, then refine, and keep NOTES.md current as you go, so the next builder
(or the next session of you) can pick up where you stopped.

### Coordinating

- The coordinator builds the kit and the shared contracts before any builder starts, and marks the foundation done.
- Builders hand in with `slate check <N>` passing and their checklist done.
- Every act keeps a requirement checklist in its NOTES.md, each ask a checkbox with its evidence; before calling an act
  finished, the builder re-reads the brief's original words against it.
- Superseded cuts stay recorded in the notes as a record of what was delivered and why it changed; they're never
  silently erased.
- A technical PASS is not a creative verdict. Review the moving choreography and the requester's feedback alongside
  the checks, and carry the successful construction into the remaining scenes and output compositions.
- Intentionality degrades across parallel acts: judge each act against the best act's code and notes, tie every move to
  a word or an idea, and prefer fewer, better moves.

A fill-in brief: [builder's brief](#reference-a-builders-brief-fill-in-template).

---

## Reference: A builder's brief (fill-in template)

Copy this into the film folder (for example `brief/BUILDERS.md`), fill in every bracket, and hand it to every act
builder. Keep it in sync with what's actually built. The rules behind it are in [builder briefs](#reference-running-act-builders).

---

### What the film is

[One paragraph: the film's idea, runtime, acts, narrator, and who it's for. Quote the owner's own words where they
shaped it.]

### The inputs (generated; don't edit them)

| What | Where |
|---|---|
| The approved script and shot list | `script/SCRIPT.md` (from `script/script.json`) |
| The product truth: screens, labels, numbers, flows, with sources | `brief/truth.json` and [the product-truth document] |
| The frame-exact shots and the voice's word timings | `timing/shots.json`, `timing/vo_words.json` |
| The voice's takes, placed | `timing/vo_cues.json` |
| Captions | `timing/captions.json` |
| The brand's look and motion law | the brand pack; [the brand's MOTION.md] |
| Shared surfaces and contracts | `scenes/contracts.tsx`, [any shared components] |

### The look

[The approved look in a few lines: the ground, the surfaces, depth, the accent's one meaning, what the camera does. Link
the look test that was approved.]

### Motion law (enforced)

Only the brand's named eases, by job; the duration scale; staggers capped; nothing scales from zero; no bounce outside
the named settle; no linear moves except time-based things; no hard cuts or crossfades except the reasoned ones; hero
text moves or unmasks; read times hold; sync within 2 frames of the word; motion blur is the renderer's, never faked.

### Truth (enforced)

[What the film never shows or says: ruled-out features, banned words, the sample data and its label, partner rules.]

### Files and ownership

You own only your act's folder: `scenes/act<N>/`. Import the kit, the contracts and other acts read-only. Kit requests
go in your NOTES.md. Your own scratch folder: [path].

Every act folder follows one pattern: `index.tsx` (the act inside its `ActRoot`, plus the scene), `beats.ts` (every beat
computed from the voice's words, at module level), scene files per shot or per world, the act's events (registered in
the beats, or `events.ts`), `NOTES.md`, and optionally a review-only entry.

Your NOTES.md keeps, from the first hour: a checklist re-read against this brief's words; what each shot shows;
decisions and restaging; the truth pass; what you reused; your contracts and their proof; the checks you ran; score and
sound cues; open items and kit requests; and a log.

### Who builds what

| Builder | Acts | Shots | Frames | Folder |
|---|---|---|---|---|
| [1] | [1–2] | [S01–S09] | [0–2223] | `scenes/act1/`, `scenes/act2/` |

### Contracts (both sides must match)

| Boundary | Rest state | The picture |
|---|---|---|
| [Act 2 → Act 3] | [`NameOpen`] | [exactly what's on screen, where, at what size; the character calm] |

Hold each contract still for at least 6 frames each side; settle everything decorative out over the last 0.6 s before
it.

### Signature moments

[Per act: the moment, the word it lands on, what the sound does.]

### Sound

Export your beats with `slate emit-events --act <N>` in the event vocabulary (tap, type, land, snap, count, draw, data,
page, stamp, whoosh, swell, character, impact; size s, m, l). List every beat that lands. Note score cues in NOTES.md.

### Checking and handing in

- Stills: `slate render stills --act <N> --frames <frames> --scale 0.5`, into your scratch folder.
- A draft preview: `slate render --act <N> --draft --out <scratch>/act<N>.mov`.
- No full-resolution finals. No other machine.
- Hand in with `slate check <N>` passing.

**Before you finish:**
- [ ] Every shot's on-screen text matches the script (restaging the picture is fine; say so in NOTES.md).
- [ ] No banned words; read times hold; body text at least 28 px at a 1080-line frame.
- [ ] Both contracts match.
- [ ] Any character is calm at your act's ends.
- [ ] The word-miss list is empty.
- [ ] Your events file lists every beat.
- [ ] NOTES.md says what you decided, what you restaged and what you couldn't do.

---

## Reference: App captures: real footage on the film's clock

A product demo is often best told with the product itself. Slate records it deterministically (a pinned build, a
seeded demo account, scripted steps), conforms it to the film's frame rate and requested capture size, and lands its
taps on the voice's words, so a capture behaves like any other shot on the one clock.

### iOS

```
slate capture ios --spec captures/save-entry.json
```

A spec names the app (its path, bundle id and the SHA-256 of the pinned build), the demo account (launch arguments
that seed it), where it sits in the film (`place: {shot}`), and timed steps:

```json
{"kind": "ios", "name": "save-entry", "duration": 8,
 "app": {"path": "build/Demo.app", "bundle_id": "com.example.demo", "build_sha256": "0000000000000000000000000000000000000000000000000000000000000000"},
 "account": {"kind": "demo", "launch_args": ["-ui-testing", "-seed-demo-account"]},
 "place": {"shot": "S04"},
 "steps": [{"at": 0, "do": "launch"},
           {"at": 2.4, "do": "tap", "id": "save", "x": 201, "y": 742, "word": {"shot": "S04", "text": "save"}, "size": "small"}]}
```

Replace the example's zero hash with the actual app bundle's SHA-256 and use launch arguments that the app supports.
Tap sizes are `small`, `medium` or `large`.

- By default it creates or reuses a Slate-owned Simulator, erases it before recording, and shuts it down afterwards.
  The device is retained for reuse; other devices are left alone. Apple's status bar shows 9:41, full battery and
  full bars.
- A build whose hash doesn't match the spec is refused. The hash pins the recorded bytes; owner approval and the
  build's correspondence to source are separate evidence.
- Tap and type steps need an installed idb or AXe driver. Slate refuses when neither is available; it does not
  silently simulate an interaction. Choose `tap_driver: scripted` only when the app actually plays its own demo
  from launch arguments: those steps mark interactions the app performs, rather than injecting taps or text.
- Booting a Simulator is heavy: run captures when the machine is quiet, one at a time.

Prepare the demo profile's setup and privacy choices before recording. Record those choices and distinguish seeded
content from actual feature output. Inspect startup frames and first-use tips before selecting film footage; allow
the app to settle. Clear notices through the app's real demo state or controls, and keep optional sharing disabled
when the intended demo declines it. Removing a notice is not a reason to grant sharing or manufacture AI output.

### Web

```
slate capture web --spec captures/pricing.json
```

- **Always through Aside**, never another browser. A local wrapper page holds the target at exactly the spec's viewport.
- Local folders and local dev servers are captured frame by frame on a virtual clock at the film's rate, so CSS and
  script animations land on exact frames.
- Other sites fall back to a real-time recording conformed from timestamps, and the capture record says so.

### After capturing

- The capture lands in `captures/<name>/`: `capture.json` (what, when, which build) and a JPEG sequence at the film's
  rate, which scenes play from film time. `fit: native` preserves the device's pixels; `contain` or `cover` fits to
  the spec's size, or the film's size when no size is supplied. A native sequence is source footage, not a finished
  film frame.
- Taps and marks become visual events (kind `tap`, their size), beat-mapped onto the voice's words: holds and small
  retimes happen only in idle time, never inside a tap's response. A tap that still misses its word fails the capture's
  gate rather than warping the motion.
- A recording made by hand can be conformed the same way, as its own capture.
- Build previews from the capture record's frame count and rational frame rate. Keep the film's clock when copying
  stills or encoding a review movie; do not round a fractional rate to an integer.

### Rules

- Capture for truth and speed; rebuild in code when a shot needs camera moves, restaging, motion blur, exact type or a
  state the demo account can't reach (app-ui.md).
- Use the demo account and sample data only; never a real person's account or data.
- Captures that were replayed in tests are marked so, and never ship in a final delivery.
- Recording an app to check its UI (jank, flicker, transitions) is QA, not film-making: that's video-verifier's job,
  not a capture.

---

## Reference: Data on screen: charts

Charts in a film are read once, in a few seconds, while the voice talks. They carry one idea each, and every number in
them is true (slate-story, truth-packs.md).

### Truth first

- Draw data graphics from the product's real distributions, ranges and clamps, never invented shapes.
- **Conceptual charts carry no numbers and no axis labels.**
- Illustrative graphics that aren't real data carry an illustration treatment and never show fabricated percentages.
- Future or illustrative points carry no numbers; only real sample readings are labelled.
- Show aggregated data the way the product aggregates it; never single out an individual.
- One company, one set of numbers: every chart of the sample reads from the same sample-data record.

### Drawing

- **Timelines of data are drawn to scale.** Label only the ends when the word budget is tight, and name partners in type
  (no partner logos).
- **Show a range as a solid value plus a lighter band.**
- **Hairline leaders can tie labels to the parts they describe.**
- **The accent colour keeps one meaning**: the line that matters is the accent; competing lines are ink.
- **Tabular figures** on every number that changes; count-ups count once, on the entrance ease, holding each figure
  three frames.
- The kit's charts (distributions, bars, lines, radar, rings, axes, markers) take the brand's tokens and the motion law.

### Motion

- Stagger along the data's direction: low to high, baseline to latest, the product's own order.
- A line draws on the entrance ease with a trim reveal; the value it lands on counts once.
- When an element lifts off a chart, its attached parts (area fill, head marker) go with it or fade gradually; never
  remove them all on one frame.
- Keep layouts stable when data changes: a column that reflows becomes a fast move.
- Show an analysis step as the signature line reading the data, so the pattern has a visible cause.

### Reading time

A number holds at least 2 s after its count lands. A chart with more than one idea needs more than one shot.

---

## Reference: Contracts between acts

Acts built by different builders, or rendered separately, meet on **contract frames**: a named rest state that both
sides draw exactly. On the first films, five of five joins passed with jumps of 0.00 to 0.39 against the picture's own
motion, because every boundary was specified to the pixel and checked.

### How a contract works

- **One shared component per rest state**, in `scenes/contracts.tsx`. On the boundary frames both builders render that
  component and nothing else. Its position, size and every value come from named constants both sides import.
- **Hold it still for at least 6 frames** on each side (`slate check <act>` checks the hold; `--hold` changes it). The
  two boundary frames are then bit-identical, and a splice or a bridge has clean frames to start and end on.
- **Next to it**, animate to and from the rest state with the same named constants, so your first or last moving frame
  continues exactly from it.
- **A character is calm** in the rest state: every gesture finished, the mark at rest.
- **Gate the rest state on the master frame** (the kit's frame, rounded), so every motion-blur sub-sample of a contract
  frame draws the rest picture.
- Declare it in the act: `export const contracts = {in: 'NameIn', out: 'NameOut'}`. The engine registers each rest
  state as its own composition, so it can be rendered alone and compared.

### Good contracts

- **The simplest is an empty ground**: the next act's first frame is the brand's ground with its texture and nothing
  else.
- **A single object**: one line at a given place and weight, one ring, one lockup at an exact position, a set of frame
  brackets. The next act turns it into something else.
- **Geometry can encode the next act's data**: a line drawn as four segments whose joins sit exactly where the next
  builder splits it.
- **A whip**: one act ends whipping one way in its last fraction of a second; the next opens mid-whip. Mirror the
  direction and rotation.
- **A moving contract** (a line drawing across the join) is defined by its start point, start time and constant speed
  in the shared contracts module, so both sides compute the same frames. Compare the two boundary frames against that
  function, since nothing holds still.

### Settling out before the boundary

Everything that decorates a frame (fading rings, impact echoes, paper light, grain, a character's gesture) settles out
before the contract frame: over the last 0.6 s at least. On the first film a relief ring still fading on an act's last
frame blinked out on the cut: a join jump of 1.36 against 0.13 inside either side. The kit's `settleBy` does this for
logo builds.

After a contract frame, hold the contract state for its frames, then bring texture (light, grain) up slowly on the
rest-to-rest ease, so there's no flash against the flat contract frame.

### Hand-offs inside an act

Hand-offs inside one builder's span aren't pixel contracts, but they follow the same discipline: carries per the
script's transition column, with no pop or cut.
- Hand an element between screen space and a card only when the card is at rest and the camera at identity, so every
  hand-over is a carry by construction.
- Hand an object between components only at rest or on a morph's first moving frame.
- When a shot switches from an act's own drawing to a kit component mid-shot (a logo build), the component's start
  state matches the drawing exactly; check the switch frame pixel by pixel.
- When several acts share one continuous space, draw them from one stage function of film time, so internal cuts are
  the same pixels on both sides.

### When a shared component changes

Re-measure the join from both sides, and tell the other side's builder (in the component's header and their notes).
When a surface in an approved act is replaced, keep its outer geometry identical (card size, the anchor positions of
carried elements), so every pose, carry and contract stays where it was.

### Checking a join

1. Render both boundary frames at full size and compare: they should be bit-identical, or differ by at most a 1 px
   settle. CSS transforms change the raster, so "the same picture" drawn two ways isn't the same pixels: draw rest states
   untransformed.
2. `slate check <act>` renders the act's boundary frames against its neighbours' and the rest state, and checks the
   hold.
3. After the finals render, `slate qa boundary` measures every join between consecutive act renders against the
   picture's own motion either side.

---

## Reference: Visual events: telling the sound what each beat is

Sound is designed from the picture's own beats. Each kind of interaction gets its own family of sounds, with natural
variation between repeats, and that only works when every beat says exactly what it is. Loose kinds ("click" used for a
press, a check, a vertex and a row) made consistent sound impossible on the first film; a strict vocabulary fixed it.

### The shape

`timing/visual_events/act<N>.json`, written by `slate emit-events` from the act's scenes:

```json
[{"shot": "S12", "id": "seal_sets", "t": 41.28, "kind": "stamp", "size": "l", "note": "the seal presses into the page"},
 {"shot": "S13", "id": "trend_draws", "t": 44.10, "start": 43.30, "dur": 0.80, "kind": "draw", "size": "m",
  "note": "the trend line draws"}]
```

- `t` is always **the beat**: the film second where the motion lands (its contact), taken from the same beat constant
  the picture uses. Never the start.
- A sustained motion also gives its **span**: `start` (film seconds) and `dur` (seconds), always together.
  - A `draw` and a `count` need their span, and they **end on their beat**: `t = start + dur` (within half a frame).
    A count runs `from` → `to` and reaches `to` at `t`.
  - A `whoosh` and a `swell` **peak on their beat**, somewhere inside their span.
  - Any other kind may give a span too; its beat sits inside it.
  The films timed one sustained draw at its start while the sound handover read a draw as ending on `t`; spans make
  it explicit, and `slate.timing.beats.problems` checks the arithmetic the same way for every engine and reader.
- A capture's beats carry `"source": "capture:<name>"`; a captured draw or count needs its span like any other.
- `id` is unique in the act and says what it is.
- `note` is what the viewer sees, in plain words.
- An act with no beats says so, `{"silent": true, "reason": "…"}`, because "no file" and "no beats" look the same to a
  sound engine and only one of them is a decision.

### The kinds

| Kind | Use it for | Example |
|---|---|---|
| `tap` | a press or a choice: a button, a chip, a menu pick | "Continue" pressed |
| `type` | text writing on (a line or a word) | the question writes on |
| `land` | a card, panel, sheet or document settling into place | the report swings up and lands |
| `snap` | a state change: a chip flipping, a check, a toggle, a node lighting | node 2 lights |
| `count` | a number counting (give `from` and `to`, and the landing) | 2% counts to 23% |
| `draw` | a line or chart drawing | the trend line draws |
| `data` | a single data point arriving (dots, bars, points) | a dot lands on the trend |
| `page` | paper moving as paper: a stack fanning, a page turning, a sheet sliding | the research fans out |
| `stamp` | a seal or stamp pressing down; a group completing | the seal sets |
| `whoosh` | a camera move, a carry, a transition | the camera pushes in |
| `swell` | a chapter opening, a ground rising, the picture filling | the next chapter opens |
| `character` | the brand's character or mark gesturing (one row per note) | the mark nods |
| `impact` | the one big landing of a scene: rare, at most one per act | the key value lands |

`size`: `s` a small detail, `m` normal, `l` a moment.

### Rules

- **List every beat that lands**: checks, chips, cards, counts, whips. Sound locked to the picture is a signature the
  owner loves; a beat that isn't listed gets no sound.
- **One impact per act, at most.** Land it at the end of a sentence, so its sound plays in the voice's pause.
- **Character rows come from the rig** (`motifBeats()`): one row per note, each on its own whole contact frame. The
  sound engine adds no offsets of its own. A character's flight that lands with no gesture on it is an ordinary `land`
  event, not a `character` row.
- **Captures' taps** become beats too: `slate capture ios` and `slate capture web` beat-map a capture's taps onto the
  voice's words and write them as events.
- **Score cues** (where the score should drop to one pad, or thin under a heavy line) go in the act's NOTES.md for the
  sound pass; they aren't events.

### Checking

- `slate emit-events --act <N>` writes the file from the act and validates it: kinds, sizes, the act's span, unique
  ids, at most one impact, and every beat's own span (t at a draw's end, inside a whoosh's span).
- `slate check <N>` fails the act when its events file is missing or no longer matches what the act says now.
- `slate qa events_complete` fails the film if any act has neither beats nor an explicit silence, or if a beat
  disagrees with its span.

---

## Reference: Handing an act in

An act is handed in when its hand-in check passes and its checklist is done, not when it looks finished in a preview.

### The check

```
slate emit-events --act <N>
slate check <N>
```

| Gate | What it proves |
|---|---|
| `handin.act<N>.typecheck` | TypeScript, run from the film folder, over the act and everything it imports |
| `handin.act<N>.module` | the act's modules load in Node without throwing (a throw at load breaks every composition in a bundle) |
| `handin.act<N>.word_misses` | every word lookup found its word; none fell back to an estimate |
| `handin.act<N>.kit_problems` | what the kit had to assume or refuse (an unknown ease name, a missing token), for a person to read |
| `handin.act<N>.banned_words` | none of the brand's banned words in the act's strings or its shots' on-screen text |
| `handin.act<N>.never_claim` | every on-screen line that uses something the brand or the film never claims, printed for you to read |
| `handin.act<N>.literals` | no literal film or act frame numbers in the act's sources: every time is keyed to a word, a shot or a contract constant |
| `handin.act<N>.margins` | every timing margin the act records (the kit's `margin()`: the slack between beats the picture depends on) is positive, and the rig lint is clean; `slate emit-events` writes nothing until both hold |
| `handin.act<N>.character` | each mark the act registers (`registerMotifTrace`) passes the character's acceptance checks: calm at both ends and after every gesture, still between gestures, clear of the split point and of every clip |
| `handin.act<N>.events` | the events file exists, is valid, and matches what the act says now |
| `handin.act<N>.contracts` | the act's boundary frames are bit-identical to its neighbours' and the rest state, and held |
| `handin.act<N>.fonts` | the brand's faces loaded (a substituted font fails) |
| `handin.act<N>.motion` | the act's motion trace keeps the brand's motion law: every check `slate qa motion` runs on a trace (eases, durations, staggers, entrances, settled type, speed and acceleration, loops, rig symmetry), with no pixels, so a law the act breaks fails here before anything renders. The trace must be the act as it is now: once its sources change, emit again. An act with no trace (drawn without the kit's motion registry) has nothing for it to read; `slate qa motion` judges it from its render |

Only PASS counts. A gate that couldn't run is UNCHECKED, never a quiet pass. `slate timing misses` lists any word
lookups that fell back to an estimate. `slate check all` checks every built act, and `slate --dry-run check <N>` says
what it would run without running it. Two checks run when you ask for them:
`slate check <N> --markup` reads the act's static markup at every frame and four sub-frame samples (NaN, Infinity or
undefined fails; with `--against <git ref or kit folder>` a rendering-only change proves it changes nothing), and
`--determinism` renders the act's first frames alone and in sequence and fails on the first frame that differs. A web
shot inside a Remotion act is handed in with its act (`handin.act<N>.shot.<ID>.*`). After a re-voice, emit-events
reports what moved in `timing/visual_events/changes/act<N>.json`.

### Handing in a web act

An act built for the open web renderer (`scenes/act<N>/web/`, started with `slate engine scaffold --act <N>`) hands in
with the same `slate emit-events --act <N>` and `slate check <N>`, through that renderer. Its scene scripts are
type-checked from the film folder like any act, and its page is opened once in a dry-run emit (nothing written), which
hands back its beats, its word lookups and what the kit had to assume. On top of the gates above:

| Gate | What it proves |
|---|---|
| `handin.act<N>.page` | the page loads and draws its first frame in the open web renderer without an error (a page the renderer can't open is UNCHECKED, with its next step) |
| `handin.act<N>.network` | the page reached for nothing outside its own folders (the renderer can't reach the network, and a request that tried is a finding) |
| `handin.act<N>.fonts` | the brand's faces loaded in the page (a substituted font fails) |

Its banned words are read from its scripts, its page's text and its copy files. A web act's boundary frames aren't yet
compared with a neighbour's declared rest state (the contracts gate says UNCHECKED when asked), so check those joins by
eye and with `slate render stills` until it is.

### Checking your work

- **Stills**: `slate render stills --act <N> --frames <f1,f2,…> --scale 0.5`. Put them on a contact sheet and look hard:
  hierarchy, emptiness, legibility, the brand's look, sync with the words.
- **A draft preview**: `slate render --act <N> --draft --out <your scratch folder>/act<N>.mov` (4 motion-blur samples
  instead of 16; not registered as the act's render).
- **Previews and stills go in your own scratch folder**, never in the film folder or another builder's.
- **Scan previews, not just stills**: some renderer faults show only in sequence (a card face dropping for two frames).
- **Confirm any flicker at full size before fixing it**: half-scale previews can flicker a level or two on slowly
  drifting cards because the browser picks a different raster scale.
- **Review every transition of a product surface at 2 to 4 frame steps** as well as at full speed; a one-frame scan can't
  see a card that stays wrong.
- **Pixel-diff every hand-over** at full resolution: a flat card to its 3D twin, a morph to its final component, frames
  at rest.

Full-resolution finals are rendered centrally, one at a time, through the job queue (slate-finish). A builder never
starts one.

### The hand-in checklist

- [ ] Every shot's on-screen text matches the script's on-screen column (restaging the picture is fine; NOTES.md says
      so).
- [ ] No banned words; the claims and sample-data rules hold (slate-story, truth-packs).
- [ ] Read times hold, and body text is at least 28 px at a 1080-line frame.
- [ ] Both contracts match, held at least 6 frames.
- [ ] Any character is calm at the act's ends; its track lints clean.
- [ ] The word-miss list is empty.
- [ ] The events file lists every beat that lands (or the act says why it's silent).
- [ ] `slate check <N>` passes.
- [ ] NOTES.md says what you decided, what you restaged and what you couldn't do, and the brief's words were re-read
      against the act's checklist.

---

## Reference: Headless Chrome: CSS and assets that fail quietly

The things below render fine in a normal browser and fail, silently or intermittently, when a frame is taken by the
renderer. Build around them from the start.

### Clipping and masking

- **CSS `clip-path: path()` silently fails in headless Chrome**, and SVG data-URI masks can decode after the frame is
  taken. Use `polygon()` clips and CSS `mask-image` gradients.
- **A clip path on a transformed element rides its transform** (a corner mark switched at the wrong height). Clip on
  untransformed, full-frame wrappers.

### Type and layout

- **Positioned type inside a zero-width container wraps one word per line**: set `white-space: nowrap` on positioned
  type.
- **Text snaps to whole pixels** under slow motion (remotion-gotchas.md): move with transforms and the kit's raster
  hints.
- **Centre a lockup** (a mark beside a word, a title block) on its visible extents and the type's cap height, aligned
  on the baseline, never on its layout box: the box carries ascender and descender space the eye doesn't see.
- **SVG text under a changing transform needs `text-rendering: geometricPrecision`.** Otherwise each render tab lays it
  out at a different scale, and the motion-blur samples, which come from different tabs, double it (a resting seal
  differed by 13 levels from frame to frame).
- **Fonts**: headless Chrome can't see fonts installed locally from a web font kit. Load every face explicitly through
  the brand's font plan (Google Fonts by family, a kit URL, or an installed face the renderer can reach); the font gate
  fails the render when a face is missing rather than letting a fallback slip through.

### Textures and effects

- **Draw textured objects (grain, ink) at one base size and scale the result**, so the texture never jumps as the object
  scales.
- **Post-processing passes render blank** under Remotion's frame-by-frame loop; build the effect into the scene or drop
  it.
- **Never fake motion blur** (a CSS blur on moving things, or Remotion's own camera blur, which is 8-bit additive and
  shifts flat colours). The renderer's sub-frame average is the only motion blur.

### Footage

- **Video decoders crash long parallel renders.** Play footage (plates, captures) as JPEG sequences through `<Img>`, one
  frame per film frame (`round((t − t0) × fps)`), with every sub-sample of a frame showing the same image.
- Heavy media lives in the film's `public/` folder, linked into the bundle, never copied: copied plates once made every
  bundle 290 MB and filled the disk.

### Performance

- Prefer the kit's own components to heavy CSS on machines without a strong GPU: large blurs, big shadows and gradient
  stacks are expensive, and the renderer draws each frame 16 times.
- PNG frames are only for where alpha or lossless averaging needs them; the renderer handles that.
- Huge `translateZ` zooms rasterize badly: use a 2D camera over poses and zoom in log space.

---

## Reference: Building hinged books

`HingedBook` is a reusable physical surface in the kit's 2.5D world. It draws board thickness, an underlying page
block, a fixed last page, a hinged front cover and caller-owned recto/verso faces on curling leaves. The film owns
the faces, timing, camera staging, morphs and any stamp or comparison. Read slate-motion's physical-books.md before
staging one as the act's carrier.

### API and coordinates

Import `HingedBook`, `PageLeaf` and their types from `@slate/kit`. Geometry helpers also export from
`@slate/kit/core`, so beats and checks can use them without React.

| Input | Contract |
|---|---|
| `w`, `h` | Positive page dimensions in world pixels. Derive their size from the film's frame; choose their aspect for the object. |
| `state.cover` | Degrees: `0` closes the cover on the right; `-180` opens it on the left. |
| `state.leaves` | One angle per leaf, ordered from the top of the closed stack down. A missing angle defaults to `0`. |
| `coverOuter`, `coverInner` | Caller-owned cover faces, with their origin at the face's top left. |
| `leaves` | `{recto, verso}` pairs. Each face is laid out once in page coordinates, from `(0, 0)` to `(w, h)`. |
| `last` | The fixed right-hand page under every turning leaf, in the same page coordinates. |
| `overhang` | Cover extension beyond the free page edge and both ends of the spine. Default: `0.02 × w`. |
| `pageThickness`, `coverThickness` | Positive depth units. Defaults: `0.002 × w` and three page thicknesses. |
| `pageRadius`, `coverRadius` | Nonnegative corner radii. Defaults: `0.013 × w` and `0.035 × w`. |
| `strips`, `curl` | Whole strip count from 1 to 100, default 10; nonnegative curl strength, default 1. Zero curl makes a rigid leaf. |
| `palette` | Optional page, page-edge, cover, cover-edge and shade colours. Unspecified roles come from the brand's tokens. |

The book's origin is the **centre of the spine**. A closed page occupies `x = 0…w`, `y = -h/2…h/2`; a turned page
occupies `x = -w…0` over the same height. Face content uses its own top-left origin, so callers never mirror a verso
themselves. The kit gives that face its orientation. A cover face measures `w + overhang` by `h + 2 × overhang`;
`bookGeometry(size, leaves.length)` returns those dimensions as `cw` and `ch` for precise emblem placement.

`PageLeaf` provides the same spine-centred leaf on its own, with a caller-chosen `z`. Its `radius` controls the page's
free corners. Angles must be finite; the helpers clamp easing overshoot to the physical range `-180…0`.

### Build faces once, drive state from beats

Make a shared face component for the film's pages, expressed in the page's local coordinates. Its progress props can
reveal ink or data; it needs no private timeline. Reuse that component and one ordered face list for the whole act.

The book itself takes state rather than start times. A turn can be computed from the act's word-derived beats:

```tsx
import {roleEase, tw} from '@slate/kit/core';
import type {BookState} from '@slate/kit';

const state: BookState = {
  cover: -180 * tw(t, beats.cover.start, beats.cover.dur, roleEase('move')),
  leaves: beats.turns.map(turn => -180 * tw(t, turn.start, turn.dur, roleEase('move'))),
};
```

Here `t` is film seconds and `beats` is the act's own beat data. Register those turns with `defineMotion`, and the
meaningful page or stamp landings with `defineEvent`; the book does not emit authored events for the film. Align
contact times with the voice through the existing beat helpers, and keep the reading hold after the turn.

Place the same instance inside `Camera` and, when needed, `Place`. Reframe that object as the idea changes; retain
the same face list and accumulated marks. Camera and object transforms belong to the film's motion trace too. Rest
the camera for the hand-over between a carried mark and a cover emblem so both use the same screen position.

### Raster and depth rules

- Use `RasterModeProvider` at the act root. Put `TiltSpan` around each text block in a face, keeping shapes outside it.
- A reverse face has the same physical registration in hint and tilt modes. Tilt mode places it by transform to keep
  fractional offsets stable; its target matches the final flat page.
- Keep `preserve-3d` parents free of opacity and filters. A page may clip its own face content; an ancestor that
  flattens the whole book destroys the board and strip depth.
- Use the kit's thickness ordering. Changing a palette or face does not need a new depth stack.
- If a hand-over crosses acts, both boundary frames draw the same book state, camera, raster mode and face content
  through one shared contract component. Apply the existing [contract holds](#reference-contracts-between-acts).

### Review before hand-in

The kit includes `Kit-Book` and `Kit-Book-Hint`, neutral short compositions that open a cover and turn two leaves.
Use that mechanism proof when changing the primitive. A film adds its own complete scenario: emblem hand-over,
contact, comparison, audience view and read holds, wherever its treatment calls for them.

Record the uninterrupted sequence and inspect the moving frames, the rest switch and the settled result. Keep the
recording, frame numbers and any failure samples. Type checks and geometry tests support this review; they do not
establish that page turns, type registration or the authored sequence look right in the rendered film.

---

## Reference: The kit (`@slate/kit`)

The shared visual kit every scene imports. It draws a film in its brand's tokens, on the brand's motion law, on the
film's one clock, and it knows no brand, frame size or frame rate of its own. Its React-free half, `@slate/kit/core`, is
what an act's beats module imports, so the engine can run the same beats in Node for the events, the motion trace and
the hand-in check.

### What it reads

- **`@film/data`**, generated per film by the engine: `film` (id, size and frame rate from film.json, the only source of
  either), `shots`, and as the film gains them `vo_words`, `vo_cues`, `timeline`, `events`, `captions`, `spoken` (how
  each number or symbol is said) and `brand` (the pack, logos inlined). Never edit it; it's rebuilt from the film.
- **The brand pack**: palette tokens and roles, type families with their sources and licences, the motion law, logos
  with their build specs, the motif, the look. Every reader is forgiving and lists what it had to assume
  (`kit_problems` in the hand-in check).

### What it gives you

| Area | Pieces |
|---|---|
| Clock | `useFilmTime()`, `shot()`, `voSpan()`, `word()` / `wordTime()` (never throw), `misses()`, `frameOf()`, `contactAt()`, `ActRoot` (the sub-frame shutter), `actComposition()` |
| Motion law | named eases with exact endpoints, `tw()`, `dur()`, capped staggers, `landOn()`, `startFor()`, `defineMotion()` (the motion trace), monotone splines, `chain()` |
| Tokens and fonts | typed tokens and CSS variables (`TokenScope`), the type scale as fractions of the frame's short side, the font plan and its gate (a missing face fails the render) |
| Looks | `flat` (default), `paper-2.5d` (papery brands only), `editorial`, `blueprint`, and the AE bridge's looks by name |
| Surfaces | `Card`, `FadeCard` (fades as one sheet), `Ground`, `Grain`, `HingedBook`, `PageLeaf` ([book API](#reference-building-hinged-books)) |
| Cameras | `Camera` (look-at, dolly in z), `WorldLayer` (2D, identity at rest), `camAt`, `lerpCam`, `drift2D` |
| Type | `PerChar` (capped), `PerWord`, `Arrive`, `CountUp` (each figure held three frames), `KineticWords` |
| Product UI | surfaces, buttons, fields, chips, pills, progress, avatars, streaming text (`ui.tsx`) |
| Charts | distributions, bars, lines, radar, rings, axes, markers |
| Logos | `LogoBuild`, `LogoSting`, `Ripple` from the brand's SVG and build spec |
| Motif and character | `MotifMark`, `MarkCharacter`, `gesture()` (slate-motion) |
| Captions | burned-in captions from `timing/captions.json` in the brand's font |
| Placeholders and review | `PlaceholderAct`, `KitReviewSheet` |

### The rules it keeps for you

Exact 0 and 1 at the ends of every ease; lookups that never throw; no spline overshoot; staggers capped at 0.6 s and
half the entrance; nothing scales from zero (kinetic words start at 85%); a count-up holds each figure for three frames
and never re-centres (`CountUp` draws over an unseen box: the count's own shape in nines until it has the final
value's figures, then the final value; a suffix holds still at its right end, and `followed` keeps a word after the
count from moving);
a fading card fades as one sheet; clips on untransformed wrappers; raster hints only while moving; a world layer
untransformed at rest; a motif that moves as a whole below its size threshold, never loops but to breathe, and
overshoots only where the brand allows.

Don't re-implement any of these locally: the films had nine copies of one timing table and six copies of one ease
wrapper, and every copy drifted.

### Rules for using it

- **Import it; never edit it from an act.** A builder who needs a kit change writes it up in the act's NOTES.md and
  works around it locally until the coordinator changes the kit.
- **A kit change is additive and opt-in**: without its new prop a component draws exactly as before. Before it lands,
  `slate engine golden` (the kit's own stills) and `slate engine golden --approved <film>` (every approved act's
  boundary frames and one frame per shot, at 45 dB against the approved render) both pass.
- **Reuse grounded components** (surfaces already matched to the product) rather than redrawing them.
- **Shared product surfaces are timeline-free faces drawn in card pixels**: a kit `Card` places one at the builder's
  pose, and 0-to-1 progress props from the act's beats drive its states, so any act can reuse it. A surface first drawn
  on one film's timeline is adapted once, when it's shared.
- **A surface a character sits in exports that slot** (its position in card pixels), and the character is drawn in the
  same card at the slot, never as a second copy.
- **Every shared surface has a cell in the film's kit review sheet.**
- **A helper that places something against text** (an underline, a marker) measures from the text's real origin and
  width in the loaded face (the kit's `measureText`), never an assumed offset: one underline sat 64 px right of its
  word.
- **Bookends reuse the same component** as the opening, with the closing's timing, never a redraw.
- **Author a world at film scale and screen-aligned at rest**, so rest frames are pixel-exact.
- **Lay out text with room** for words that arrive later, so no make-room move is needed.
- **Never fake motion blur**: the renderer averages 16 sub-frame samples across a 180-degree shutter.
- Audit the film's own shared components for repeats now and then; a repeat is a component waiting to be promoted.

### Kit review sheets

`KitReviewSheet` lays the kit's components out in the brand's tokens, for onboarding's look review and for settling
open look questions side by side. Render them as stills (`slate render stills`) or as a short moving test. Shot-recipe
cards with motion previews, one per shot type (as some open Remotion projects publish them), are good prior art for what
a review sheet should show; Remotion's licence still applies to anything built from them.

### Optional helpers

Vector drawing (an SVG character, arrows, a diagram), static frame design, component looks for a brand without a design
system, and script polish all have optional helper skills (asset-creator, canvas-design, frontend-design,
avoid-ai-writing). They help builders; none is a dependency.

---

## Reference: Remotion and headless Chrome: rendering traps

Remotion renders each frame in headless Chrome, and Slate's renderer draws each frame 16 times across the shutter and
averages them. Both are exact and unforgiving. These traps each cost a re-render on the first films.

### Smooth motion, crisp rest (raster stability)

Headless Chrome snaps text, and boxes placed by `left`/`top`, to whole pixels as it rasterizes. Under slow motion (a
drift, the tail of any ease) a line of type then steps a pixel at a time while the shapes around it glide: the film
looks jittery and shaky. The kit's answer changes no design, timing, layout or stacking:
- **`Card` and `Camera` carry raster hints when told they move**: pass `atRest={!poseMoving(pose, t)}`. The layer is
  hinted while it moves and drops the hint the frame it stops.
- **An element moved by its own transform** gets a key that changes each whole pixel of the move and once at rest, plus
  the kit's mover hint; `PerChar`, `PerWord` and `Arrive` do this for you.
- **Any other layer that scales by more than about 5%**: `key={rasterKey(scale)}` and `motionHint(moving)`.
- **Move with transforms, not `left`/`top`/`width`**, whenever something moves slowly or settles.
- **A box that grows or settles slowly is sized by a transform too**: a tile growing out of a line, a fill rising to its
  level, a segment, an axis, ticks, dividers, drop lines, row backgrounds through a fold, an edge shadow. Lay it out at a
  whole-pixel size and draw it to its exact place and size with `translate` and `scale`, counter-scaling its content so
  type keeps its size. Laid out by height or width, such a box settled a pixel at a time (a 15% tile and its number
  stepped −1.1, −1.0, −1.0 px as they came to rest).
- **Every raster switch can tick the text up to half a pixel.** Don't switch a hint on or off in place on something
  visible and still; a layer whose last rebuild falls just before it settles can keep one raster through its rest.
  Prefer a few percent of softness to a visible jump.
- **Keys must be named and unique among siblings** (Determinism, below).
- **A half-scale, one-sample preview hides this.** One act was approved from such a preview, and its 16-sample final
  shook: type stepped a pixel at a time under a slow push. Before a final, render short 16-sample windows of the risky
  moves (slow pushes, the tails of long eases, text rising on its own) through the real render path, and check them at
  full size.

#### Tilt mode: crisp type under slow moves (opt in per act)

Hint mode, above, is the default and costs type about 15% of its sharpness under a slow push. Tilt mode draws type
under a skew too small to see (0.034° at full size), so Skia places each glyph at quarter pixels: as crisp as a fresh
raster, and two renders bit-identical. An act opts in with one wrapper at its root,
`<RasterModeProvider value={actRasterMode()}>`; the kit's `README.md` ("Raster modes") has the whole contract. The
rules that bite:

- **Tilt type only, never shapes.** A tilt moves everything else off whole pixels; keep tilted boxes tight around their
  type, and give a wide card with thin lines far from its centre `faceTilt={false}` and a `TiltSpan` around each text.
- **Inside the layer, after the text's own transform**: `<TiltSpan>` inside anything with opacity below 1, a filter, a
  blend mode or a blur; `useTypeTilt()` or `<TypeTilt>` for type you move yourself. Never on a composited layer's own
  transform or above one.
- **Running text tilts as one block**, never per character; a trailing character fades by its colour's alpha.
- **Move boxes by transform**, and **a card whose size morphs takes `morphPose`** (whole even layout sizes).
- **Both acts on a boundary render in the same mode**, and a text left untilted on purpose says why
  (`data-slate-untilted="<why>"`).
- **Prove it before and after.** No act converts until the kit's stability bench passes on this Mac
  (`slate qa stability conformance --render --detach`). Then convert one act at a time: `slate check <act> --markup
  --against <ref>` proves the conversion is a no-op in hint mode and audits the tilt rules without rendering, and the
  `stability` gate checks the act's render.

### Depth sorting and stacking

- **Several parallel 3D planes stacked close together make Chrome's depth sorting race**: a card's face dropped for two
  frames in a preview while stills of the same frames were clean. Avoid extra parallel planes, and scan previews, not
  just stills.
- **Use 3D for one object at a time** and keep everything else flat, drawn in document order: planes crossing inside one
  3D context swapped stacking mid-move, cut words in half and ghosted cards through each other.
- **A card tilting through another element's plane gets sliced** by it for a few frames: keep moving cards in front of
  the planes they pass.
- **Overlapping cards keep one depth order** for as long as they overlap; objects that move against each other live in
  separate cameras, so their stacking is plain document order and can't flip.
- **Declare the stacking explicitly**: a back-to-front list of layers per scene, each its own context.
- **Opacity or a filter on a 3D group flattens it**, and a translucent card shows its thickness layers through its face:
  put opacity and blur on leaves, and fade a card as one flat sheet (the kit's `FadeCard`).
- **3D planes that meet edge to edge crack along the seam** and shimmer in camera moves: run every plane about 3 px
  past its shared edges.

### UI belongs to its card

Print a button (or any control) on the card that owns it, so it moves and clips with the card. Never float it in front
at a fixed position: a floating button was once left behind on the bare page when its card moved.

### Geometry that shouldn't be there

- **Remove geometry that's never meant to be seen**: a block hidden under a flat sheet only ever showed as a panel
  popping in when the sheet lifted, and it hid the sheet's own shadow.
- **Zero-length dashed lines still render a dot.**
- **Mount every component before its first animated frame and hide it until then**: a row mounted partway through a
  draw starts mid-move (a dash popped in at 45% of its length).

### Determinism

- The GPU renderer isn't bit-exact run to run (about one level): call a frame "changed" only when it differs from both
  of two baseline renders. Software GL is bit-exact.
- **Every rebuild key** (a raster or tilt key that remounts a layer) **is named and unique among its siblings**: two
  siblings sharing one were drawn wrong, one label shown twice.
- A lookup that throws at module load breaks every composition in the bundle; the kit's never do.
- A half-written act can break the bundle for everyone: the hand-in check's type check and module load catch it.
- **To find which frames a change can affect without a browser**, render the act's scene components to static markup
  for every frame, before and after (react-dom/server's static renderer), diff the markup, then pixel-compare only the
  frames whose markup changed.

### Load

Under heavy machine load, raster tiles can go missing (grey) for a frame. Render at moderate concurrency through the
queue, one heavy job at a time, and let the glitch scan catch what slips through.

---

## Reference: Where Slate overrides Remotion's own skills

Remotion publishes agent skills of its own. Slate installs them inside its engine folder (never globally) so agents
can read Remotion's API guidance, but where they disagree with Slate, Slate wins. Read theirs for API details; follow
Slate for anything below.

| Remotion's skill says | Slate does instead | Why |
|---|---|---|
| Voice-over with an older multilingual TTS model and its settings | Slate's voice stages on the brand's pinned model (slate-voice) | the best current model, pinned per film, with the voice checks |
| Sound effects from a library that points at meme sounds | designed sound from the picture's own events (slate-sound) | sound is designed, never stock |
| Captions from a GPU Whisper that doesn't run everywhere | captions built from the voice's word timings (slate-voice), burned in by the kit in the brand's font | word-exact, on the film's clock, portable |
| Preview in Remotion's Studio | stills and draft renders through `slate render`; the Studio, if a person ever starts it by hand, runs with `--no-open` and never opens a browser | nothing opens a browser |
| `CameraMotionBlur` for motion blur | the renderer's 16-sample average across a 180-degree shutter, in 16-bit | Remotion's blur is 8-bit additive and shifts flat colours |
| `OffthreadVideo` for footage | JPEG sequences played from film time | decoders crash long parallel renders |
| Render with the Remotion CLI | `slate render` (chunked, resumable, proven splices, the job queue, disk reserved, bundle cleaned up) | renders must survive a dying agent and never fill the disk |

### The engine

- Remotion is pinned exactly in Slate's engine (upgraded only after a parity check proves nothing changed, and never to a
  new major version unplanned).
- One bundle per film per source hash, reused for every act and still, then deleted.
- Scenes reach the kit and the film's data by alias (`@slate/kit`, `@film/data`), never by relative paths out of the
  film folder.
- Scenes are type-checked from the film folder with the engine's own TypeScript.

### Licences

Remotion is free for individuals and small teams and needs a company licence above that (slate, licences.md). Slate
never redistributes it; the open web renderer and After Effects are the routes that need no Remotion licence.
