---
name: "slate-voice"
description: "Cast, design, direct and record the voice of a Slate film, then clean, pace, align and caption it. Covers casting shootouts and Voice Design with measured ranking, directing eleven_v4 with audio tags (never whisper, soft, quiet or gentle tags), voicing every line with its neighbours as context, cleanup, pacing, word timings, captions, the voice checks, and the cloning policy (designed or library voices by default, the owner's own verified professional clone, never anyone else's). Use when a Slate film needs a narrator chosen or designed, lines voiced or re-voiced, a take cleaned or re-timed, captions made, or a question about which voices may be used."
---

> Knowledge-only edition of Slate's `slate-voice` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-voice

The voice carries a film. Slate voices every line on ElevenLabs' best model, one take per line with the neighbouring
lines as context so the reads flow as one narration, then cleans, paces and times them, and checks every take before
anyone hears it. The owner picks voices, takes and direction by ear: measurements shortlist and catch faults, they
never decide.

This is stage 4 of the production (voice), and it feeds stage 5 (timing). Every paid call goes through the ledger and
replays offline in tests (`SLATE_FAKE_VENDORS=1`); `--live` spends.

## 1. The profile and the cloning policy

The brand's pack holds its voice profile (provider, voice id, model, settings, lexicon of brand words); a film pins
what it uses at first use, so a re-voice in week three matches week one.

- **Designed or library voices by default.**
- **The owner's own voice** may be an ElevenLabs professional clone, which the owner verified with ElevenLabs
  themselves. An agent never does that verification.
- **Anyone else's voice** only as a real recording, never a clone, and never a public figure's.
- Autonomous agents may narrate with the owner's own clone; their films are still held for the owner.

The policy is enforced before any request is sent: a refused voice exits 1 with the reason. See
[voice policy](#reference-voice-policy-who-may-be-voiced-and-how).

## 2. Cast or design the voice

- **Cast**: `slate voice cast --voices <id,id,…> --shots <S01,S02>` has several voices read the same lines, measures
  them (pace, pauses, pitch range, noise floor, every word heard, brand words said in full), ranks them, and makes a
  level-matched, labelled listening reel. See [casting](#reference-casting-choosing-a-voice-by-ear).
- **Design** a new voice from a brief: `slate voice design --description "<prompt>" --text "<preview text>"` makes
  Voice Design previews (always on the design model), measured and ranked; keep one with `--save`; then check the kept
  voice on the production model with `--check`, because designed voices can come out higher and faster there. See
  [voice design](#reference-designing-a-voice).
- The **shortlist** goes to the pre-production sitting. The owner picks by ear; the pick is recorded with its model,
  settings and seed.

## 3. Direct it

Direction on eleven_v4 is **audio tags**: short instructions in square brackets where the delivery should change,
such as `[warmly, with a smile]` or `[confident]` before a line, or `[short pause]` for a beat.

- **Never use a tag that lowers vocal effort or adds breath**: whisper, soft, quiet, gentle, hushed, murmuring, breath,
  intimate, calm or a low voice, in any form. They make a read sound whispery and a little scary. Slate refuses them
  before any request is sent, for every brand.
- Emotion comes through a full, clear voice: warm, with a smile, bright, confident, reassuring, encouraging, sincere,
  matter-of-fact, hopeful.
- A tagged line strips back to the script exactly: tags never change a word. Tag sparingly (about half the lines or
  fewer), one emotion per phrase; a tag at the head of a line carries across it.
- If a line doesn't land, swap the tag rather than rewriting the words.
- Every tagged take is measured against the voice's own untagged takes of the same words, and one that measures
  breathier, softer, creaky, repeated or too long is rejected, however good its tag.

The tagged script lives in `voice/direction.json`; `slate voice --help` lists the direction tools (setting, checking,
stripping and A/B-testing tags). The full guide: [v4 tags](#reference-directing-elevenv4-with-audio-tags); settings and context:
[directing](#reference-directing-the-read-settings-context-and-timing).

## 4. Voice every line

```
slate voice tts --estimate      # what it will cost, nothing spent
slate voice tts                 # one take per line, with the neighbouring lines as context
```

- Each line is voiced with its previous and next lines as plain-text context (tags stripped), so the narration flows.
- The model, voice, settings, seeds and request ids are pinned at first use; `--repin` needs the owner's name and a
  reason.
- Existing takes are kept; approved takes are locked by hash and never regenerated without `--force` and a recorded
  spend approval.
- Long batches can run as a queued job: `--detach` returns a job id.

Re-voicing, leaked tails and reusing approved takes: [takes and re-voicing](#reference-takes-pins-and-re-voicing).

## 5. Clean and pace

- `slate voice clean --diagnose` measures each take's noise floor; `slate voice clean` applies the approved chain (a
  denoiser that tracks the floor, with a gentle gate). `--method isolator` uses Voice Isolator, and `--remix` makes
  Voice Remix previews that keep the voice and change only the recording. Offer a few labelled cleanup variants and let
  the owner pick by ear. See [cleanup](#reference-cleaning-a-voice).
- `slate voice pace` shortens long pauses and quickens the read gently with Rubber Band (formants kept), because
  eleven_v4's own speed setting barely moves it. See [pacing](#reference-pacing-a-read).

## 6. Align, caption, time

```
slate voice align                   # word timings (Whisper by default), recorded with the model and version
slate voice captions                # SRT, WebVTT and timing/captions.json, timed to the words
slate script build --from-takes     # every voiced shot re-timed from its take
slate timing                        # the film's clock
```

Word starts are snapped to each take's energy onsets. Forced alignment on ElevenLabs is for evaluation until it's
proven against Whisper. Captions are at most 2 lines of 42 characters, 17 characters a second, at least 1 s each,
never overlapping, and word for word the script. See [alignment](#reference-word-timings) and
[captions](#reference-captions).

## 7. The voice checks

Before the owner hears a take, it passes the voice checks (listed in `slate voice --help`, recorded in
`qa/gates.json`):
- **policy**: the voice may be used;
- **direction**: no banned tag, and every tagged line strips back to the script exactly;
- **takes**: every line has a take;
- **words**: Whisper hears every word, and every brand word in full, with no repeats and no tag read aloud;
- **tails**: no sound from the next line leaking into the end of a take;
- **fit**: each read fits its shot, starting a short lead in and ending before the cut.

Replayed takes (in tests) are UNCHECKED, never passed.

## 8. Approval and locks

Takes are approved by ear, each against its exact bytes, and approved takes are locked by hash. The voice shortlist
belongs to the pre-production sitting; individual takes come in packets. Re-voicing an approved take needs `--force`
and a recorded spend approval, and re-voices only the lines that changed, with their neighbours as context.

## References

- [voice-policy](#reference-voice-policy-who-may-be-voiced-and-how): who may be voiced, clones, labels, character voices.
- [casting](#reference-casting-choosing-a-voice-by-ear): shootouts, reels, choosing by ear, long reads, dialogue.
- [voice-design](#reference-designing-a-voice): the voice brief, prompts, previews, the production-model check.
- [directing](#reference-directing-the-read-settings-context-and-timing): settings, context, timing from the text, consistency.
- [v4-tags](#reference-directing-elevenv4-with-audio-tags): the tag families, the rules, the banned tags, measuring every tagged take.
- [cleanup](#reference-cleaning-a-voice): the floor, the chain, Voice Isolator, Voice Remix.
- [pacing](#reference-pacing-a-read): shortening pauses, Rubber Band, what the speed setting doesn't do.
- [alignment](#reference-word-timings): Whisper, onset snapping, forced alignment, word misses.
- [captions](#reference-captions): the caption rules, sidecars and burned-in captions.
- [takes-and-revoicing](#reference-takes-pins-and-re-voicing): pins, locks, leaked tails, re-voicing with neighbours.

---

## Reference: Word timings

Every beat in a Slate film is keyed to the voice's words, so word timings are the film's clock. They come from the takes
themselves, after cleaning and pacing.

### Whisper by default

```
slate voice align                     # every take, with Whisper (local, free)
slate timing words                    # re-time the words and rebuild the timing files
```

- Whisper's turbo model with word timestamps, run locally; the model and its version are recorded in the evidence of
  every result that uses them.
- **Word starts are snapped to the take's energy onset** (within about 80 ms, on a clear rise), because Whisper's word
  starts can be off by tens of milliseconds.
- Results are cached per take by its hash: a take that changes is re-aligned; one that doesn't isn't.

### Forced alignment is for evaluation

ElevenLabs' Forced Alignment (`--engine elevenlabs`) is paid per minute of audio. It stays an evaluation until it's been
compared with Whisper on approved takes (`--compare` writes the per-word differences), and the owner decides whether to
switch. Whether the newest TTS model returns its own timestamps isn't documented; verify before relying on it.

### Whisper's quirks

- It writes numbers as digits and symbols as symbols: word lookups match through the language's spoken forms both ways,
  so "twenty twenty-six" finds "2026".
- Over digital silence at the very end of a track it can hallucinate a repeat of the last phrase: ignore silent tails.
- It can mishear a brand word: the lexicon tells the checks which words must be heard in full.
- For reference analysis (someone else's film), take the voice's text from Whisper with a second model agreeing on
  disputed lines, never from a generation vendor's scene analysis (which once paraphrased the on-screen text instead of
  the voice).

### Word misses

- A word lookup (`word()` in the kit, `word_time` in Python) never throws: when a word can't be found it returns an
  estimate from the line and records a miss.
- `slate timing misses` lists them; the list must be empty before any act is handed in.
- A miss usually means the script and the take disagree (a changed word, a number spoken differently): fix the script or
  the take, never the timing file.

### After alignment

```
slate script build --from-takes
slate timing
```

The storyboard is re-timed from the takes, and the timing files are rebuilt on the film's clock. Once an act render is
registered, the timing locks.

---

## Reference: Captions

Captions come from the script's words and the voice's word timings, so they're word for word what's said and exactly
in sync. They're built once and used twice: as sidecar files for platforms, and burned in by the renderer where the
format asks for it.

### Building them

```
slate voice captions
```

writes `timing/captions.json` (the cues, for the renderer and the checks) and `voice/captions/<film>.srt` and `.vtt`.

### The rules

- At most **2 lines of 42 characters**.
- At most **17 characters a second**; a cue that would read faster is held longer.
- At least **1 second** on screen.
- **Never overlapping**, and in order.
- **Word for word the script** (the booth script, not what Whisper heard), including how numbers are written.
- Breaks at natural phrase boundaries; never split a name or a number across lines.

`slate qa captions` checks every rule against the delivered captions.

### Burned-in captions

Social reels (9:16) usually carry burned-in captions: the kit draws them from `timing/captions.json` in the brand's own
font, inside the platforms' safe zones (slate-motion, safe-areas.md), styled by the brand pack. They're part of the
picture, so they're checked by OCR with the rest of the frame.

### Sidecars

Deliver SRT and WebVTT alongside the masters for every platform that takes them (slate-finish). A derived film in
another language gets its own captions from its own script and takes.

### Language

v1 speaks English, but the caption code carries no English literals: line-break and punctuation rules live in language
tables, so another language arrives as data.

---

## Reference: Casting: choosing a voice by ear

A casting shootout has several voices read the same lines, measures every take, and gives the owner a listening reel.
The owner chooses by ear; the measurements only filter out takes that fail and put the rest in a sensible order.

### Running a shootout

```
slate voice cast --voices <voice-id>,<voice-id>,<voice-id> --shots S01,S05
slate voice cast --text "<a line that matters>" --name opening-line
```

- Pick lines that matter: the opening line, a line with the brand's name, a line with a number, the emotional peak.
- Every candidate reads the same lines on the production model with the same settings.
- Each take is measured: pace (words a second), pauses at full stops and turns, pitch range, falling endings on
  statements, the noise floor, and whether Whisper hears every word, including each brand word said in full.
- The reel is level-matched (every take at the same loudness), labelled, and plays the takes one after another, so the
  owner compares voices, not volumes.
- A clone or a famous voice among the candidates is refused before anything is spent.

### Choosing

- **The owner picks by ear.** Record the pick with its model, settings and seed, and pin it.
- **Try the pick inside the approved sound** before committing: the same proof mix with the new voice, checking
  loudness and a Whisper read.
- **Brand words decide close calls.** One engine clipped the brand's name on the first film; the best current model said
  it in full. Put every brand word in the lexicon so the checks listen for it.
- **Time shots from the real reads.** A deliberate narrator can read 1.5 to 3.2 words a second; the shots are re-timed
  from the takes after voicing.

### Which engine and model

- Narration runs on ElevenLabs directly, on its best model (recorded in `registry.json`, pinned per film). A generation
  vendor's own TTS route gave lower bitrate, allowed only a few jobs at once, and clipped a brand word.
- For long reads (60 to 120 seconds of continuous narration), A/B the best model against the vendor's most stable
  long-form model before choosing.
- For pieces with several voices, the vendor's dialogue endpoint takes requests up to about 2,000 characters, any number
  of speakers, and previous and next context.
- Check the best models against the live API at the start of a project; the catalogue changes.

### The shortlist at the sitting

Bring two or three voices to the pre-production sitting, each with its reel entry and a one-line note (what it does
well, what to listen for). Measurements go in the notes, not in the pitch: the owner is choosing a voice, not a number.

---

## Reference: Cleaning a voice

Most takes need little or nothing. When a voice carries noise, the cleanup must remove the noise and keep the voice:
the owner chooses between variants by ear.

### Diagnose first

```
slate voice clean --diagnose
```

- Measures each take's noise floor and where it lives in the spectrum.
- A designed voice can carry a baked-in artifact (a faint buzz between about 5 and 12 kHz) that's present even in
  lossless output: it's in the voice, not the codec, so a better format won't remove it.
- Request the best format the plan allows (lossless PCM needs a higher plan); Slate records any fallback.

### The options

| Method | What it does | When |
|---|---|---|
| The default chain (`slate voice clean`) | a denoiser that tracks the take's own floor, then a gentle gate | most takes with a steady floor |
| Voice Isolator (`--method isolator`) | the vendor's isolator | background noise that isn't in the voice; it lowered a baked-in buzz only about 2 dB |
| Voice Remix (`--remix --text "<line>"`) | re-generates the recording with the same voice | an artifact in the voice itself; prompt it to keep this exact voice and change only the recording, at a modest prompt strength (about 0.25 to 0.5), across a few seeds, lossless output |
| A custom chain (`--chain`) | your own filter chain | when the owner picked one |

### Letting the owner choose

Offer three to five labelled variants of the same line (level-matched, side by side) and let the owner pick by ear. On
the first films, the owner's pick was a floor-tracking denoiser with a gentle expander, chosen from five. Record the
chosen chain and use it for every take of that voice.

### Rules

- Clean every take of a voice the same way, so lines match.
- Never clean an approved take in a way that changes it without a new approval: the approval is bound to its bytes.
- Clean before pacing; pacing works on the clean take.
- Whisper still has to hear every word after cleaning.

---

## Reference: Directing the read: settings, context and timing

### Settings

eleven_v4 has two settings: **stability** and **similarity**. Style and speed aren't available on it, and neither is
SSML.
- **Stability** trades consistency for expressiveness. Too low gives odd, random, rushed reads; too high goes monotone.
  Start at 0.5 and change it only when a probe earns the change: on the first films a looser 0.35 changed the waveform
  and nothing else (the tags didn't land better).
- **Similarity** raises adherence to the reference voice at some cost to naturalness, and can reproduce flaws in the
  source recording. The voice's stored value (often about 0.75) is the start.

### Context

- Each line is voiced with its **previous and next lines** as context, so the narration flows as one read. The context
  carries the neighbours' **plain words**, with tags stripped: a tag belongs to the line it directs. (Tagged context was
  tested: harmless, and no better.)
- Request ids of neighbouring takes can stitch generations more tightly than text, within a couple of hours; the voice
  stage handles it.
- Context can leak: the next line's first sound sometimes appears at the end of a take (takes-and-revoicing.md).

### Timing comes from the text

On eleven_v4, identical text and context gave sample-identical lengths across seeds and stability values. So:
- **change pacing through the text**: punctuation, tags, line structure;
- **regenerating** changes texture and inflection, not timing;
- **air after heavy lines comes from the edit** (a longer hold in the shot), not from pause tags; use pause tags
  sparingly.

### Consistency across a film

- One small tag vocabulary, the same settings and the same context rule on every line.
- The model can shift over time as the vendor retrains it: record the seed and request id of every take, so a re-test
  is comparable, and pin the model per film.
- Tagged takes can come out 1 to 2 dB quieter than untagged ones; the mix levels each take by its voiced loudness, and
  A/B clips are level-matched.

### Punctuation is direction

- A full stop gives a beat; an ellipsis adds a trailing pause and weight; a line break gives a longer beat.
- A dash cuts the speaker off; an exclamation mark adds intensity; capitals add emphasis.
- A question lifts: don't end a statement with one.

### When a line doesn't land

1. Listen to what's wrong: pace, pitch, a word, an emotion.
2. Swap the tag (or move it to the exact clause) and regenerate. Don't rewrite the words.
3. If the words must change, change them in the script on purpose, rebuild, and re-voice with neighbours.

---

## Reference: Pacing a read

eleven_v4's speed setting barely moves a read (take-to-take variation is bigger than the setting's effect), and
regenerating changes texture, not timing. So pace is adjusted after the take, gently, keeping the voice natural.

### What `slate voice pace` does

1. **Shortens long pauses**: pauses longer than about a quarter of a second are cut to about 0.8 of their length, from
   the middle, so the breath and the onset either side stay intact.
2. **Quickens the read slightly** with Rubber Band's highest-quality engine (about 6% faster on the first films), with
   formants kept, so the voice's timbre doesn't shift.

Options: `--no-tempo` (pauses only), `--tempo <factor>`, `--min-pause <seconds>`, `--pause-keep <fraction>`.
`slate voice pace --check-tools` reports the Rubber Band build: an Intel build running under Rosetta is flagged, and the
installer can replace it with a native one.

### Rules

- Keep it natural: a narrator who sounds hurried is worse than a shot that's a little long. Re-time the shot instead
  (the storyboard re-derives shot lengths from the paced takes).
- Whisper must still hear every word after pacing.
- Pace every take of a film the same way, so the narration matches itself.
- Pacing never makes a read fit a shot it doesn't fit. If a read is far too long, the line needs fewer words (slate-story)
  or the shot needs more time.
- Pacing is a derived file: the raw and clean takes are kept, so it can be redone.

### Where pace is set

- **In the script**: at most 2.6 words a second per shot, planned from the words (slate-story).
- **In the text**: punctuation and structure (directing.md).
- **After the take**: this stage.
- **In the edit**: holds and air around heavy lines, set by the shot lengths.

---

## Reference: Takes, pins and re-voicing

### One take per line, pinned

- `slate voice tts` voices every line of the script, one take per line, with the neighbouring lines as plain-text
  context. The takes and their records live in `voice/` (which take is selected, its raw, clean and paced files, its
  alignment, and whether it's approved).
- At first use the film pins the model, the voice id, the settings, each line's seed and each request id. A registry
  refresh never changes a pinned film; moving a pin needs the owner's name, a reason and ideally an A/B as evidence.
- Existing takes are kept unless you ask for new ones.

### Approved takes are locked

- An approved take is locked by its content hash. Regenerating it needs `--force` and a recorded spend approval: the
  owner's yes to spend again on something already paid for.
- **Reuse, never regenerate, approved assets.** When the film changes around an approved take, re-time the shot, not
  the take.
- Superseded takes are archived (with a note of what replaced them), never deleted.

### Leaked tails

Context-conditioned speech can leak: the next line's first sound appears at the end of a take (on the first film, a
line ended with the first consonant of the next line's first word, and the owner heard it). So:
- the tails check scans every take's end for sound returning after silence;
- the fix is to **trim** the take after its last word decays (the trim is recorded with the take), never to regenerate an
  approved take for it;
- the dialogue stem is digital silence at the trimmed point.

### Re-voicing

When a line's words change (a correction, a claim removed):
1. Change the script, rebuild it (slate-story).
2. Re-voice **only the changed lines**, with their neighbouring lines as context, at the same delivery (the same voice,
   model, settings and cleanup), so they match the lines around them.
3. Whisper must hear the new lines word for word; the new takes must fit their shots.
4. Re-time, re-render the affected range and splice it (slate-finish), re-mix, re-run the gates.

Because every beat is keyed to words, the picture follows the new timing automatically; nothing is re-timed by hand.

### Fitting the shot

Every read fits its shot: it starts a short lead into the shot and ends at least a short tail before the cut. The fit
check measures each paced take against its shot's room. A read that doesn't fit gets a longer shot (the storyboard is
re-timed from the takes), fewer words, or a gentler pace, in that order of preference.

### Brand words

Every take is checked for the brand's words said in full. A clipped brand word is a failed take, whatever else is right
about it.

---

## Reference: Directing eleven_v4 with audio tags

An audio tag is a short natural-language instruction in square brackets, placed where the delivery should change:
`[warmly, with a smile] Hi, it's good to meet you.` The list of tags is open (they're direction, not a fixed menu), and
v4 follows them more reliably than earlier models, though not perfectly. Tags are billed as characters.

### The rule above all: full voice only

**Never use a tag that lowers vocal effort or adds breath.** That means whisper or whispering, talking softly, soft or
softly, quiet or quietly, gentle or gently, hushed, murmuring, under one's breath, breathy, intimate, calm, and a low
voice, in any form or combination. The owner heard them as whispery and a little scary. Even a tag that sounds harmless
("calm and reassuring") measured breathier than the voice's untagged reads. Slate refuses these words inside any tag
before a request is sent, for every brand; a brand can ban more, and nothing can un-ban these.

**Emotion comes through a full, clear voice**: warm, with a smile, bright, confident, reassuring, encouraging, sincere,
matter-of-fact, hopeful.

### The families (safe examples)

| Family | Examples that work |
|---|---|
| Emotion | `[happy]`, `[excited]`, `[thoughtful]`, `[curious]`, `[hopeful]`, `[delighted]`, `[impressed]`, `[reflective]` |
| Delivery and register | `[confident]`, `[warmly]`, `[reassuring]`, `[sincere]`, `[matter-of-fact]`, `[encouraging]`, `[conversational tone]`, `[professional]` |
| Longer narration direction | `[warm, conversational tone]`, `[bright, friendly, smiling]`, `[candid, kind]`, `[voice rising into firm resolve]` |
| Pacing and pauses | `[pause]`, `[short pause]`, `[long pause]` |
| Reactions (non-verbal) | `[laughs]`, `[chuckles]`, `[sighs]`, `[clears throat]`: only when the voice's character suits them |

Two families exist that a film narrator almost never wants: **sound effects** (the model can perform a tag as a sound
effect; a film's sound is designed separately) and **accents or singing**.

### The rules

**How many**
- Don't tag every line: v4 infers emotion from well-written text. Tag about half the lines at most.
- One emotion per phrase. A tag at the head of a line carries across the whole line.

**Where**
- Immediately before the segment it modifies (a reaction can follow it). If the feeling changes mid-sentence, put the tag
  before the exact clause.
- A softening tag in the middle of a line is where creak appeared on the first films: prefer the head of the line, and
  give any mid-line tag a creak check.

**Wording**
- A tag describes something you can **hear**, never a face, a gesture or music (not `[grinning]`, `[standing]`, `[music]`).
- Be explicit about voice quality, and word tags so they can't be read as a sound cue: describe the voice, never an
  object or an event.
- Match tags to the voice's character: a serious professional voice doesn't suit playful tags, and a designed voice is
  never asked for a performance it wasn't designed for (laughing, big emotion).

**The words**
- Tags never change a word. A tagged line must strip back to the script exactly (Slate refuses one that doesn't).
- If a line doesn't land, swap the tag rather than rewriting the text, then regenerate.

**Pauses**
- v4 has no SSML. Pause with punctuation and structure (an ellipsis adds pause and weight, a line break a longer beat) or
  a pause tag, sparingly. Air after heavy lines comes from the edit.

### What tags do, measured

On the first films a smile tag lifted the pitch about 2.4 semitones and brightened the voice; a brighter variant lifted
about 3.4 semitones, which risks sounding perky. Tags work, modestly. They also brought failures: one smile tag alone
before a short line made the model say the phrase twice, and a mid-line softening tag put the voice into creak. So
every tagged take is checked.

### Failure modes, and the guard for each

| Failure | Guard |
|---|---|
| A tag read aloud | tags stay inside the voice's character; Whisper checks every take for tag words spoken |
| A tag performed as a sound effect | tags name voice qualities, never objects or events |
| Over-acting | tag sparingly, one tag per segment, stability kept at its start value; pace and pitch range measured against an untagged control |
| A repeated phrase | a word-for-word check on every take |
| Creak (vocal fry) on a key phrase | a creak count (low, irregular pitch frames) against the untagged baseline |
| Drift between lines | one small vocabulary, the same settings and context rule; seed and request id recorded per take |
| A pause that breaks the edit | pause tags only where the edit can't give the air |
| A take that no longer fits its shot | every paced take measured against its shot's room |

### Measuring breath and effort

Every tagged take is measured against the same voice's untagged takes **of the same words** (several of them, so the
normal spread is known), on the spans the tag governs and on the whole line:
- **breath and whisper**: the voiced fraction of speech, cepstral peak prominence, harmonics-to-noise, the first-minus-
  second harmonic, spectral tilt, and effort (the span's level against the rest of the take);
- **warmth and smile**: pitch level and range, formants, spectral centroid;
- **energy**: loudness and its contour; **creak**: low, irregular pitch; **pace**: words a second and pauses; **words**:
  errors, repeats, tags spoken.

A take is rejected when its breath measures sit clearly above the untagged spread (on average more than one spread, or
two core measures well beyond it, or the voice dropping out). These checks were validated against the owner's ear on
takes they'd already judged, before they were trusted. The owner still picks by ear.

### The A/B before a full re-voice

Tag sparingly, then A/B a handful of key lines for the owner (the current take, the tagged take, both level-matched,
side by side) before re-voicing everything. Because every beat is keyed to the voice's words, a re-voice re-times the
film automatically; the renders and the mix still rebuild.

### Settings and context

Tags work with the voice's stored settings (stability about 0.5). Neighbouring lines go in as plain words, never tagged
(directing.md).

---

## Reference: Designing a voice

When no library voice fits (a brand character, a narrator with a very particular presence), design one from a brief
with Voice Design. The design model is always named explicitly in the request (Slate does this).

### The voice brief

Write it before any preview:
1. **Who they are**: in a few sentences, as a person.
2. **Values**, each with a source (the brand's own words, the product's copy).
3. **How they speak**: warmth, pace, breath at full stops and turns, pitch register, delivery per sentence type
   (statements, questions, the call to action), the opening line, the microphone and the room.
4. **What they never sound like.**
5. **A philosophy-to-sound table**: each value, and how it sounds.
6. **The model**, the prompts, the preview text.
7. **The measured comparison** of the candidates, the production-model check, a recommendation, and the credits spent.

If you can run sub-agents, one can turn the brand's philosophy into the brief while you prepare the tools; otherwise
write it yourself first. Either way, every value cites its source.

A voice brief that quotes company code or internal material is company material: it stays with the company's files and
never travels into a personal or public package.

### Prompts

Voice Design reads prompts in a set order: native language, gender and age range, quality, a two-to-five-word persona,
two or three emotion adjectives, then timbre, pacing and delivery.
- Say "thick" rather than "strong" for an accent; don't use "accent" to mean intonation.
- Avoid "reverb" and "echo": they design the room into the voice.
- Longer preview text gives more stable previews.
- Higher guidance adheres to the prompt more closely but can cost quality.

### Previews and the production-model check

```
slate voice design --description "<the prompt>" --text "<the preview text>"
```

- Previews are measured and ranked on proxies: a pace of about 150 to 170 words a minute, sentence pauses of about 0.35
  to 0.7 s, a pitch range of about 9.5 to 13 semitones, statement endings that fall (at least a semitone, never rising
  much), a clean floor, and every word heard (brand words included).
- **Keep a candidate, then check it on the production model** (`--save`, then `--check`). Designed voices can perform
  differently there: higher in pitch and faster than their previews. Render the candidates on the film's own model
  before choosing.
- The owner picks by ear.

### Designed voices and direction

Designed voices can be less performative on the newest model than on older ones, and tags land more readily when the
delivery is already in the voice. Keep a designed voice's tags inside its designed character; never ask it for a
performance it wasn't designed for (laughing, big emotion). See v4-tags.md.

### Cleanup

A designed voice can carry a baked-in artifact (a faint buzz high in the spectrum, present even in lossless output),
because it's in the voice, not the codec. Diagnose it, then offer cleanup variants (cleanup.md).

---

## Reference: Voice policy: who may be voiced, and how

These rules hold in every mode and for every brand. They're enforced in code before any request is sent (a refused
voice exits 1 with the reason) and checked again by the voice policy gate.

### Whose voice

| Voice | Allowed? |
|---|---|
| A library voice (from the vendor's voice library) | Yes: the default. |
| A designed voice (made with Voice Design from a brief) | Yes. |
| The owner's own voice, as a **professional** clone the owner verified with the vendor themselves | Yes, in every mode. |
| The owner's own voice as an unverified or instant clone | No. |
| Anyone else's voice as a clone (a teammate, a client, a customer) | Never. |
| Anyone else's voice as a real recording, with their permission | Yes, as a recording: never synthesized from. |
| A public figure's voice, cloned or recorded | Never. |

- The profile records which it is (a clone names whose voice it is, what kind, and whether its owner verified it); the
  vendor's own voice category is checked live, so a voice the vendor marks as cloned or famous is caught.
- **Slate has no way to make a clone and never verifies one.** Verification is the owner's, done in the vendor's own
  interface. An agent never does that step and never enters the owner's credentials.
- **Autonomous agents** may narrate with the owner's own verified clone, and no other clone. Their films are still held
  for the owner before anything is published.

### Character voices

- A brand's character voice (a designed voice with a persona) is the brand's. Never ship its audio as a demo outside the
  brand's films.
- A voice brief that quotes company code or internal material stays with the company's material; it never travels into
  a personal or public package.
- Designed voice ids belong to the vendor account that made them and don't transfer to another account.

### AI labels

- None unless the law requires one. Slate records which voices in each film are synthetic, in the manifest (internal
  only), so it's clear when a law does apply.
- Platforms (TikTok, YouTube, Meta) have their own rules that can require labels on realistic AI voices even where the
  law doesn't. Mention it once when it's relevant; whether to follow them is the owner's call per platform.

### Commercial use

Only paid plans' output is licensed for commercial use: free-plan output can't be used commercially at all, and output
from beta services can't be used commercially on any plan. Lossless voice (PCM) needs a higher plan; Slate uses the
best format the account allows and records any fallback.

### Keys

The ElevenLabs key is set by a person in their own Terminal (`slate connect elevenlabs`), never in chat. Autonomous
films use a separate key with its own credit quota and only the scopes they need, so they can never spend the owner's
main balance.
