---
name: "slate-voice"
description: "Cast, design, direct and record the voice of a Slate film, then clean, pace, polish, align and caption it. Covers casting shootouts and Voice Design with measured ranking, directing eleven_v4 with audio tags (never whisper, soft, quiet or gentle tags) and the tag-optimization loop, voicing every line with its neighbours as context, cleanup, pacing, the studio polish (de-esser, EQ, compression, a small room, verified by measurement), measured inflection and A/B spectrogram sheets, word timings, captions, the voice checks, and the cloning policy (designed or library voices by default, the owner's own verified professional clone, never anyone else's). Use when a Slate film needs a narrator chosen or designed, lines voiced or re-voiced, tags tested, a take cleaned, polished or re-timed, a read judged by measurement, captions made, or a question about which voices may be used."
---

> Knowledge-only edition of Slate's `slate-voice` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-voice

The voice carries a film. Slate voices every line on ElevenLabs' best model, one take per line with the neighbouring
lines as context so the reads flow as one narration, then cleans, paces and times them, and checks every take before
anyone hears it. The owner picks voices, takes and direction by ear: measurements shortlist and catch faults, they
never decide.

This is stage 4 of the production (voice), and it feeds stage 5 (timing). Every paid call goes through the ledger and
replays offline in tests (`SLATE_FAKE_VENDORS=1`); `--live` spends.

## 1. The profile and the cloning policy

The brand's pack holds its voice profile (provider, voice id, model, settings, lexicon of brand words); a film pins
what it uses at first use, so a re-voice in week three matches week one.

- **Designed or library voices by default.**
- **The owner's own voice** may be an ElevenLabs professional clone, which the owner verified with ElevenLabs
  themselves. An agent never does that verification.
- **Anyone else's voice** only as a real recording, never a clone, and never a public figure's.
- Autonomous agents may narrate with the owner's own clone; their films are still held for the owner.

The policy is enforced before any request is sent: a refused voice exits 1 with the reason. See
[voice policy](#reference-voice-policy-who-may-be-voiced-and-how).

## 2. Cast or design the voice

- **Cast**: `slate voice cast --voices <id,id,…> --shots <S01,S02>` has several voices read the same lines, measures
  them (pace, pauses, pitch range, noise floor, every word heard, brand words said in full), ranks them, and makes a
  level-matched, labelled listening reel. See [casting](#reference-casting-choosing-a-voice-by-ear).
- **Design** a new voice from a brief: `slate voice design --description "<prompt>" --text "<preview text>"` makes
  Voice Design previews (always on the design model), measured and ranked; keep one with `--save`; then check the kept
  voice on the production model with `--check`, because designed voices can come out higher and faster there. See
  [voice design](#reference-designing-a-voice).
- The **shortlist** goes to the pre-production sitting. The owner picks by ear; the pick is recorded with its model,
  settings and seed.

## 3. Direct it

Direction on eleven_v4 is **audio tags**: short instructions in square brackets where the delivery should change,
such as `[warmly, with a smile]` or `[confident]` before a line, or `[short pause]` for a beat.

- **Never use a tag that lowers vocal effort or adds breath**: whisper, soft, quiet, gentle, hushed, murmuring, breath,
  intimate, calm or a low voice, in any form. They make a read sound whispery and a little scary. Slate refuses them
  before any request is sent, for every brand.
- Emotion comes through a full, clear voice: warm, with a smile, bright, confident, reassuring, encouraging, sincere,
  matter-of-fact, hopeful.
- A tagged line strips back to the script exactly: tags never change a word. Tag sparingly (about half the lines or
  fewer), one emotion per phrase; a tag at the head of a line carries across it.
- If a line doesn't land, swap the tag rather than rewriting the words.
- Every tagged take is measured against the voice's own untagged takes of the same words, and one that measures
  breathier, softer, creaky, repeated or too long is rejected, however good its tag.

The tagged script lives in `voice/direction.json`; `slate voice --help` lists the direction tools (setting, checking,
stripping and A/B-testing tags). The full guide: [v4 tags](#reference-directing-elevenv4-with-audio-tags); settings and context:
[directing](#reference-directing-the-read-settings-context-and-timing).

**When a line's direction matters, run the tag loop**: write the candidates (several tagged versions, several seeds
each, plus extra untagged seeds of the same line), check the estimate, then voice and measure the round. Every take is
a paid call in live mode.

```
slate voice tags optimize --estimate   # the round's cost; nothing voiced
slate voice tags optimize              # voice and measure the round
slate voice tags pick                  # gate and rank each line's takes
slate voice tags abc S01               # hear the best passing takes, level-matched
slate voice tags adopt S01 N1s101      # the owner's pick goes in as that exact file
```

Each take is measured against the voice's untagged reads of the same words on three spans (the tag's words, the words
where the feeling should show, the whole line), gated (full voice, words, creak, fits, no question rise, no mid-word
stop) and checked for its feeling (a smile, reassurance, a calmer read). The best passing takes go to the owner as a
level-matched ABC reel, and the pick goes into the film as that exact file, never re-voiced. See
[the tag loop](#reference-the-tag-loop-voicing-measuring-and-picking-audio-tags).

## 4. Voice every line

```
slate voice tts --estimate      # what it will cost, nothing spent
slate voice tts                 # one take per line, with the neighbouring lines as context
```

- Each line is voiced with its previous and next lines as plain-text context (tags stripped), so the narration flows.
- The model, voice, settings, seeds and request ids are pinned at first use; `--repin` needs the owner's name and a
  reason.
- Existing takes are kept; approved takes are locked by hash and never regenerated without `--force` and a recorded
  spend approval.
- Long batches can run as a queued job: `--detach` returns a job id.

Re-voicing, leaked tails and reusing approved takes: [takes and re-voicing](#reference-takes-pins-and-re-voicing).

## 5. Clean and pace

- `slate voice clean --diagnose` measures each take's noise floor; `slate voice clean` applies the approved chain (a
  denoiser that tracks the floor, with a gentle gate). `--method isolator` uses Voice Isolator, and `--remix` makes
  Voice Remix previews that keep the voice and change only the recording. Offer a few labelled cleanup variants and let
  the owner pick by ear. See [cleanup](#reference-cleaning-a-voice).
- `slate voice pace` shortens long pauses and quickens the read gently with Rubber Band (formants kept), because
  eleven_v4's own speed setting barely moves it. See [pacing](#reference-pacing-a-read).

## 6. Polish

A generated voice can sound generated: harsh S sounds, a glassy edge, no room around it. The **polish** stage runs a
studio vocal chain on every take, locally: a high-pass, a low-mid cleanup, moderate compression on the take at a working
loudness, a dynamic cut on the 2-5 kHz edge and a de-esser (each only while a consonant dominates its band), warmth
shelves, a small synthetic room, and the take's own loudness back at the end. Every stage keeps the length sample for
sample, so nothing in the cut moves.

- **Try first.** Its trial mode renders the voice's named strengths (A, the subtler side of a marked change; B, the
  warmer side; or any number from 0 to 1) for every line, with a level-matched reel and A/B sheets, pinning nothing.
- **The owner picks by ear**, then the polish runs at that strength and the film pins it, chain and all, so a line
  re-voiced later gets the same polish. Moving the pin needs the owner's name and a reason.
- **Perfect, don't replace.** The polished file sits beside the take; the raw, clean and paced files never change, and
  voice measurements keep reading the unpolished stages.
- A voice's tuning lives in its profile (`polish`), measured on its own takes; the neutral chain is the default.

```
slate voice polish --try A,B --sheet   # every line at each strength, a level-matched reel, sheets; pins nothing
slate voice polish --strength B        # the owner's pick, pinned for the film; the cue sheets and the mix play it
```

Align again afterwards, so Whisper hears what the audience hears. See [the polish](#reference-the-studio-polish).

## 7. Measure a read

The **analysis** stage measures any take (a WAV, or a shot) and compares takes against a reference: pitch level, range
and contour, breath and effort (voiced fraction, CPPS, HNR, H1-H2, tilt), brightness, sibilance and edge, loudness,
creak, pacing, the last word's movement, a clean ending, and the Whisper checks. With a sheet it draws every take's
spectrogram, words, pitch and level on one time and colour scale beside its numbers. Use it before the owner hears a
tagged take, to choose a polish strength, and to check a re-voice against the approved take. Emotion comes through a
full voice, checked by measurement; the owner still picks by ear. See [measuring a read](#reference-measuring-a-read-inflection-breath-and-spectrograms).

```
slate voice analyze S03 --stage polished --ab S03 --sheet   # one take's polish, raw against polished
slate voice analyze S01 S02 S03 --sheet --spectrum          # every take, plus the long-term spectrum against speech
```

## 8. Align, caption, time

```
slate voice align                   # word timings (Whisper by default), recorded with the model and version
slate voice captions                # SRT, WebVTT and timing/captions.json, timed to the words
slate script build --from-takes     # every voiced shot re-timed from its take
slate timing                        # the film's clock
```

Word starts are snapped to each take's energy onsets. Forced alignment on ElevenLabs is for evaluation until it's
proven against Whisper. Captions are at most 2 lines of 42 characters, 17 characters a second, at least 1 s each,
never overlapping, and word for word the script. See [alignment](#reference-word-timings) and
[captions](#reference-captions).

## 9. The voice checks

Before the owner hears a take, it passes the voice checks (listed in `slate voice --help`, recorded in
`qa/gates.json`):
- **policy**: the voice may be used;
- **direction**: no banned tag, and every tagged line strips back to the script exactly;
- **takes**: every line has a take;
- **words**: Whisper hears every word, and every brand word in full, with no repeats and no tag read aloud;
- **tails**: no sound from the next line leaking into the end of a take;
- **fit**: each read fits its shot, starting a short lead in and ending before the cut;
- **inflection**: nothing whisper-like, no tagged read breathier than the voice's untagged reads of the same words, no
  statement ending that rises like a question, no read that stops mid-word; a tagged line nobody has measured waits for
  the owner's ear;
- **polish**: every polished take verified by measurement (same length, loudness back within 0.5 LU, S and edge down
  within the chain's reach, not over-processed, made with the film's pinned polish); a film that doesn't polish passes
  and says so.

Replayed takes (in tests) are UNCHECKED, never passed.

## 10. Approval and locks

Takes are approved by ear, each against its exact bytes, and approved takes are locked by hash. The voice shortlist
belongs to the pre-production sitting; individual takes come in packets. Re-voicing an approved take needs `--force`
and a recorded spend approval, and re-voices only the lines that changed, with their neighbours as context.

## References

- [voice-policy](#reference-voice-policy-who-may-be-voiced-and-how): who may be voiced, clones, labels, character voices.
- [casting](#reference-casting-choosing-a-voice-by-ear): shootouts, reels, choosing by ear, long reads, dialogue.
- [voice-design](#reference-designing-a-voice): the voice brief, prompts, previews, the production-model check.
- [directing](#reference-directing-the-read-settings-context-and-timing): settings, context, timing from the text, consistency.
- [v4-tags](#reference-directing-elevenv4-with-audio-tags): the tag families, the rules, the banned tags, measuring every tagged take.
- [tag-loop](#reference-the-tag-loop-voicing-measuring-and-picking-audio-tags): candidates and seeds, measuring rounds, the gates and feelings, ABC, adopting.
- [cleanup](#reference-cleaning-a-voice): the floor, the chain, Voice Isolator, Voice Remix.
- [pacing](#reference-pacing-a-read): shortening pauses, Rubber Band, what the speed setting doesn't do.
- [polish](#reference-the-studio-polish): the studio chain, strengths, trials, pins, the report and its gate, tuning a voice.
- [measuring-reads](#reference-measuring-a-read-inflection-breath-and-spectrograms): every measure, A/B sheets, when to use them, the inflection gate.
- [alignment](#reference-word-timings): Whisper, onset snapping, forced alignment, word misses.
- [captions](#reference-captions): the caption rules, sidecars and burned-in captions.
- [takes-and-revoicing](#reference-takes-pins-and-re-voicing): pins, locks, leaked tails, re-voicing with neighbours.

---

## Reference: Word timings

Every beat in a Slate film is keyed to the voice's words, so word timings are the film's clock. They come from the takes
themselves, after cleaning and pacing.

### Whisper by default

```
slate voice align                     # every take, with Whisper (local, free)
slate timing words                    # re-time the words and rebuild the timing files
```

- Whisper's turbo model with word timestamps, run locally; the model and its version are recorded in the evidence of
  every result that uses them.
- **Word starts are snapped to the take's energy onset** (within about 80 ms, on a clear rise), because Whisper's word
  starts can be off by tens of milliseconds.
- Results are cached per take by its hash: a take that changes is re-aligned; one that doesn't isn't.

### Forced alignment is for evaluation

ElevenLabs' Forced Alignment (`--engine elevenlabs`) is paid per minute of audio. It stays an evaluation until it's been
compared with Whisper on approved takes (`--compare` writes the per-word differences), and the owner decides whether to
switch. Whether the newest TTS model returns its own timestamps isn't documented; verify before relying on it.

### Whisper's quirks

- It writes numbers as digits and symbols as symbols: word lookups match through the language's spoken forms both ways,
  so "twenty twenty-six" finds "2026".
- Over digital silence at the very end of a track it can hallucinate a repeat of the last phrase: ignore silent tails.
- It can mishear a brand word: the lexicon tells the checks which words must be heard in full.
- For reference analysis (someone else's film), take the voice's text from Whisper with a second model agreeing on
  disputed lines, never from a generation vendor's scene analysis (which once paraphrased the on-screen text instead of
  the voice).

### Word misses

- A word lookup (`word()` in the kit, `word_time` in Python) never throws: when a word can't be found it returns an
  estimate from the line and records a miss.
- `slate timing misses` lists them; the list must be empty before any act is handed in.
- A miss usually means the script and the take disagree (a changed word, a number spoken differently): fix the script or
  the take, never the timing file.

### After alignment

```
slate script build --from-takes
slate timing
```

The storyboard is re-timed from the takes, and the timing files are rebuilt on the film's clock. Once an act render is
registered, the timing locks.

---

## Reference: Captions

Captions come from the script's words and the voice's word timings, so they're word for word what's said and exactly
in sync. They're built once and used twice: as sidecar files for platforms, and burned in by the renderer where the
format asks for it.

### Building them

```
slate voice captions
```

writes `timing/captions.json` (the cues, for the renderer and the checks) and `voice/captions/<film>.srt` and `.vtt`.

### The rules

- At most **2 lines of 42 characters**.
- At most **17 characters a second**; a cue that would read faster is held longer.
- At least **1 second** on screen.
- **Never overlapping**, and in order.
- **Word for word the script** (the booth script, not what Whisper heard), including how numbers are written.
- Breaks at natural phrase boundaries; never split a name or a number across lines.

`slate qa captions` checks every rule against the delivered captions.

### Burned-in captions

Social reels (9:16) usually carry burned-in captions: the kit draws them from `timing/captions.json` in the brand's own
font, inside the platforms' safe zones (slate-motion, safe-areas.md), styled by the brand pack. They're part of the
picture, so they're checked by OCR with the rest of the frame.

### Sidecars

Deliver SRT and WebVTT alongside the masters for every platform that takes them (slate-finish). A derived film in
another language gets its own captions from its own script and takes.

### Language

v1 speaks English, but the caption code carries no English literals: line-break and punctuation rules live in language
tables, so another language arrives as data.

---

## Reference: Casting: choosing a voice by ear

A casting shootout has several voices read the same lines, measures every take, and gives the owner a listening reel.
The owner chooses by ear; the measurements only filter out takes that fail and put the rest in a sensible order.

### Running a shootout

```
slate voice cast --voices <voice-id>,<voice-id>,<voice-id> --shots S01,S05
slate voice cast --text "<a line that matters>" --name opening-line
```

- Pick lines that matter: the opening line, a line with the brand's name, a line with a number, the emotional peak.
- Every candidate reads the same lines on the production model with the same settings.
- Each take is measured: pace (words a second), pauses at full stops and turns, pitch range, falling endings on
  statements, the noise floor, and whether Whisper hears every word, including each brand word said in full.
- The reel is level-matched (every take at the same loudness), labelled, and plays the takes one after another, so the
  owner compares voices, not volumes.
- A clone or a famous voice among the candidates is refused before anything is spent.

### Choosing

- **The owner picks by ear.** Record the pick with its model, settings and seed, and pin it.
- **Try the pick inside the approved sound** before committing: the same proof mix with the new voice, checking
  loudness and a Whisper read.
- **Brand words decide close calls.** One engine clipped the brand's name on the first film; the best current model said
  it in full. Put every brand word in the lexicon so the checks listen for it.
- **Time shots from the real reads.** A deliberate narrator can read 1.5 to 3.2 words a second; the shots are re-timed
  from the takes after voicing.

### Which engine and model

- Narration runs on ElevenLabs directly, on its best model (recorded in `registry.json`, pinned per film). A generation
  vendor's own TTS route gave lower bitrate, allowed only a few jobs at once, and clipped a brand word.
- For long reads (60 to 120 seconds of continuous narration), A/B the best model against the vendor's most stable
  long-form model before choosing.
- For pieces with several voices, the vendor's dialogue endpoint takes requests up to about 2,000 characters, any number
  of speakers, and previous and next context.
- Check the best models against the live API at the start of a project; the catalogue changes.

### The shortlist at the sitting

Bring two or three voices to the pre-production sitting, each with its reel entry and a one-line note (what it does
well, what to listen for). Measurements go in the notes, not in the pitch: the owner is choosing a voice, not a number.

---

## Reference: Cleaning a voice

Most takes need little or nothing. When a voice carries noise, the cleanup must remove the noise and keep the voice:
the owner chooses between variants by ear.

### Diagnose first

```
slate voice clean --diagnose
```

- Measures each take's noise floor and where it lives in the spectrum.
- A designed voice can carry a baked-in artifact (a faint buzz between about 5 and 12 kHz) that's present even in
  lossless output: it's in the voice, not the codec, so a better format won't remove it.
- Request the best format the plan allows (lossless PCM needs a higher plan); Slate records any fallback.

### The options

| Method | What it does | When |
|---|---|---|
| The default chain (`slate voice clean`) | a denoiser that tracks the take's own floor, then a gentle gate | most takes with a steady floor |
| Voice Isolator (`--method isolator`) | the vendor's isolator | background noise that isn't in the voice; it lowered a baked-in buzz only about 2 dB |
| Voice Remix (`--remix --text "<line>"`) | re-generates the recording with the same voice | an artifact in the voice itself; prompt it to keep this exact voice and change only the recording, at a modest prompt strength (about 0.25 to 0.5), across a few seeds, lossless output |
| A custom chain (`--chain`) | your own filter chain | when the owner picked one |

### Letting the owner choose

Offer three to five labelled variants of the same line (level-matched, side by side) and let the owner pick by ear. On
the first films, the owner's pick was a floor-tracking denoiser with a gentle expander, chosen from five. Record the
chosen chain and use it for every take of that voice.

### Rules

- Clean every take of a voice the same way, so lines match.
- Never clean an approved take in a way that changes it without a new approval: the approval is bound to its bytes.
- Clean before pacing; pacing works on the clean take.
- Whisper still has to hear every word after cleaning.

---

## Reference: Directing the read: settings, context and timing

### Settings

eleven_v4 has two settings: **stability** and **similarity**. Style and speed aren't available on it, and neither is
SSML.
- **Stability** trades consistency for expressiveness. Too low gives odd, random, rushed reads; too high goes monotone.
  Start at 0.5 and change it only when a probe earns the change: on the first films a looser 0.35 changed the waveform
  and nothing else (the tags didn't land better).
- **Similarity** raises adherence to the reference voice at some cost to naturalness, and can reproduce flaws in the
  source recording. The voice's stored value (often about 0.75) is the start.

### Context

- Each line is voiced with its **previous and next lines** as context, so the narration flows as one read. The context
  carries the neighbours' **plain words**, with tags stripped: a tag belongs to the line it directs. (Tagged context was
  tested: harmless, and no better.)
- Request ids of neighbouring takes can stitch generations more tightly than text, within a couple of hours; the voice
  stage handles it.
- Context can leak: the next line's first sound sometimes appears at the end of a take (takes-and-revoicing.md).

### Timing comes from the text

On eleven_v4, identical text and context gave sample-identical lengths across seeds and stability values. So:
- **change pacing through the text**: punctuation, tags, line structure;
- **regenerating** changes texture and inflection, not timing;
- **air after heavy lines comes from the edit** (a longer hold in the shot), not from pause tags; use pause tags
  sparingly.

### Consistency across a film

- One small tag vocabulary, the same settings and the same context rule on every line.
- The model can shift over time as the vendor retrains it: record the seed and request id of every take, so a re-test
  is comparable, and pin the model per film.
- Tagged takes can come out 1 to 2 dB quieter than untagged ones; the mix levels each take by its voiced loudness, and
  A/B clips are level-matched.

### Punctuation is direction

- A full stop gives a beat; an ellipsis adds a trailing pause and weight; a line break gives a longer beat.
- A dash cuts the speaker off; an exclamation mark adds intensity; capitals add emphasis.
- A question lifts: don't end a statement with one.

### When a line doesn't land

1. Listen to what's wrong: pace, pitch, a word, an emotion.
2. Swap the tag (or move it to the exact clause) and regenerate. Don't rewrite the words.
3. If the words must change, change them in the script on purpose, rebuild, and re-voice with neighbours.

---

## Reference: Measuring a read: inflection, breath and spectrograms

Takes, tags and polish strengths are judged by measurement as well as by ear. The analysis stage measures any take (a
WAV, or a shot in the film) and compares takes against a reference, with an A/B spectrogram sheet to look at while you
listen. `slate voice --help` lists it; its own `--help` gives every option.

It came from the first film's tag work. The owner heard whispery tags as "a little bit scary" and suggested "analyzing
the waveforms and frequencies, like a spectrogram" to gauge the emotion. The measures below are the ones that film used,
with the same meanings.

### What's measured

| Family | Measure | What it catches |
|---|---|---|
| Pitch | F0 median, mean, range (5th to 95th percentile, semitones), movement (SD), and the contour | monotone or sing-song; a smile lifts pitch |
| Breath and effort | voiced fraction, CPPS (cepstral peak prominence), HNR (harmonics-to-noise), H1-H2, spectral tilt, level | a whisper has no pitch; breath fills the harmonics; a soft voice tilts steeply |
| Brightness and smile | spectral centroid, F1 and F2 | a smile shortens the vocal tract and lifts F2 (only between takes of the same words) |
| Sibilance and edge | the 5-9 kHz and 2-5 kHz bands against the whole sound, and their loudest 5 ms moments | harsh S sounds, a glassy edge |
| Energy | BS.1770 loudness and true peak, the level contour's spread, the last word against the rest | a fading or flat delivery |
| Creak | voiced frames far under the median pitch, irregular pitch, and the words they fall on | vocal fry on a key phrase |
| Pacing | words a second over the speech span, articulation rate, pauses, the quiet at each sentence end | rushed or dragging |
| Endings | the last word's pitch across it, its contour (start, peak, end, fall, range), every question word's rise | a statement that rises like a question |
| A clean end | how far the last 20 ms sit under the speech | a take that stops mid-word (under 35 dB) |
| The Whisper checks | every word heard (WER), no repeats, no tag read aloud, every lexicon word in full, no voice after the last word | misreads, leaked tails |
| The tag's scope | all of the above from the first word an emotion tag governs to the end | a tag on the last word that whispers just that word |

Without a take's heard words the word-timed measures are left out, never guessed: in a film the alignment supplies
them (when it times that very audio), and for loose files you give a Whisper JSON or ask for a local Whisper run.

### Comparing against a reference

Name a reference and every other take is compared with it: each measure's change (pitch in semitones), the sibilance
and edge changes, and a breath verdict. With one reference take there's no spread to measure against, so the verdict
uses fixed floors; it flags a big change, and it's strongest when the voice drops out (a whisper). For the full rule,
compare against several untagged reads of the same words (the tag loop does).

### The sheet

One PNG, every take on one time scale and one colour scale (each brought to -20 LUFS first), the reference first:
- the spectrogram (0-8 kHz for takes, 0-12 kHz for polish comparisons), with 2, 5 and 9 kHz marked;
- the words under it;
- the pitch contour, with the reference's median pitch dashed across it;
- the level contour;
- a measurement column, with the breath verdict against the reference.

Look for: voicing that thins out on a tagged phrase (a whisper), harmonics fading into noise (breath), a pitch line
that hooks up at the end of a statement (a question rise), S bursts that stand out of the 5-9 kHz band (harshness),
a level line that collapses before the last word (fading).

### The long-term spectrum

Ask for the spectrum too (the analyze stage's spectrum option) and every take gets its third-octave long-term
spectrum over speech at -20 LUFS, set against natural speech's shape (ANSI S3.5's standard speech spectrum) over
500 Hz-1 kHz, in a chart beside the sheet (`spectrum.png`): the films' "where the harshness lives" picture. A curve
well over the grey line at 2-5 kHz is edge (a glassy, pushed sound); at 5-9 kHz it's sibilance. It also lists the
band levels (lows, body, the 1-5 kHz clarity band, edge, sibilance, air), the edge and sibilance bands' median and
loudest 5 ms moments, and the words those loudest moments fall in, which tell you exactly where to listen. The
polish's trial mode draws the same chart for the unpolished lines against each strength, pooled over every line.

### When to use it

- **Before the owner hears a tagged take**: against the voice's untagged reads of the same words. A tagged read that
  measures breathier is out, however good its tag looks.
- **Choosing a polish strength**: the unpolished take against each strength, on a 0-12 kHz sheet (the polish stage's
  trial mode draws these for every line). Read the sibilance, edge and spectrum there, not the breath: the room and
  the EQ move CPPS and H1-H2 without any change of breath, so those sheets leave the breath verdict out.
- **A re-voice against the approved take**: did the notes change the read, or the voice?
- **Tuning a voice's polish**: where its sibilance and edge actually sit.

### The gate it backs

The inflection gate holds every line to the no-whisper rule by measurement:
- **fails**: a whisper-like read (the voice dropping out, against the film's other lines); a tagged read breathier than
  the voice's own untagged reads of the same words (when a tag round measured it); a statement ending that rises like a
  question (past the voice's own endings plus 3 semitones); a read that stops mid-word;
- **asks for an ear**: a tagged line nobody has measured against untagged reads of the same words, until the owner
  approves the take by ear;
- **notes, not verdicts**: breathiness or creak against the film's other lines (other words differ, so these only
  point where to listen).

The film's breath and pitch measures read each take before its polish, so the polish never becomes its own baseline.

### What it can't do

These are proxies. They can tell a read is breathy, whispered, creaky, rising, rushed, harsh or misheard. They can't
hear warmth, sincerity or a smile the way a person does. The owner still picks by ear.

---

## Reference: Pacing a read

eleven_v4's speed setting barely moves a read (take-to-take variation is bigger than the setting's effect), and
regenerating changes texture, not timing. So pace is adjusted after the take, gently, keeping the voice natural.

### What `slate voice pace` does

1. **Shortens long pauses**: pauses longer than about a quarter of a second are cut to about 0.8 of their length, from
   the middle, so the breath and the onset either side stay intact.
2. **Quickens the read slightly** with Rubber Band's highest-quality engine (about 6% faster on the first films), with
   formants kept, so the voice's timbre doesn't shift.

Options: `--no-tempo` (pauses only), `--tempo <factor>`, `--min-pause <seconds>`, `--pause-keep <fraction>`.
`slate voice pace --check-tools` reports the Rubber Band build: an Intel build running under Rosetta is flagged, and the
installer can replace it with a native one.

### Rules

- Keep it natural: a narrator who sounds hurried is worse than a shot that's a little long. Re-time the shot instead
  (the storyboard re-derives shot lengths from the paced takes).
- Whisper must still hear every word after pacing.
- Pace every take of a film the same way, so the narration matches itself.
- Pacing never makes a read fit a shot it doesn't fit. If a read is far too long, the line needs fewer words (slate-story)
  or the shot needs more time.
- Pacing is a derived file: the raw and clean takes are kept, so it can be redone.

### Where pace is set

- **In the script**: at most 2.6 words a second per shot, planned from the words (slate-story).
- **In the text**: punctuation and structure (directing.md).
- **After the take**: this stage.
- **In the edit**: holds and air around heavy lines, set by the shot lengths.

---

## Reference: The studio polish

A generated voice can sound generated: a little too harsh on its S, T and SH sounds, a bright, glassy edge, no room
around it. The polish is a studio vocal chain that fixes that without changing who the voice is. It runs on every take,
locally (numpy and scipy, nothing paid), as the last step before the take goes into the film.

`slate voice --help` lists the polish stage with the other voice stages; its own `--help` gives every option.

### What the owner asked for, and why it's built this way

The first film's owner heard a narrator as "a little too harsh… you can tell it was generated" and asked for a
de-esser, a lot of EQ and other local vocal effects. The target was a podcast host: natural and conversational, a
little room, warm and present. The strength had to sit between "barely noticeable" and "clearly warmer": a marked
change that is still the same voice.

Measuring first changed the plan. That voice's harshness wasn't in 2-5 kHz at all (it sat 3 to 7 dB under natural
speech there); it was at the very top, on its vowels and on its S sounds. A static cut at 2-5 kHz would only have dulled
it. So: **measure where a voice's harshness lives before tuning its chain** (the analysis stage's sibilance and edge
bands, and the long-term spectrum the polish report gives).

### The chain

| Stage | What it does | Why |
|---|---|---|
| High-pass | 12 dB an octave, about 80 Hz | rumble and low thump out, nothing of the voice |
| Low-mid cleanup | a gentle bell cut where the voice measures boxy or honky | one bump, not a curve |
| Compressor | moderate (2 to 2.5:1), on the take brought to -20 LUFS first | the threshold means the same thing on every line |
| The edge | a dynamic cut on 2-5 kHz, only while a consonant dominates the band | T, SH and CH come down; vowels are left alone |
| De-esser | the same on the sibilance band (5-9 kHz by default), faster | S and SH come down, only while they dominate |
| Warmth | presence, a low shelf for body, a high shelf easing a glassy top | the static colour |
| Room | a small synthetic room, 18 to 22 dB under the dry voice | space without mud or hiss |
| Loudness | back to the take's own integrated loudness (BS.1770) | the mix balance holds |

Every stage keeps the take's length sample for sample, so no word, caption or cue moves. A take whose true peak would
pass -1 dBTP sits a hair lower instead (by a few tenths of a dB, recorded in the report).

### Strengths

A voice's tuning names its strengths. The neutral default has two:
- **A**: the subtler side of a marked change;
- **B**: the warmer side.

Each has a place on a scale from 0 (the take untouched) to 1, so a number in between blends its neighbours: 0.8 sits
halfway between A (0.6) and B (1.0). Use a name when the owner picked one by ear; use a number only to find a middle the
owner asked for.

### The flow

1. **Try before you pin.** The polish stage's trial mode renders the strengths you name (A and B, say) for every line
   without pinning or registering anything: a level-matched reel (each line unpolished, then each strength), every
   number in `voice/polish/try/trial.json`, and on request an A/B spectrogram sheet per line plus one long-term
   spectrum chart (every line pooled, unpolished and each strength, against natural speech's shape).
2. **The owner picks by ear.** Measurements say what changed; the ear says whether it's still the voice.
3. **Polish with the pick.** The first real polish pins the strength and the whole resolved chain in film.json
   (`voice_polish`). Every later polish of that film uses the pin, so a line re-voiced in week three gets week one's
   polish. Moving it is a re-pin with who approved it and why, after a new trial.
4. **Align again.** Whisper hears the polished takes (the words gate runs on what the audience hears), then run the
   voice checks.

### What it writes

- `voice/takes/<shot>/<take>.polished.wav` beside the take. The raw, clean and paced files are never changed.
- `voice/takes/<shot>/<take>.polish.json`: the report (below).
- `voice/polish/summary.json`: the film's polish, pooled over every line.
- film.lock.json records the polished take with the stage it was made from and the raw take as inputs, so a new take
  or a new pace makes the polish stale. Cleaning or pacing a take again drops its old polish.
- Approving a take locks its polished file too. Polishing an approved take again needs `--force` and the person's
  approval id.

### The report

Both sides are brought to the same working loudness by the same gain, and measured over speech frames:
- **sibilance**: the de-esser band's level and its loudest 5 ms moments (the 99th percentile), before and after;
- **the edge**: the same for 2-5 kHz;
- **spectral tilt** (50 Hz-1 kHz against 1-5 kHz) and **warmth** (80-500 Hz against 1-5 kHz);
- **low-mid**: the octave around the cleanup frequency;
- **clarity**: 1-5 kHz, where words stay clear in a mix;
- **loudness and true peak**, in and out, and the length;
- the third-octave change and its RMS (the overall spectral change);
- what each stage did: the compressor's gain reduction, how often and how deep the edge cut and the de-esser acted.

Bands a take barely uses (more than 60 dB under its loudest third-octave) are left out, so a narrowband recording
can't produce a fake "change".

### The gate

Every polished take is verified by measurement:
- the length is identical;
- loudness is back within 0.5 LU of the take;
- the true peak stays under -1 dBTP, or the take's own peak if it was higher;
- when the de-esser acted, the S peaks came down; they never came down more than the chain can do;
- the 2-5 kHz peaks didn't rise (presence may lift them a little, never more than 1 dB);
- not over-processed: the overall spectral change at most 6 dB, and at most 2.5 dB taken out of 1-5 kHz;
- made with the film's pinned polish, from the current take.

A film that doesn't use the polish passes the gate and says so. A voice can require it (`polish.required` in its
profile), and then every line must be polished. On the first film the two strengths measured 2.5 and 3.7 dB of overall
change, took out 0.7 and 1.4 dB of 1-5 kHz, and cut the S peaks by about 6 and 9 dB.

### Tuning a voice

A brand's voice profile can carry its own tuning in `polish`: named `points` (each a chain; anything left out comes from
the neutral chain), their `strengths` on the 0-1 scale, a `default_strength`, and `verify` overrides. Tune it on the
voice's own measurements:
- where its sibilance peaks (some voices' S sits at 10-11 kHz, others' at 5-8 kHz): set the de-esser band there;
- whether it has a glassy top (a high shelf) or a presence bump (a small cut at 3 kHz);
- where it's boxy or honky (the low-mid cleanup);
- how heavy its lows are (the low shelf).

Keep the measurement source honest: the voice's breath and tag measurements read the unpolished stages, because a
polished baseline would make the next round's new takes look harsher than the voice's own reads.

### Parity

The chain was ported from the first film's tool, whose EQ and compressor ran in a GPL-licensed plug-in host. Slate
doesn't depend on it: the same formulas in numpy and scipy reproduce that tool's polished takes to within 0.001 dB per
band, on two voices and three strengths.

---

## Reference: The tag loop: voicing, measuring and picking audio tags

When a line's direction matters (a smile on the greeting, reassurance on a hard truth, a lively fall on a one-word
answer), one tagged take isn't enough to know. The tag loop voices several candidates on several seeds, measures each
against the voice's own untagged reads of the same words, gates and ranks them, lets the owner hear the best side by
side, and puts the pick into the film as that exact file.

```
slate voice tags optimize --estimate   # the round's cost from voice/tags/candidates.json; nothing is voiced
slate voice tags optimize              # voice every candidate on every seed plus the untagged reads, then measure
slate voice tags pick                  # gate and rank each line's takes; ranking.md shows every gate
slate voice tags abc S01               # the best passing takes, level-matched in one reel, to hear side by side
slate voice tags adopt S01 N1s101      # the owner's pick (candidate N1, seed 101) goes in as that exact file
```

Each action works on the round in `voice/tags/main/` unless `--round R` names another; `--help` gives the rest.

### What the first films learned

- **The seed matters as much as the tag.** A tag that passed on one seed measured breathier on three others, and a
  winning text lost its lift on a new seed. So candidates get several seeds, and the pick goes in as that exact file.
- **Some tags make a voice breathier even when they sound harmless.** On one voice every "sincere", "kind", "warm" and
  "reassuring" take measured breathier than its untagged reads; a smile made the same voice fuller.
- **One average hides a whispered word.** A tag on the last word changed that word while the line's average barely
  moved, so every take is measured on three spans.
- **The rules tightened as the rounds went on**, each written down before the pick: the strict breath rule, the
  question-rise rule, the mid-word stop.

### The plan: voice/tags/candidates.json

Hand-written, checked against `schemas/voice_tag_candidates.schema.json`:

```json
{"lines": {
  "S01": {"intent": "smile", "emotion_from_word": 0, "baseline_seeds": [301, 401],
          "candidates": [{"key": "N1", "tagged": "[warmly, with a smile] Hi, it's good to meet you.", "seeds": [101, 201]},
                         {"key": "N2", "tagged": "[confident] Hi, it's good to meet you.", "seeds": [102, 202]}]},
  "S07": {"intent": "rhetorical", "rhetorical": true, "baseline_seeds": [303],
          "candidates": [{"key": "M1", "tagged": "[matter-of-fact] Why does it matter? Because it decides.", "seeds": [107]}]}
}}
```

- **intent**: the feeling the pick must measurably show (below), or `none` for the gates only.
- **emotion_from_word**: where the feeling should show (0-based script word); every take of the line is compared on
  the same words.
- **baseline_seeds**: extra untagged reads, so the voice's own spread is known (the film's current take counts too,
  when it's untagged).
- A candidate may set `stability`, `context` (`neighbours`, `no_next` or `none`) and `role`.
- **hold**: planned but waiting for the person's go.

Every candidate must strip back to the script exactly, with no banned tag; the whole plan is refused before anything is
voiced if one doesn't.

### Optimize: voice and measure a round

Each take is voiced the film's way (its pinned voice, model and settings, the neighbouring lines as plain context),
cleaned and paced. **Every take is a paid TTS call in live mode**, through the one ElevenLabs client (estimate, budget,
ledger row); ask for the estimate first. The round is resumable: a take already voiced is never voiced again.

Then every take is transcribed (local Whisper) and measured on its clean file, on three spans (the tag's words, the
emotion words, the whole line), against the untagged reads of the same words. Everything lands in
`voice/tags/<round>/metrics.json`.

### Pick: the gates and the feeling

A take that fails any gate is out:

| Gate | Rule |
|---|---|
| Full voice | two tests, both required, on every span: the statistical rule (breath index over 1 SD, two core measures over 1.5, or the voice dropping out), and no span breathier than the breathiest untagged read of the same words |
| Words | Whisper hears the script word for word, no repeat, no tag read aloud |
| Creak | no more creak than the untagged reads, plus one point |
| Fits | the paced take fits its shot |
| Ending | the last word rises at most 3 semitones past the untagged endings; on a rhetorical line, no question word rises more than 1 semitone past its untagged reads |
| Complete | the take's last 20 ms sit at least 35 dB under its speech |

The feelings, measured on the emotion span against the untagged reads:

| Intent | Present when |
|---|---|
| smile | pitch up 0.8 to 3.5 semitones (past that reads theatrical), and brighter (centroid up 4% or F2 up 2%) |
| smile_end | a smile, and the phrase lifts over the rest at least as much as untagged |
| reassure | steadier (pitch movement at least 0.2 semitones lower) at full level |
| hopeful_end | the last phrase lifts at least 0.5 semitones more than untagged, fully voiced, level held |
| sincere | steadier, or 3% slower, at full level |
| rhetorical | the question words rise at least 1 semitone less than untagged |
| plain | no wider pitch movement than untagged, at full level |
| encourage, warm | a modest lift (warm may brighten instead), at full level |
| alive_fall | the last word falls 1.5 to 4 semitones from its peak, with more range and no less energy or clarity than the reference |
| calmer | narrower range, a lower peak, less rise on the last word, a steadier level and not rushed, against a reference take, without going flat |

Among the takes that pass, the pick is the clearest feeling with the fullest voice. If none pass, the line stays on its
current take: retagging it is a job for the owner's ear, not another round. Replayed stand-ins (tests, demos) are never
picked. `ranking.md` shows every take's gates.

### ABC: listen

For one line: A is the film's current take, then the best passing candidates (one per tag family first), each
level-matched to -20 LUFS, in one reel with short gaps; abc.json with the timings and measurements; an A/B sheet per
candidate; and the last word's pitch for every take on one axis. Near misses can be added, labelled with what they
missed, never presented as passes.

### Adopt: the exact file

The owner's pick goes into the film as that exact file: a new take of the shot (raw, clean and paced copied byte for
byte), selected, with its tagged text as the line's direction and the round's measurements carried with it, so the
inflection gate knows it was measured against untagged reads of the same words. Adopting over an approved take needs
the person's go. Then align, polish (if the film uses it) and check as usual.

---

## Reference: Takes, pins and re-voicing

### One take per line, pinned

- `slate voice tts` voices every line of the script, one take per line, with the neighbouring lines as plain-text
  context. The takes and their records live in `voice/` (which take is selected, its raw, clean and paced files, its
  alignment, and whether it's approved).
- At first use the film pins the model, the voice id, the settings, each line's seed and each request id. A registry
  refresh never changes a pinned film; moving a pin needs the owner's name, a reason and ideally an A/B as evidence.
- Existing takes are kept unless you ask for new ones.

### Approved takes are locked

- An approved take is locked by its content hash. Regenerating it needs `--force` and a recorded spend approval: the
  owner's yes to spend again on something already paid for.
- **Reuse, never regenerate, approved assets.** When the film changes around an approved take, re-time the shot, not
  the take.
- Superseded takes are archived (with a note of what replaced them), never deleted.

### Leaked tails

Context-conditioned speech can leak: the next line's first sound appears at the end of a take (on the first film, a
line ended with the first consonant of the next line's first word, and the owner heard it). So:
- the tails check scans every take's end for sound returning after silence;
- the fix is to **trim** the take after its last word decays (the trim is recorded with the take), never to regenerate an
  approved take for it;
- the dialogue stem is digital silence at the trimmed point.

### Re-voicing

When a line's words change (a correction, a claim removed):
1. Change the script, rebuild it (slate-story).
2. Re-voice **only the changed lines**, with their neighbouring lines as context, at the same delivery (the same voice,
   model, settings, cleanup and pinned polish), so they match the lines around them.
3. Whisper must hear the new lines word for word; the new takes must fit their shots.
4. Re-time, re-render the affected range and splice it (slate-finish), re-mix, re-run the gates.

Because every beat is keyed to words, the picture follows the new timing automatically; nothing is re-timed by hand.

A film that uses the studio polish pinned its strength and chain at first use, so a re-voiced line gets exactly the
same polish, and the polish check fails until it has it ([polish](#reference-the-studio-polish)). A tagged line's pick from a tag round
goes in as that exact file ([the tag loop](#reference-the-tag-loop-voicing-measuring-and-picking-audio-tags)): seeds aren't fully deterministic, so it's never re-voiced in
the hope of getting it back.

### Fitting the shot

Every read fits its shot: it starts a short lead into the shot and ends at least a short tail before the cut. The fit
check measures each paced take against its shot's room. A read that doesn't fit gets a longer shot (the storyboard is
re-timed from the takes), fewer words, or a gentler pace, in that order of preference.

### Brand words

Every take is checked for the brand's words said in full. A clipped brand word is a failed take, whatever else is right
about it.

---

## Reference: Directing eleven_v4 with audio tags

An audio tag is a short natural-language instruction in square brackets, placed where the delivery should change:
`[warmly, with a smile] Hi, it's good to meet you.` The list of tags is open (they're direction, not a fixed menu), and
v4 follows them more reliably than earlier models, though not perfectly. Tags are billed as characters.

### The rule above all: full voice only

**Never use a tag that lowers vocal effort or adds breath.** That means whisper or whispering, talking softly, soft or
softly, quiet or quietly, gentle or gently, hushed, murmuring, under one's breath, breathy, intimate, calm, and a low
voice, in any form or combination. The owner heard them as whispery and a little scary. Even a tag that sounds harmless
("calm and reassuring") measured breathier than the voice's untagged reads. Slate refuses these words inside any tag
before a request is sent, for every brand; a brand can ban more, and nothing can un-ban these.

**Emotion comes through a full, clear voice**: warm, with a smile, bright, confident, reassuring, encouraging, sincere,
matter-of-fact, hopeful.

### The families (safe examples)

| Family | Examples that work |
|---|---|
| Emotion | `[happy]`, `[excited]`, `[thoughtful]`, `[curious]`, `[hopeful]`, `[delighted]`, `[impressed]`, `[reflective]` |
| Delivery and register | `[confident]`, `[warmly]`, `[reassuring]`, `[sincere]`, `[matter-of-fact]`, `[encouraging]`, `[conversational tone]`, `[professional]` |
| Longer narration direction | `[warm, conversational tone]`, `[bright, friendly, smiling]`, `[candid, kind]`, `[voice rising into firm resolve]` |
| Pacing and pauses | `[pause]`, `[short pause]`, `[long pause]` |
| Reactions (non-verbal) | `[laughs]`, `[chuckles]`, `[sighs]`, `[clears throat]`: only when the voice's character suits them |

Two families exist that a film narrator almost never wants: **sound effects** (the model can perform a tag as a sound
effect; a film's sound is designed separately) and **accents or singing**.

### The rules

**How many**
- Don't tag every line: v4 infers emotion from well-written text. Tag about half the lines at most.
- One emotion per phrase. A tag at the head of a line carries across the whole line.

**Where**
- Immediately before the segment it modifies (a reaction can follow it). If the feeling changes mid-sentence, put the tag
  before the exact clause.
- A softening tag in the middle of a line is where creak appeared on the first films: prefer the head of the line, and
  give any mid-line tag a creak check.

**Wording**
- A tag describes something you can **hear**, never a face, a gesture or music (not `[grinning]`, `[standing]`, `[music]`).
- Be explicit about voice quality, and word tags so they can't be read as a sound cue: describe the voice, never an
  object or an event.
- Match tags to the voice's character: a serious professional voice doesn't suit playful tags, and a designed voice is
  never asked for a performance it wasn't designed for (laughing, big emotion).

**The words**
- Tags never change a word. A tagged line must strip back to the script exactly (Slate refuses one that doesn't).
- If a line doesn't land, swap the tag rather than rewriting the text, then regenerate.

**Pauses**
- v4 has no SSML. Pause with punctuation and structure (an ellipsis adds pause and weight, a line break a longer beat) or
  a pause tag, sparingly. Air after heavy lines comes from the edit.

### What tags do, measured

On the first films a smile tag lifted the pitch about 2.4 semitones and brightened the voice; a brighter variant lifted
about 3.4 semitones, which risks sounding perky. Tags work, modestly. They also brought failures: one smile tag alone
before a short line made the model say the phrase twice, and a mid-line softening tag put the voice into creak. So
every tagged take is checked.

### Failure modes, and the guard for each

| Failure | Guard |
|---|---|
| A tag read aloud | tags stay inside the voice's character; Whisper checks every take for tag words spoken |
| A tag performed as a sound effect | tags name voice qualities, never objects or events |
| Over-acting | tag sparingly, one tag per segment, stability kept at its start value; pace and pitch range measured against an untagged control |
| A repeated phrase | a word-for-word check on every take |
| Creak (vocal fry) on a key phrase | a creak count (low, irregular pitch frames) against the untagged baseline |
| Drift between lines | one small vocabulary, the same settings and context rule; seed and request id recorded per take |
| A pause that breaks the edit | pause tags only where the edit can't give the air |
| A take that no longer fits its shot | every paced take measured against its shot's room |

### Measuring breath and effort

Every tagged take is measured against the same voice's untagged takes **of the same words** (several of them, so the
normal spread is known), on the spans the tag governs and on the whole line:
- **breath and whisper**: the voiced fraction of speech, cepstral peak prominence, harmonics-to-noise, the first-minus-
  second harmonic, spectral tilt, and effort (the span's level against the rest of the take);
- **warmth and smile**: pitch level and range, formants, spectral centroid;
- **energy**: loudness and its contour; **creak**: low, irregular pitch; **pace**: words a second and pauses; **words**:
  errors, repeats, tags spoken.

A take is rejected when its breath measures sit clearly above the untagged spread (on average more than one spread, or
two core measures well beyond it, or the voice dropping out). These checks were validated against the owner's ear on
takes they'd already judged, before they were trusted. The owner still picks by ear.

### The A/B before a full re-voice

Tag sparingly, then A/B a handful of key lines for the owner (the current take, the tagged take, both level-matched,
side by side) before re-voicing everything. Because every beat is keyed to the voice's words, a re-voice re-times the
film automatically; the renders and the mix still rebuild.

When a line's direction really matters, a single A/B isn't enough to know: the same tag can pass on one seed and measure
breathier on the next. Run a round of the tag loop instead (several candidates, several seeds, extra untagged seeds,
gates and a measured feeling, then an ABC reel), and adopt the pick as that exact file: [the tag loop](#reference-the-tag-loop-voicing-measuring-and-picking-audio-tags).
How each measure is read: [measuring a read](#reference-measuring-a-read-inflection-breath-and-spectrograms).

### Settings and context

Tags work with the voice's stored settings (stability about 0.5). Neighbouring lines go in as plain words, never tagged
(directing.md).

---

## Reference: Designing a voice

When no library voice fits (a brand character, a narrator with a very particular presence), design one from a brief
with Voice Design. The design model is always named explicitly in the request (Slate does this).

### The voice brief

Write it before any preview:
1. **Who they are**: in a few sentences, as a person.
2. **Values**, each with a source (the brand's own words, the product's copy).
3. **How they speak**: warmth, pace, breath at full stops and turns, pitch register, delivery per sentence type
   (statements, questions, the call to action), the opening line, the microphone and the room.
4. **What they never sound like.**
5. **A philosophy-to-sound table**: each value, and how it sounds.
6. **The model**, the prompts, the preview text.
7. **The measured comparison** of the candidates, the production-model check, a recommendation, and the credits spent.

If you can run sub-agents, one can turn the brand's philosophy into the brief while you prepare the tools; otherwise
write it yourself first. Either way, every value cites its source.

A voice brief that quotes company code or internal material is company material: it stays with the company's files and
never travels into a personal or public package.

### Prompts

Voice Design reads prompts in a set order: native language, gender and age range, quality, a two-to-five-word persona,
two or three emotion adjectives, then timbre, pacing and delivery.
- Say "thick" rather than "strong" for an accent; don't use "accent" to mean intonation.
- Avoid "reverb" and "echo": they design the room into the voice.
- Longer preview text gives more stable previews.
- Higher guidance adheres to the prompt more closely but can cost quality.

### Previews and the production-model check

```
slate voice design --description "<the prompt>" --text "<the preview text>"
```

- Previews are measured and ranked on proxies: a pace of about 150 to 170 words a minute, sentence pauses of about 0.35
  to 0.7 s, a pitch range of about 9.5 to 13 semitones, statement endings that fall (at least a semitone, never rising
  much), a clean floor, and every word heard (brand words included).
- **Keep a candidate, then check it on the production model** (`--save`, then `--check`). Designed voices can perform
  differently there: higher in pitch and faster than their previews. Render the candidates on the film's own model
  before choosing.
- The owner picks by ear.

### Designed voices and direction

Designed voices can be less performative on the newest model than on older ones, and tags land more readily when the
delivery is already in the voice. Keep a designed voice's tags inside its designed character; never ask it for a
performance it wasn't designed for (laughing, big emotion). See v4-tags.md.

### Cleanup

A designed voice can carry a baked-in artifact (a faint buzz high in the spectrum, present even in lossless output),
because it's in the voice, not the codec. Diagnose it, then offer cleanup variants (cleanup.md).

---

## Reference: Voice policy: who may be voiced, and how

These rules hold in every mode and for every brand. They're enforced in code before any request is sent (a refused
voice exits 1 with the reason) and checked again by the voice policy gate.

### Whose voice

| Voice | Allowed? |
|---|---|
| A library voice (from the vendor's voice library) | Yes: the default. |
| A designed voice (made with Voice Design from a brief) | Yes. |
| The owner's own voice, as a **professional** clone the owner verified with the vendor themselves | Yes, in every mode. |
| The owner's own voice as an unverified or instant clone | No. |
| Anyone else's voice as a clone (a teammate, a client, a customer) | Never. |
| Anyone else's voice as a real recording, with their permission | Yes, as a recording: never synthesized from. |
| A public figure's voice, cloned or recorded | Never. |

- The profile records which it is (a clone names whose voice it is, what kind, and whether its owner verified it); the
  vendor's own voice category is checked live, so a voice the vendor marks as cloned or famous is caught.
- **Slate has no way to make a clone and never verifies one.** Verification is the owner's, done in the vendor's own
  interface. An agent never does that step and never enters the owner's credentials.
- **Autonomous agents** may narrate with the owner's own verified clone, and no other clone. Their films are still held
  for the owner before anything is published.

### Character voices

- A brand's character voice (a designed voice with a persona) is the brand's. Never ship its audio as a demo outside the
  brand's films.
- A voice brief that quotes company code or internal material stays with the company's material; it never travels into
  a personal or public package.
- Designed voice ids belong to the vendor account that made them and don't transfer to another account.

### AI labels

- None unless the law requires one. Slate records which voices in each film are synthetic, in the manifest (internal
  only), so it's clear when a law does apply.
- Platforms (TikTok, YouTube, Meta) have their own rules that can require labels on realistic AI voices even where the
  law doesn't. Mention it once when it's relevant; whether to follow them is the owner's call per platform.

### Commercial use

Only paid plans' output is licensed for commercial use: free-plan output can't be used commercially at all, and output
from beta services can't be used commercially on any plan. Lossless voice (PCM) needs a higher plan; Slate uses the
best format the account allows and records any fallback.

### Keys

The ElevenLabs key is set by a person in their own Terminal (`slate connect elevenlabs`), never in chat. Autonomous
films use a separate key with its own credit quota and only the scopes they need, so they can never spend the owner's
main balance.
