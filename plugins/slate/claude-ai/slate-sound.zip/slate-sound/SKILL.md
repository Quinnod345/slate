---
name: "slate-sound"
description: "Design, score, mix and verify the sound of a Slate film. Covers the warm starting palette as a contextual preset, each brand and film's chosen palette, measured effects from picture events, Eleven Music scores planned per act and assembled by measurement, balance against the voice, and the sound gates. Use when a Slate film needs its effects spotted or rendered, its score planned, composed or assembled, its mix built or rebalanced, its sound verified, a brand's sound palette defined, or an answer on how a film should sound."
---

> Knowledge-only edition of Slate's `slate-sound` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-sound

Sound is designed, not stock, and it's locked to the picture: every beat the eye follows lands within a frame of its
sound, and the voice is always understood. The bar is the approved proof: "intentional", noticeable without being too
loud, and matching exactly what happens on screen.

This is stage 9 of the production. Its inputs are the voice's placed takes (`timing/vo_cues.json`), the picture's beats
(`timing/visual_events/act<N>.json`, from slate-build) and the brand's sound palette.

## 1. Taste and the starting palette

Read `slate history context --topic sound` when a private history is selected. The starter below reflects one
successful direction, not a universal prohibition. Every brand can choose its own materials, energy and silence.
Use the current brief and listening feedback to set its palette; measurements check that palette and preserve
approved references. A detector flag is evidence to inspect, not a substitute for hearing the intended result.

- **The warm starter:** pads, small soft felt notes, and hollow wood (woodblock, temple block, clave, knock, rim), with
  air for moves and a sub for a big landing. **No chimes** is this starter's choice, along with avoiding bells, metal,
  glass and buzzers; another palette can use them.
- **Design the result.** The current effects renderer uses real sampled instruments for tonal roles and reports a
  missing sample rather than substituting a synthesized tone. A previous synthesized layer sounded cheap in that
  proof; it does not establish a universal creative ban on synthesis or stock material.
- **The starter avoids sustained pitch glides and room-tone drone.** A glide had read as a siren in the earlier proof.
  A different direction can permit glides with both `rules.no_glides` and `rules.no_slide_ups` false, and drone with
  `rules.no_drone` false in the chosen palette.
- **One deliberate sound per kind, with variation** is the starter's interaction language. Repeats and shared sounds
  can be chosen through the palette's rules; keep intentional repetition distinct from an accidental repeated file.
- **Restraint and silence** can make a landing matter. Off-screen sound, ambience and dense passages can also serve a
  requested story. Choose the hierarchy deliberately and keep narration intelligible.

That palette (proof 2's, the approved proof) is the **starting point**. Each brand gets its own palette during
onboarding: its key and tempo, its materials, its banned timbres, its motif, and its levels measured against its
voice (slate-brand). See [taste](#reference-sound-taste) and [palette](#reference-sound-palettes).

Use the latest brief and authorized listening feedback for revisions. Keep the original proof, feedback and new result
as comparison history. The film's `sound.palette` overrides the brand's palette for that film. A requested experiment
does not need approval of the same choice again; source-bound proof, reference and delivery approvals remain separate.

## 2. Balance: the voice first

A mix is a hierarchy, not one level for everything:
- the narration is always fully intelligible;
- small tactile accents (wood clicks, knocks, felt notes) may stick out a little;
- noise textures (whooshes, swishes, air, reverse bursts, write-on scratch) and tonal sweeps (risers, pad swells) sit
  well under the voice and duck harder while it speaks;
- bright noise (roughly 2 to 6 kHz, where consonants live) stays out from under words;
- no effect is ever louder than the voice.

The approved proof put its effects about 11 LU and its UI clicks about 17 LU under the voice, clearly audible. A later
mix buried them 25 to 28 LU under, and they stopped standing out: that was a failure too. See [mix](#reference-the-mix).

## 3. Spotting: tell the sound what each beat is

The picture's events name each beat's **kind** (tap, type, land, snap, count, draw, data, page, stamp, whoosh, swell,
character, impact) and **size**. The starting recipe gives kinds distinct families, groups bursts into gestures and uses
at most one impact per act, often with an echo on the score's tempo. Choose density and repetition for this brief;
every synchronized sound's measured anchor still needs to sit on its beat's frame. See
[spotting](#reference-spotting-from-the-pictures-beats-to-sounds) and [families](#reference-families-one-sound-per-kind-of-interaction).

## 4. Run the approved effects design

`slate sfx status` reports the hash-bound proof 3 approval. The effects engine is built; it refuses until that approval
is present and current. After approval, `slate sfx spot` writes measured cues and
`slate sfx render` writes their balanced stems; `slate sfx run` does both. Use `--dry-run` to inspect the work without
writing, or `--detach` to queue it in the render slot. Missing samples and malformed event files stop with a report;
they never turn into a synthesized stand-in or a silent act. A score-and-voice film can still mix without effects.
See [effects engine](#reference-the-designed-effects-engine).

## 5. The score

A composed score is part of most films: Eleven Music on its best model, composed per act and assembled by measurement.
The warm starter keeps the effects' materials out of the score to make their roles distinct; choose instrumentation
for the current sound direction and record it in the palette and score plan.

```
slate score plan          # one composition plan per act: 3 s pre-rolls, parts under 90 s, blocks of 3 s or more
slate score compose       # composes the missing takes (spends; estimated and budget-checked first)
slate score assemble      # measured placement, equal-power joins, freeze repairs, the gap check
slate score qa            # silence and noise in the takes and the score
```

`sound/score/directions.json` (hand-edited) says where the music does something special: stops, blooms on a landing,
splits at a story turn, styles. Never name an artist, songwriter, song or label in its styles or a plan's prompts,
never ask the music to sound like one, and no lyrics. The playbook, and why each rule exists:
[score](#reference-the-score-the-eleven-music-playbook).

## 6. The mix

```
slate mix                 # voice, score and any effect stems, mixed to the film's targets
slate mix --calibrate     # trim each effect stem to its palette level against the voice first
slate verify              # the sound gates, the balance gates included
slate sound balance       # the balance on its own: every word clear of the score and effects, each family in place
```

The balance gates (`sound.balance.*` and `sound.planned_stops`) measure the mix word by word against the voice: every
word at least 12 dB clear of everything else in the consonant band, nothing louder than the voice while it speaks,
textures and accents where the brand's palette puts them. A delivery needs them to pass like every other sound gate.

The mix places the voice from its cue sheet, sets the score under the voice with ducking (by default 18.5 LU under
before a 6 dB duck, the starting palette's level; `slate mix --under` and `--duck` change it for one mix), runs the
score's own clarity guard (its top dips under any word it would crowd, by just enough), sets effect stems at the
palette's levels, and takes the whole to −14 LUFS with the true peak at or under −1 dBTP, in 48 kHz, 24-bit, exactly as
long as the picture. Four delivery stems (dialogue, effects, ambience, music) sum to the mix sample for sample. Manual
polish in a DAW is allowed, but the engine's timing stays the reference. See [mix](#reference-the-mix).

## 7. Verification

`slate verify` runs sixteen core gates (loudness, stems summing, the music gap, voice sync, cue sync, repeats, glides,
drone, levels against the palette, the brand's sound reference, clarity under the voice, the music licence for the
destination, the voice limiter's touch, notes on the brand's key, timbre, and Whisper hearing the mix word for word)
and the seven balance gates (section 6, an approved span kept as approved among them), and a delivery needs every one
of them under its configured policy. Glides, drone, repeats and timbre have supported palette controls; allowing a
material does not erase the measured detector evidence or approve the mix by ear. Only PASS counts; a gate that can't
run (no approved sound reference, say) is UNCHECKED. See
[verification](#reference-verifying-the-sound).

A change to the approved narration (a polish, a re-voice) moves the balance: re-run the balance gates after it and
re-solve the mix's rides (mix.md).

## 8. Preserve what worked; explore what was requested

Keep the approved sound as the comparison baseline. Apply small balance notes without changing unrelated decisions;
when the owner requests a new sound or an experiment, build it within the authorized scope. Record both successful
and rejected versions with their feedback. A previous request to return to a proof means that redesign lost something
valuable in that film; it does not ban future redesigns. Compare intentionality, audibility and voice clarity by ear
as well as by measurement. New experiments do not overwrite the approved source.

## References

- [taste](#reference-sound-taste): the owner's sound taste, rule by rule.
- [palette](#reference-sound-palettes): the starting palette, a brand's palette, levels, instruments.
- [families](#reference-families-one-sound-per-kind-of-interaction): one family per kind of interaction; impacts and echoes.
- [spotting](#reference-spotting-from-the-pictures-beats-to-sounds): from beats to sounds, moment by moment.
- [score](#reference-the-score-the-eleven-music-playbook): the Eleven Music playbook and directions.json.
- [mix](#reference-the-mix): the balance hierarchy, the mix, stems and their manifest.
- [verification](#reference-verifying-the-sound): the sixteen core and seven balance gates, configured policies and measured sync.
- [effects-engine](#reference-the-designed-effects-engine): commands, proof approvals, reproducible cues, beds and approved spans.

---

## Reference: The designed effects engine

The engine turns the picture's events into measured cues, then balanced effect stems. It carries the approved sound
design: wood, air, subs, sampled felt notes and sampled pads, with natural variation and the voice always understood.
Its runtime gate still requires a person's approval of the exact proof file; a changed or revoked proof closes it.

### Commands

```
slate sfx status                 # approval state; no film required
slate sfx spot --seed 7          # picture events to sound/sound_cues.json; no stem render
slate sfx render                 # existing cues to sound/stems/ and stems.json
slate sfx run                    # spot, then render (also the default for slate sfx)
slate sfx run --dry-run          # inspect the work; no decoding, locks, writes or queued job
slate sfx run --detach           # keep working through the job queue in the render slot
```

The seed controls variation. It is combined with each event's stable identity, so inserting an earlier tap does not
reroll the rest of the film. A cue records its voice parameters, sample take, gain and measured anchor. The sheet
records the film clock and hashes of its events, palette, brand sound/motion, timing and authored spans.

Every expected act must have valid `timing/visual_events/act<N>.json`. Missing, unreadable or malformed files stop with
a per-file report. An act without sound says `{"silent": true, "reason": "A held frame."}`. An empty array is not that
declaration. A derived film reads inherited events in place and writes its new cues and stems only in the child.

One interaction becomes one logical cue. A count carries individual measured clicks in `notes`; its clicks follow the
explicit start, duration, value change and frame hold. A stamp or impact can contain several material layers within
one cue. Sampled swishes vary their rate and are measured again after variation. Composite air layers align their
peaks before the combined cue is placed.

### Palette and instruments

Each `sound.palette.kinds.<kind>` supplies its material family, processing family, stem, anchor, rendering type, gain
and params. The defaults use installed sampled swishes, wood voices, air, subs and sampled tonal instruments. Musical
notes come from the brand's key or explicit pitches; the character's motif must be supplied. Named eases resolve
through the brand's motion law and are pinned as curve data in the cue. See [palette](#reference-sound-palettes).

Text write-ons use `start`: their first audible sound on a 2 ms RMS envelope, 40 dB below its peak, lands on the
picture beat. The louder middle of the air does not pull the sound ahead of the writing.

For an authored exception, store the choice in `film.json` `sound.event_overrides`, keyed by both shot and event:

```json
{"sound": {"event_overrides": [
  {"shot": "S01", "event": "panel-arrival", "params": {"kind": "temple", "pitch": "A4"},
   "gain": -30, "balance_family": "accents"}
]}}
```

Use the film's own identity and musical pitch. Each entry may set `type`, `sound`, `balance_family`, `stem`, `anchor`,
`params`, `gain` and `pan`. Those values merge into that event's palette kind; nested params merge as well. Rendering
types must be supported cue voices, families must be `accents`, `textures`, `swells` or `impacts`, and stems must be
`ui`, `fx`, `tonal` or `amb`. Anchors must be measurable. Timing, cue routing and approval metadata cannot be set
through an override. The picture still owns motion duration and easing; seeded variation remains reproducible.

These film choices survive re-spotting and record their hash on the generated cue. A missing or duplicate identity,
unknown field, unsupported family or nonfinite value refuses before rendering. An override inside a pinned approved
span also refuses: approve the revised sound before pinning its reference. Overrides keep the palette's verification
rules, including one sound per kind; a new sound name does not exempt the cue from those checks.

Samples stay in their installed libraries. Missing files or tonal instruments raise a prerequisite error with a next
step. The engine never downloads, copies or substitutes them with synthesis.

### Authored beds and composed scores

Most films use a composed score. In score mode, bed spans document permitted sound but do not generate continuous pad
beds. To author sampled beds, set `film.json` `sound.music.kind` to `bed` and provide `sound.beds` entries:

```json
{
  "id": "opening-pad",
  "from": 0.5,
  "to": 4.5,
  "why": "The opening holds this chord before the next passage.",
  "gain": -31,
  "params": {"notes": ["A3", "C4", "E4"], "vel": 35, "attack": 0.4, "release": 0.5}
}
```

Those notes are an example; use the brand's authored chord. Notes are required: a span alone cannot invent its harmony.
The voice is sampled `spad`. Same-chord overlaps use a measured 0.3-second handoff at equal energy, with gain knots on
the film clock. A bed between two handoffs keeps both envelopes. Planned silences and beds survive re-spotting.

### Preserve approved spans

`sound.music.match` entries name a film-relative approved reference bundle with `clip`, `from`, `to`, `core`,
`pin_cues` and `pin_rides`. Its folder must have a current hash-bound `sound_proof` approval and contain
`cue_sheet.json` and `balance_used.json`; matching voice and score files belong in `family_stems/` inside that bundle.

Pinned cues retain exact timing, gains, seeds, pitches and reverb. Approved legacy layers remain separate; regrouping
them would change the approved sound. A layer whose event differs from its picture interaction supplies an explicit
`visual_event` owner. Deleted or moved interactions refuse, and spans are never relocated automatically. Reapprove
the changed sound when the picture changes. The reference loader rechecks its approval before and after reading it.

Keep `render_log.json` in the approved bundle. Its dry waveform fingerprints bind sampled instruments and named
motion curves to the approved sound, at the same sample rate. A changed waveform refuses even when its cue fields
match. Legacy bundles without a log can preserve literal synthesis and built-in curves; unresolved sampled roles,
recordings and brand curves require approved render evidence. Slate never guesses the missing source context.

After rendering, run `slate mix` and `slate verify`. Rendering produces provisional balanced stems; the final mix
recalculates its guards against the current delivered voice and score. Only passing gates establish delivery quality.

---

## Reference: Families: one sound per kind of interaction

### One family per kind, each its own material

The warm starting recipe maps touch to wood, paper to paper, marks to graphite and ink, moves to air, chapter swells to
tuned air or a pad, a character to its motif, and a big landing to a deep, hollow sound. Consistent families help the
viewer learn that language. The current palette and authorized feedback can choose other materials, shared sounds or
deliberate repetition; do not treat this earlier mapping as universal.

- **Be strong-willed about what each beat is.** The builders tag every beat with its kind and size (slate-build); a beat
  with the wrong kind gets the wrong sound.
- **The starter separates kinds.** Its tap and snap have different sounds; the chosen palette's rules decide whether
  sharing serves another treatment.
- **Unknown kinds are reported, never silently dropped.**

### Variation that sounds played, not random

The same sample repeated reads as cheap: one film's first mix put 483 cues on 48 distinct sounds, with runs of up to
eleven identical hits. The fix was designed variation:
- variations within a family differ the way real playing does: pitch within the key's pentatonic, the material's colour,
  the strike, the timing of a second contact;
- the starter avoids consecutive identical variations; the configured repeat policy can permit intentional repetition;
- **bursts are gestures**: a list writing on is one writing gesture, a run of dots is one run walking up the scale, not
  twelve identical clicks;
- density stays readable (no more than about eight transients in half a second).

### Sizes

`s` a small detail, `m` normal, `l` a moment. Size scales the sound's weight, not just its volume: a large land is a
deeper knock, not a louder small one.

### Impacts

- The starting recipe uses **one impact per act** and a different file for each. The brief can choose several impacts
  or a recurring hit; declare their timing and use the chosen palette's repeat policy.
- A big impact gets a **tempo echo** on the score's beat (a dotted eighth or a quarter note), each repeat about 6.5 dB
  softer and darker, panned to the other side.
- Land it at the end of a sentence, so it plays in the voice's pause, and let music and hit land together.
- Before it, a held breath: the effects fall silent and the music stops dead.

### A character

A brand character's sounds are its motif (small felt notes, one per part of the mark, or a short phrase), a small wood
tick for pointing, and soft pads. One event per note, each on its own contact frame, and when two of its sounds land on
the same frame only one plays. The score yields to a pad under the character's motif, so its notes carry the melody.

---

## Reference: The mix

`slate mix` builds the delivery mix: the voice from its cue sheet, the score under the voice with ducking, any effect
stems at their palette levels, one fixed gain to the film's loudness target, and four delivery stems that sum to it.

### The balance hierarchy

Balance a film's sound as a deliberate hierarchy, not one level for everything:
1. **The narration is always fully intelligible.** Nothing covers a word.
2. **Small tactile accents** (wood clicks, knocks, felt notes) can stick out a little: that's what makes sound locked to
   picture feel intentional.
3. **Noise textures** (whooshes, swishes, air, reverse bursts, write-on scratch) and **tonal sweeps** (risers, pad swells,
   builds) sit well under the voice and duck harder while it speaks.
4. **Bright noise stays out from under words**: roughly 2 to 6 kHz is where consonants live.
5. **No effect is ever louder than the voice**, at any moment.
6. **The tonal bed** sits about 20 LU under the voice, and pads under speech are low-passed at or below about 1.4 kHz, so
   harmony stays out of the words.

The owner judges by ear; the gates check every level by measurement (the levels and clarity gates).

### What the mix does

```
slate mix                       # voice, score, effect stems
slate mix --no-score            # voice and effects only
slate mix --calibrate           # trim each effect stem to its palette level against the voice, and report the trims
slate mix --under 17 --duck 5   # the score's level under the voice and its ducking, for this mix
```

- **The voice** is placed from `timing/vo_cues.json`, each take levelled by its voiced loudness, protected by a
  zero-latency limiter on the voice alone (a limiter with latency once moved the voice 240 samples late).
- **The score** sits under the voice and is ducked under every word by a follower on the voice.
- **The score's own clarity guard** runs next: wherever the score on its own would come within 19 dB of the voice in
  1–5 kHz during a word, its top (above 600 Hz) dips under that word by just enough, at most 20 dB, held 0.15 s either
  side and ramped over 0.3 s, so it moves at a phrase's pace; everywhere else it plays as composed. The mix record
  lists every dip (`score_guard`), and a brand turns it off with `score_guard: false` in its palette's balance.
- **Effect stems** come from `sound/stems/` at the palette's levels against the voice; wood clicks don't duck.
- **One linear gain** takes the whole to the target (−14 LUFS integrated, true peak at or under −1 dBTP, 4× oversampled),
  any limiting as one linked curve on every stem, never a one-pass loudness normalizer (its stems couldn't sum).
- **The output**: `sound/mix/final_mix.wav` at 48 kHz, 24-bit, exactly as long as the picture (never trimmed to the
  shortest stream), and four delivery stems (dialogue, effects, ambience, music) in `sound/mix/stems/` that sum to it
  within one part in a million.

### The brand's balance

The balance gates and the score's guard read the `balance` in the brand's sound palette, laid key by key over the
starting balance (the films' approved mix). A palette that names its `families` replaces them whole.

| Key | What it sets (the starting value) |
|---|---|
| `families` | which cue kinds make each family: accents (tap, land, snap, count, data, stamp, character), textures (type, draw, page, whoosh), swells, impacts; the score is the music stem, the plate the ambience |
| `clarity` | the consonant band (1–5 kHz), the rule (every word 12 dB clear of everything else), the trade's flag and floor (8 and 6 dB), and a family's own floor (`alone_min_db`: the score 19 dB on its own) |
| `score_guard` | the score's clarity guard in `slate mix` (target 19 dB, split at 600 Hz, a dip of 20 dB at most, held 0.15 s, ramped over 0.3 s); `false` turns it off |
| `never_over` | how far under the voice everything stays while it speaks (0 dB: never louder) |
| `texture_air` | the textures' 2–6 kHz at least 20 dB under the voice's own |
| `accents_over_score` | accents and impacts clear the score by 3 dB in their own loudest band, over their loudest 120 ms |
| `levels` | each family's range against the voice: integrated, hit by hit and inside words (the score: −28 to −17 LU integrated, −19 at most inside words) |
| `stops` | how silences are read: the fade that counts as part of a planned stop (20 dB under the music's median, up to 2 s), whether the score's own rests count as planned (`score_rests`), the gap floor (−60 dBFS over 0.5 s), and whether the film opens or ends in silence (`open_silent`: only when the plan says so; `end_silent`: `"always"`, a silent last second whatever the plan, the films' rule and the default, or `"plan"`) |
| `approved_spans` | stretches the owner approved by ear (`{"from", "to"}` in film seconds): a word under the clarity rule there is listed as approved, not failed |

`slate sound balance --words` prints every word's clarity, so a level change can be judged word by word before the
next mix.

**An approved span stays as approved.** A span the owner approved as a clip (the palette balance's `approved_spans`,
naming the approved file and its window) is checked against that clip every time: family by family, ride by ride and by
the score's level (`sound.balance.approved_spans`).

**Hear what the rides did.** `slate mix --listen [N]` writes a listening file of the N hardest-ridden accents, each from
2.5 s before its hit to 3 s after, as mixed before and now, over the film's own picture (black with the same labels when
no master is on the machine). It reads the rides the mix's guards record (sound/mix/rides.json), so until those guards
run it says what it needs.

**A voice change moves the balance.** A voice polish, or any change to approved narration, changes the speech band the
balance measures (the first film's polish gave up about 0.8 dB of 1–5 kHz). Re-run the balance gates and re-solve the
mix's rides; a span pinned to rides approved before the polish can't keep them.

### Effect stems and their manifest

Stems made outside the effects engine (in a DAW, or by hand) go in `sound/stems/`, with `sound/stems/stems.json` naming
each role's file and whether it ducks:

```json
{"stems": {"ui": {"file": "ui.wav", "duck": false}, "fx": {"file": "fx.wav", "duck": true}, "amb": "amb.wav"}}
```

Roles: `ui`, `fx`, `verb` (they sum to the effects stem), `tonal`, `tverb` (music), `amb` (ambience). Without a
manifest, the mix takes whichever role files are present. Manual polish in a DAW is fine; the engine's timing stays the
reference.

### Levels and taste

- The approved proof put the effects about 11 LU and the UI clicks about 17 LU under the voice, clearly audible. Those
  are the starting palette's levels; a brand's own come from its sound reference.
- Calibrate a new design to the last approved level before comparing, so an A/B hears the design, not the volume.
- Don't bury the effects: a mix that put them 25 to 28 LU under the voice lost the thing the owner loved.

### After the mix

`slate verify` runs the sound gates (verification.md). Loudness targets differ by destination (platforms normalize
differently; −14 LUFS is a common web target, not a documented rule for every platform); the format sets the film's
target, and delivery can derive others.

---

## Reference: Sound palettes

A palette says what a brand's films sound like: which material plays each kind of beat, where each sits against the
voice, which instruments carry the tonal roles, what the score must never play, and what's banned. Slate ships one
starting palette (the approved proof's), and each brand's pack overrides it key by key (`sound.palette` in brand.json).
The film's `sound.palette` applies after the brand for that film. This is a contextual starting sound, not a universal
style rule; the latest brief and authorized listening feedback govern creative revisions.

### The starting palette

| Kind of beat | Family | Stem |
|---|---|---|
| tap (a row, check, chip or button) | wood block | UI |
| type (text writing on) | soft air | effects |
| land (a card, sheet or panel landing) | wood knock | UI |
| snap (a state flips) | clave | UI |
| count (a numeral counting) | tuned wood clicks | UI |
| draw (a line or chart drawing) | air on the draw's ease | effects |
| data (a value, bar or marker lands) | a small felt note | tonal |
| page (a sheet slides, deals or turns) | swish | effects |
| stamp (a group completes, a seal sets) | temple block with a felt note | UI |
| whoosh (a view carries into the next) | air | effects |
| swell (the picture fills or opens) | a sampled string pad | tonal |
| character (the brand's mark gestures) | small felt notes, the motif | tonal |
| impact (a designed big landing) | a sub with a hollow temple knock | effects |

**Levels against the voice** (integrated, measured on the approved proof's stems): UI clicks about 17 LU under, effects
about 11 LU under, within about 2 LU. The voice is levelled by the loudness of its voiced part; every other cue by its
peak.

**The voice limiter's margin:** the voice is limited 0.9 dB under the true-peak ceiling when other stems sound, so
they can sum on its peaks, and 0.4 dB when it's heard alone. `levels.voice_margin_db` sets the first for a film whose
linked limiter keeps the sum under the ceiling transparently (one film's limiter touched 6.2% of the speech at 0.9).

**Ducking under speech:** tonal and ambience about 6 dB, effects about 3 dB, reverb about 4 dB; the UI clicks stay crisp.

**Rules the starter carries:** no glides, no slide-ups, no drone, one sound per kind, no sound shared between kinds, no
identical repeats, every sound within a frame of its beat, tonal roles on sampled instruments.

The chosen palette can set `rules.no_glides`, `no_slide_ups`, `no_drone`, `one_sound_per_kind`,
`no_sound_shared_by_kinds` and `no_identical_repeats`. Permit glides by setting both glide rules false. These controls
change the applicable creative policy; cue timing, readable narration and required source evidence still need checks.

**Materials** in this starter (wood block, temple block, clave, knock, rim, felt marimba and the like) stay out of its
composed score to keep roles distinct. Choose the current score's instrumentation with the sound direction.

**Pads are space**: low, slowly breathing chords hold the harmony under whole passages and open up at the big moments.
Under the voice they stay low-passed, so the harmony stays out of the words.

**Design the source choice:** the earlier effects recipe used the palette's sampled materials and generated audio for
specific gaps. Another requested approach can use generated or stock sources within its authorization and budget;
record their provenance and inspect the result. The current renderer still requires its declared samples.

**Banned timbres:** bells, chimes, glockenspiel, celesta, crotales, tubular bells, vibraphone, music box, metallic hits,
glass, buzzers.

### Size, runs and an act's colour (opt-in)

Three palette tables shape the engine's choices; without them a film spots exactly as before.

- **`sizes`**: a beat's size as weight, e.g. `{"s": {"gain_db": -3}, "l": {"gain_db": 2, "octave": -1, "rate": 0.92}}`.
  `octave` moves pitched wood and felt notes (layers included) by whole octaves, so a large land is a deeper knock;
  `rate` darkens sampled swishes; a kind can set `size_weight: false` to opt out.
- **`walk`**: bursts as gestures, e.g. `{"gap_s": 1.3, "min": 3, "kinds": ["tap", "snap", "land", "data", "stamp"]}`.
  Beats of one kind in one shot, each within `gap_s` of the last, are one run, and its pitched items walk up the key's
  pentatonic a step per item, from the tonic or a seeded step above it (`spread`, 2 by default). An explicit pitch
  (an override, a kind's `pitch`) still wins.
- **`acts`**: an act's own colour, e.g. `{"3": {"gain_db": -1, "kinds": {"snap": {"params": {"kind": "temple"}}}}}`.
  It merges over the palette's kinds for that act's beats, before any event override, so a film can change register,
  material or level act by act inside one vocabulary.

### A brand's palette

Onboarding (slate-brand) makes it, from the brand's own world:
- its **key and tempo range** (every pitched effect sits on the key's pentatonic, so nothing clashes with the score, and
  nothing sits on a leading tone);
- its **materials** and **banned timbres**;
- its **motif** (a few notes that belong to the brand or its character) and the instrument that plays it;
- its **instrumentation** for the score;
- its **reference levels**, measured from its approved 10 to 20 second sound reference against its voice.

The owner's palette is where every brand starts, and a brand's own world decides where it goes.

Explicit `materials` and `banned_timbres` lists replace the starter lists, including an intentionally empty ban list.
A list in `sound.palette` takes priority over the top-level shorthand. A palette can also choose its measured timbre
limits with `sound.palette.timbre`: `centroid_max_hz` (null for no ceiling), `no_chimes`, and `no_metallic`. The warm
starter uses 1500 Hz, true and true. Configure those choices for the intended brand sound instead of inheriting an
unwanted ban. The timbre report keeps detector flags even when a permitted instrument does not fail the palette
gate; passing the configured limits is not listening approval or proof that a classifier is always right.

The renderer reads each kind's `type`, `gain`, `params` and `balance_family` alongside its material family, stem and
anchor. For example, a wood kind uses `type: "wood"` and `params.kind` for its material; a sampled felt note uses
`type: "snote"` with its role and pitch. Composite stamps and impacts use `type: "layered"` with their child voices in
`params.layers`. A page uses the installed sampled swish takes, with rate variation measured before placement.
Explicit kind params override the starting data. Put chord pitches in `params.notes`; the top-level cue `notes` field
is for independently anchored gesture hits. A character's `sound.motif` gives `notes` or a `gestures` mapping, so its
sound is authored by the brand. Processing families are accents, textures, swells, impacts and plate; authored musical
beds use the score family.

### Instruments

Tonal roles (small notes, pads) play on Apple's sampled instruments, found in place on the machine (installed with
GarageBand's sound library and Logic) and never redistributed. If they're missing, `slate doctor` fails and says what to
download; there's no synthesized stand-in for a tonal role. Plate ambience from a generated shot can serve as a bed
(it came back as usable wind and air on the first films), high-passed and well under the voice.

### Changing a palette

A palette changes on purpose under the current brief and authorized feedback. A requested redesign is work already
authorized, not another request for approval of that same creative choice. Keep the original palette, listening notes
and revision as history, and compare levels, brightness, sync and the intended feeling. Required approval of a new
source-bound sound reference or delivered clip remains distinct from permission to explore; never overwrite an
approved source or mark the revised result approved without its own evidence.

---

## Reference: The score: the Eleven Music playbook

A composed score is part of most films: Eleven Music on its best model (named explicitly in every request, because the
API's default is an older model), composed per act, assembled by measurement, and gap-checked. Every rule below is a
lesson the first films paid for.

Why a composed score at all: synthesized tonal layers sounded cheap. Music is composed (a score per act), tonal effects
play on real sampled instruments, and synthesis is kept for air, ink, beads and subs, where it shines.

### The steps

```
slate score plan                  # sound/score/plan.json and one plan per part, cut to the shots
slate score compose --dry-run     # what it will cost, nothing spent
slate score compose               # composes the missing takes; takes are kept, locked takes never redone
slate score assemble              # sound/score/score.wav and score.json
slate score qa                    # silence and noise spans in every take and the score
```

Compose runs through the ledger (estimated and budget-checked before the first call) and replays offline in tests.

### Planning (why each rule exists)

- **One composition per act**, not one for the film: a single six-minute composition came back with 21 seconds of
  silence over the film's biggest moment and 18 seconds of noise near the end.
- **Split any part longer than about 90 seconds** at a story turn: longer plans ran out of material and went silent early.
- **The plan's shape follows the model.** music_v2 and music_v2_5 (the default) take plans made of **chunks**, with the
  brand's styles on every chunk; only music_v1 takes the older **sections**, and the v2 models reject a section plan
  outright (the source films hit this). `slate score plan` builds the shape the model takes, read from registry.json,
  so a plan made before a model change has to be made again.
- **Every block (chunk or section) at least 3 seconds.**
- **A 3-second pre-roll**, cut at assembly, and every part runs at least 3 seconds past its hand-over: Eleven Music fades
  in and out at a take's edges regardless of the plan.
- **An exact moment must be a part boundary on the word's time**, not a section inside a take.
- **The score never plays the effects' materials** (they go in its negative styles), so the two never blur together.
- **Never name an artist, songwriter, song or label** in a plan's styles or prompts, never ask the music to sound like
  one, and no lyrics. The outputs aren't exclusive, and some industries are excluded by the vendor's terms (the front
  door's licences reference has the terms).
- **Leave room for the narrator** in the style, and let the score yield to a pad under a character's motif.

### Directions: sound/score/directions.json

The one hand-edited file in the score's folder. It says where the music does something special:

```json
{"parts": {"act3": {"end": "stop", "stop_before_s": 0.5},
           "act4": {"join": "bloom", "landing_event": "key_value_lands"}},
 "split": {"act2": ["S09"]},
 "planned_stops": [{"from": 0.0, "to": 1.0, "why": "the film opens out of silence"}],
 "styles": {"positive": ["felt piano", "soft low strings"], "negative": []},
 "section_styles": {"S05": ["opens up, wider"]},
 "shape_db": {"act1": -1.0},
 "seeds": [7, 21]}
```

- **Joins** (how a part comes in): `start` (the film's first frame), `act` (an equal-power crossfade centred on the cut),
  `bloom` (the bloom lands exactly on a landing: an event, a time or a word), `lift` (a small arrival nudged onto its
  beat), `arrive` (an end-card cadence).
- **Ends**: `handover` (the next part's join) or `stop` (stops dead just before the next landing: a held breath,
  recorded as a planned stop).
- **Planned stops** always carry a `why`; the gap check treats anything else as a hole.
- **Big moments land together**: a bloom with `"together": true`, or a moment inside a part
  (`"moments": [{"event": "...", "why": "..."}]`), holds its breath (an 80 ms fade into a short silence) and comes back
  exactly on the hit, 3 dB over its own level and settling over 2 s. It re-cuts the music already there; nothing new is
  composed.

### Musical choices that worked

- The score gives way at a film's key line: one held pad under a key word, thinner under a heavy line.
- Stillness is a held note, not silence, so the music never simply drops out (except at a planned stop).
- An act break with no voice for a couple of seconds is a natural place for the score to breathe.
- Typical planned stops: a silent opening second, a held breath before a hero moment, half a second before a reveal, and
  the ending.
- At a big moment, the music and the hit land together.

### Takes

- **Measure every take at its landing**, and keep every take. Eleven Music doesn't reliably deliver a requested dynamic:
  a requested swell rose 1.1 dB, and four retries never lifted it (1,204 credits).
- **Choose or splice from takes on hand before re-composing**: an unused take spliced in measured better than a new part.
  When no take delivers a moment, pick the best measured take and make a small fader move rather than keep paying.
- **Place takes by their measured entry**, never by plan time: takes open with their own silence (a bloom once entered
  0.75 s late).
- Score QA thresholds were tuned on one model's takes; re-check them when the model changes. Measure levels in stereo:
  a mono fold faked a 3.8 dB rise that wasn't there.
- A take is written in the channels Eleven Music sent: stereo, with its record saying so (`channels`). A take about
  twice or half its planned length is a channel misread, and `slate score compose` warns; listen before using it.
- Plan files are immutable once composed, and seeds are fixed, so a record of what was sent stays true.
- Concurrency is limited per plan (two music requests at once on the plan the films used); the queue's lock handles it.

### Assembly

- **Equal-power joins** (sine and cosine gains): squared gains dip about 3 dB between different takes.
- **Close holes in place** by freezing the previous chord with an equal-power hand-over (about 0.8 s); moving parts to
  close a hole cascades into the next seams.
- **The gap check**: no half-second window of the music under −60 dBFS outside the planned stops, predicted at assembly
  and measured again after the mix (the score's own QA misses holes under about 1.5 s and the last second).
- **Act joins breathe, never sag**: a join between acts may dip at most 7 dB, for at most 0.25 s, with no 100 ms step
  over 7 dB; the assembly fails a join past that.
- The end holds and is silent on the film's final frame. The final chord holds, and the score fades into the film's
  silent last second (the brand's balance `end_silent: "always"`, the films' rule and the default). A brand that sets
  `"plan"` leaves the ending to the plan, and the music then plays to the last frame.

### Level and licence

- The mix sets the score under the voice and ducks it under speech. The starting palette uses the owner's approved
  balance: 18.5 LU under before a 6 dB duck, about −21 LU against the voice (he found one score at 17 LU "a teeny bit
  loud", and it went about 1.5 dB lower). That's also the level `sound.balance.levels` holds a score to (at most −19 LU
  inside words). Adjust by ear per brand and per film (`slate mix --under`, `--duck`, or the brand's
  `sound.palette.levels.music`).
- Online commercial use is fine on paid plans; film, TV and radio need an Enterprise plan. The music-licence gate flags a
  broadcast format.

---

## Reference: Spotting: from the picture's beats to sounds

Spotting decides what each moment sounds like. Synchronized effects start from the picture's beats and follow its
movement. The current brief can also call for off-screen sound, ambience, deliberate repetition or silence; record
their intended timing and source instead of treating visible cause as a universal creative rule.

### Where the beats come from

- `timing/visual_events/act<N>.json`: every beat that lands, with its kind, size, time and a note (slate-build). An act
  that's silent says so, with a reason.
- Captures' taps, beat-mapped onto the voice's words.
- A character's gestures, one row per note, on their contact frames.
- The score's own landings, from `sound/score/directions.json`.

Every sound's measured anchor sits on its beat's frame, within one frame: the onset of a strike, the peak of air or a
swell, or the end of a draw. A sound can start before its anchor; its peak or endpoint still serves the exact beat.

`slate sfx spot` builds `sound/sound_cues.json` from those events. It validates every expected act before placing a cue
and refuses malformed or missing event files. Each event keeps one logical cue, with count clicks represented as
individually measured notes. `t` is the picture contact; sustained draws and counts give `start` and `dur` and end on
`t`. Counts also give numeric `from` and `to`, and may set `hold_frames`. Prose is never parsed to guess those values.
Each event's seed stays stable across unrelated insertions. See [effects engine](#reference-the-designed-effects-engine) for execution,
authored beds and preserving approved spans.

**The starting recipe sounds a repeating state once.** A thinking loop or pulse was silent after its first cycle.
A requested recurring sound can repeat under the chosen palette's rules; inspect its rhythm and narration balance.

**Tell the sound exactly what each beat is.** Each kind of interaction has its own family of sounds with several
variations, and that only works when every beat names its kind (and its size). A beat with a loose or wrong kind gets the
wrong sound; an unknown kind is reported, never guessed.

**Land the film's impact at the end of a sentence**, so its sound and its ripple play in the voice's pause.

### Moment patterns that worked

These are warm product-film patterns. Their materials, one-moment structure and silence are contextual choices; the
current palette and authorized listening feedback can choose another sound language.

- **Lists and step sequences** land on small notes rising up the scale, one per item.
- **State chips** flip on wood clacks pitched by meaning: positive bright, neutral middle, negative low; a negative state
  never sounds like an error buzzer.
- **Privacy and locks** sound reassuring: soft wood clacks, never metallic.
- **Stepping back in time** re-counts a number as a descending run of clicks, then rising again for now.
- **Answers streaming on screen** sit over a very low, soft texture; documents writing get a soft paper texture.
- **A sonic logo mirrors the logo build**: each construction line clicks in on a light woodblock, the fill is a soft
  swell, the mark lands on a hollow knock with one small note; the ending reverses it and lands on the same knock.
- **A brand's signature motif can have a sound**: a warm filtered tone born when the motif draws, splitting when it
  splits, resolving when the key value lands, and returning at the end on the same note. It never glides.
- **The widest moment opens the whole mix**: ambience, the motif's tone, a full pad, and the brand line landing per word
  on small notes.
- **One big sound moment per film**: the pad under the build-up stops dead for a held breath, then a sub, a pad bloom and
  a hollow knock land together.
- **In a held moment** the score drops to one pad and only one small sound plays, heard alone; text writing on during it
  stays under the pad or silent.

### Following the picture

- Envelopes, filter sweeps and swells run on the film's own named eases, so a whoosh peaks where the move peaks.
- Pads are space: low, slowly breathing chords that hold the harmony under whole passages and open up at the big
  moments.
- Keep harmony out of the words: under the voice, pads are low-passed (at or below about 1.4 kHz) and tonal beds sit
  about 20 LU under it.

### Silence

Plan silence as deliberately as sound: a silent opening second, a held breath before a hero moment, half a second before
a reveal, and the ending on the last frame. Planned stops are written down (score.md), so the gap check knows they're on
purpose.

### Carrying an approved proof onto the real picture

When adapting a storyboard proof to the real picture is within the authorized work, move it cue by cue:
- move every cue to the beat the picture really has, and remove cues for beats it doesn't have;
- re-voice tonal roles on the sampled instruments;
- trim a file that opens on silence, so its hit lands with the others;
- tie every change to one of the owner's own words about the proof.

Keep a source-bound approved clip unchanged as the baseline. A moved or altered result needs its own applicable
reference or delivered-file approval; permission to adapt does not make its new bytes approved.

### A spotting sheet

For a proof or a film, write a per-shot table (the shot, its time, its voice line, and what the sound does, with its
sources) generated from the script's sound notes and the events, so it can't drift from the film. The builders' score
cues in their NOTES.md (where the score should drop or thin) go into it.

---

## Reference: Sound taste

The owner's taste, as it was stated and as the films proved it. It's the starting point for every brand; a brand's own
palette can change the materials, key and expressive grammar. The current brief and newer listening feedback take
priority. Read `slate history context --topic sound` for scoped evidence, reversals and counterexamples.

### The bar

The approved proof: "intentional", the sound "stuck out but wasn't too loud, and it truly matched exactly what was going
on in the video". Sound effects locked to the picture are a signature the owner loves: every visible beat (a card
landing, a chip flipping, a check, a count) gets a small, quiet sound, within a frame.

### The warm starter's choices

1. **Pads, small soft felt notes, hollow wood clicks and clacks.** No chimes, no bells, nothing metallic or glass, no
   buzzers. (The first proof was "very chime-heavy"; the approved one had none.)
2. **Designed, not stock.** Build it the way a sound designer would, not from a library of generic effects. Generated
   sound effects and music models only fill a gap.
3. **Real instruments for tonal roles.** A synthesized tonal layer (pads, a hum, felt notes made from oscillators) was
   "the problem… an entire rework". Tonal roles play on real sampled instruments; synthesis stays for air, subs and
   textures where it shines.
4. **Never glide a sustained tone's pitch.** A held tone that slides reads as an air-raid siren. Move between notes by
   crossfading held notes, the way a pad changes chord.
5. **No room-tone drone.** A bed under everything read as "a microwave".
6. **One family per kind of interaction**, each its own material, consistent across a brand's films, with designed
   variation between repeats. "The same tone that plays a million times in a row" is bad.
7. **The voice first.** Effects "a little bit too loud" is a fault; so are effects buried so far under a score that they
   stop standing out. The balance hierarchy is in mix.md.
8. **Restraint.** Only what the eye follows makes a sound.
9. **Silence is a tool.** A held breath before a landing (effects fall silent, the music stops dead), opening out of
   silence, and ending on the last frame.
10. **Big moments get an impact with an echo**, on the score's tempo; rare (at most one per act).
11. **A character's sounds** are soft felt notes (its motif), a small wood tick and soft pads.
12. **Reassurance sounds soft**: privacy and locks are soft wood clacks, never metallic; a negative state is a low clack,
    never an error buzzer.

### Where taste is judged

By ear: the owner listens to proofs and approves them. Measurements (levels against the voice, brightness, repeats,
glides, drones) protect an approved sound from drift; they never approve one.

These choices are not universal bans on metallic instruments, synthesis, glides, drones or generated sound. A film
may need any of them. Choose deliberately, retain the version comparison, and configure the brand's palette for the
chosen sound. Automatic timbre detectors can misclassify polyphonic notes or slow attacks; keep that uncertainty
visible and inspect the actual audio before treating the label as an audible defect.

---

## Reference: Verifying the sound

`slate verify` runs the sound gates on the mix (the sixteen core gates and the seven balance gates) and records them in
`qa/gates.json` (and `sound/mix/verify.json`). It exits 0 only when every gate passes, and a delivery needs every one.
`slate verify loudness gap` runs just those.

### The gates

| Gate | Passes when |
|---|---|
| `sound.loudness` | the mix is on target (−14 LUFS within 0.5 LU by default) with the true peak at or under −1 dBTP, by a BS.1770 meter cross-checked against ffmpeg's |
| `sound.stems_sum` | the four delivery stems add up to the mix, sample for sample, within one part in a million |
| `sound.gap` | no half-second window of music under −60 dBFS outside the planned stops |
| `sound.voice_sync` | every take sits exactly on its cue (found again in the dialogue stem by cross-correlation) |
| `sound.cue_sync` | every effect's audible anchor is within one frame of its beat |
| `sound.repeats` | the measured repeats match the palette's interaction rules; the starter rejects consecutive identical files, while a sonic logo or marked bookend is intentional |
| `sound.glides` | no forbidden sustained pitch glide is measured; a palette with both `rules.no_glides` and `rules.no_slide_ups` false permits glides |
| `sound.drone` | no forbidden room-tone bed is measured; `rules.no_drone: false` permits a bed |
| `sound.levels` | each stem sits at its palette level against the voice, within tolerance |
| `sound.reference` | the mix matches the brand's approved sound reference (UNCHECKED when there isn't one), and effects more than 25% brighter than the reference's (spectral centroid, or the share above 2 kHz) wait for a person |
| `sound.clarity` | the voice stays clear: nothing louder than it, no bright noise under the words |
| `sound.music_licence` | the score's licence covers the destination (broadcast formats need an Enterprise music licence) |
| `sound.voice_limiter` | the voice-only limiter touches under 5% of the speech; past that it's shaping the read |
| `sound.key` | every pitched note in the UI and tonal stems is on the brand key's pentatonic (each note's pitch over its first 60 ms); a stem with more than half its notes on one or two pitches waits for a person |
| `sound.timbre` | measured families meet `timbre.centroid_max_hz`, `no_chimes` and `no_metallic`; the warm starter uses 1.5 kHz, true and true, while null removes the centroid ceiling |
| `sound.mix_words` | Whisper on the delivered mix hears the script word for word, after only the normalization a listener can't hear; a word heard over the music where the voice is quiet is set aside, never counted |
| `sound.balance.clarity` | every word at least 12 dB clear of everything else in 1–5 kHz, and the score on its own 19 dB clear; a word under a half-ridden accent is the owner's trade: listed, a person listens under 8 dB, and under 6 dB it fails |
| `sound.balance.never_over` | while the voice speaks, nothing is louder than it: each family, all the effects together and everything else together |
| `sound.balance.texture_air` | the textures' 2–6 kHz sits at least 20 dB under the voice's own |
| `sound.balance.accents` | every accent and impact clears the score by at least 3 dB in one of its own loudest bands, over its loudest 120 ms |
| `sound.balance.levels` | each family sits in its range against the voice: integrated, its hits' median and loudest, and inside words |
| `sound.balance.approved_spans` | every span the owner approved as a clip is kept exactly as approved: the film's mix over the span against the approved clip, family by family, ride by ride and by the score's level |
| `sound.planned_stops` | the music's quiet stretches are all planned (each stop widened by the music's own fade, the score's own rests counted), and the film opens out of silence or ends in it only when its plan says so |

The seven balance gates measure word by word against the voice (phrase by phrase before word timings exist), from the
brand's sound palette (`sound.palette.balance`, mix.md). `slate sound balance` runs them on their own, and
`--words` prints every word's clarity. A film whose effects arrive as one stem has the effect families' rules
UNCHECKED until the effects engine writes a stem per family; a score-and-voice film is measured in full.

The effective palette starts with the warm preset, takes the brand's settings and then the film's `sound.palette`
overrides. Explicit material and banned-timbre lists replace the starter lists. A configured timbre allowance retains
the detector flags in the report; it does not erase evidence, approve a source-bound clip or prove the detector correct.
Follow the latest authorized sound direction and preserve its earlier proof and feedback for comparison.

### How sync is measured

- Each cue is rendered alone and its **anchor** measured the way the ear hears it: a strike's first sample within 12 dB
  of its peak; paper's first audible sound; for air and swells, their loudest 20 or 50 ms; for a lift or a drawn line,
  where it ends.
- A cue passes when its anchor is within one frame of its beat. On the first films the worst of hundreds of anchors was
  about 24 ms.
- A pencil stroke's tip tick once led its letter by up to 200 ms, and a broad swell's peak sat almost a second off: that's
  why designed sounds get designed envelopes, placed by their perceptual onset.
- Documented exceptions (a character's anticipation, designed to land a few frames before its word) are listed with a
  reason, and still locked to the picture.

### Statuses

Only PASS counts. UNCHECKED means the gate couldn't run and says what to do (mix first, approve a sound reference);
replayed audio in tests is UNCHECKED, never passed. `slate qa` includes the sound gates in the film's full run (slate-qa).

### By ear, too

The gates protect an approved sound; they don't approve one. Proofs go to the owner in the packet, as a preview with the
picture and a labelled spectrogram if it helps, and the owner decides.
