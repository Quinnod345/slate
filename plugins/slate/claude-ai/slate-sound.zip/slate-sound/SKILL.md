---
name: "slate-sound"
description: "Design, score, mix and verify the sound of a Slate film. Covers the approved starting palette (pads, small soft felt notes, hollow wood clicks and clacks, no chimes) and each brand's own palette, spotting sound from the picture's events with one deliberate sound per kind of interaction, composed scores on Eleven Music planned per act and assembled by measurement, the delivery mix and its balance against the voice, and the sound gates. The designed effects engine waits for the owner's approval of proof 3. Use when a Slate film needs its score planned, composed or assembled, its mix built or rebalanced, its sound verified, a brand's sound palette defined, or a question answered about how a film should sound."
---

> Knowledge-only edition of Slate's `slate-sound` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-sound

Sound is designed, not stock, and it's locked to the picture: every beat the eye follows lands within a frame of its
sound, and the voice is always understood. The bar is the approved proof: "intentional", noticeable without being too
loud, and matching exactly what happens on screen.

This is stage 9 of the production. Its inputs are the voice's placed takes (`timing/vo_cues.json`), the picture's beats
(`timing/visual_events/act<N>.json`, from slate-build) and the brand's sound palette.

## 1. Taste and the starting palette

- **Pads, small soft felt notes, and hollow wood** (woodblock, temple block, clave, knock, rim), with air for moves and
  a sub for the one big landing. **No chimes, bells, metal, glass or buzzers.**
- **Designed, not stock.** Tonal roles play on real sampled instruments; a synthesized tonal layer sounded cheap.
- **Never glide a sustained tone's pitch** (it reads as a siren); change notes by crossfading held notes.
- **No room-tone drone** under the effects.
- **One deliberate sound per kind of interaction**, the same across a brand's films, with natural variation between
  repeats: never the same hit twice in a row.
- **Restraint and silence**: only what the eye follows makes a sound; a held breath before a landing is silence on
  purpose.

That palette (proof 2's, the approved proof) is the **starting point**. Each brand gets its own palette during
onboarding: its key and tempo, its materials, its banned timbres, its motif, and its levels measured against its
voice (slate-brand). See [taste](#reference-sound-taste) and [palette](#reference-sound-palettes).

## 2. Balance: the voice first

A mix is a hierarchy, not one level for everything:
- the narration is always fully intelligible;
- small tactile accents (wood clicks, knocks, felt notes) may stick out a little;
- noise textures (whooshes, swishes, air, reverse bursts, write-on scratch) and tonal sweeps (risers, pad swells) sit
  well under the voice and duck harder while it speaks;
- bright noise (roughly 2 to 6 kHz, where consonants live) stays out from under words;
- no effect is ever louder than the voice.

The approved proof put its effects about 11 LU and its UI clicks about 17 LU under the voice, clearly audible. A later
mix buried them 25 to 28 LU under, and they stopped standing out: that was a failure too. See [mix](#reference-the-mix).

## 3. Spotting: tell the sound what each beat is

The picture's events name each beat's **kind** (tap, type, land, snap, count, draw, data, page, stamp, whoosh, swell,
character, impact) and **size**. Each kind has its own family of sounds; bursts of beats become one gesture; an act has
at most one impact; a big impact gets an echo on the score's tempo; every sound's attack sits on its beat's frame. See
[spotting](#reference-spotting-from-the-pictures-beats-to-sounds) and [families](#reference-families-one-sound-per-kind-of-interaction).

## 4. The effects engine waits for proof 3

The designed effects engine (spotting beats to cues and rendering them to stems) is built only after the owner approves
proof 3, the perfected proof of the approved design: `slate sfx` refuses until that approval is recorded, and
`slate sfx status` shows the gate. Until then a film's sound is its score, its voice and its brand's onboarding sound
reference, through the mix; effect stems made another way (by hand, in a DAW) can be supplied as stems. See
[effects engine](#reference-the-effects-engine-waits-for-proof-3).

## 5. The score

A composed score is part of most films: Eleven Music on its best model, composed per act and assembled by measurement,
never playing the effects' own materials.

```
slate score plan          # one composition plan per act: 3 s pre-rolls, parts under 90 s, sections of 3 s or more
slate score compose       # composes the missing takes (spends; estimated and budget-checked first)
slate score assemble      # measured placement, equal-power joins, freeze repairs, the gap check
slate score qa            # silence and noise in the takes and the score
```

`sound/score/directions.json` (hand-edited) says where the music does something special: stops, blooms on a landing,
splits at a story turn, styles. The playbook, and why each rule exists: [score](#reference-the-score-the-eleven-music-playbook).

## 6. The mix

```
slate mix                 # voice, score and any effect stems, mixed to the film's targets
slate mix --calibrate     # trim each effect stem to its palette level against the voice first
slate verify              # the sound gates
```

The mix places the voice from its cue sheet, sets the score under the voice with ducking, sets effect stems at the
palette's levels, and takes the whole to −14 LUFS with the true peak at or under −1 dBTP, in 48 kHz, 24-bit, exactly as
long as the picture. Four delivery stems (dialogue, effects, ambience, music) sum to the mix sample for sample. Manual
polish in a DAW is allowed, but the engine's timing stays the reference. See [mix](#reference-the-mix).

## 7. Verification

`slate verify` runs twelve gates: loudness, stems summing, the music gap, voice sync, cue sync, repeats, glides, drone,
levels against the palette, the brand's sound reference, clarity under the voice, and the music licence for the
destination. Only PASS counts; a gate that can't run (no approved sound reference, say) is UNCHECKED. See
[verification](#reference-verifying-the-sound).

## 8. Perfect, don't replace

When the owner approves a sound and adds notes, apply the notes to that exact sound, and keep its levels measurable
against the approved version. The films' sound once went off the rails exactly here: small notes (a cheap-sounding
tonal layer, glides that read as a siren, more variation wanted) were answered with a new vocabulary and a new layer,
and the effects ended up buried. Research only fixes a named flaw.

## References

- [taste](#reference-sound-taste): the owner's sound taste, rule by rule.
- [palette](#reference-sound-palettes): the starting palette, a brand's palette, levels, instruments.
- [families](#reference-families-one-sound-per-kind-of-interaction): one family per kind of interaction; impacts and echoes.
- [spotting](#reference-spotting-from-the-pictures-beats-to-sounds): from beats to sounds, moment by moment.
- [score](#reference-the-score-the-eleven-music-playbook): the Eleven Music playbook and directions.json.
- [mix](#reference-the-mix): the balance hierarchy, the mix, stems and their manifest.
- [verification](#reference-verifying-the-sound): the twelve sound gates and how sync is measured.
- [effects-engine](#reference-the-effects-engine-waits-for-proof-3): the gated effects engine, and what a film uses until it's open.

---

## Reference: The effects engine (waits for proof 3)

The designed effects engine turns the picture's beats into sounds: it spots every beat to a cue (family, variation,
level, anchor rule) and renders the cues to stems (UI, effects, tonal, reverb) that the mix reads. It's the part of
Slate's sound that isn't open yet, on purpose.

### Why it waits

The approved sound design (proof 2) was being perfected with the owner's own notes when Slate was built: sampled tonal
instruments, no glides or slide-ups, no drone, one sound per kind of interaction with natural variation, proof 2's
levels. That perfected proof (proof 3) has to be approved by the owner, and the tools behind it re-inventoried, before
its engine becomes Slate's. Porting it earlier would port a design still being changed.

### What that means today

- `slate sfx` (and `slate sfx spot`, `slate sfx render`) refuses, saying what's needed. `slate sfx status` shows the
  gate: whether a person's approval of proof 3 is recorded with its SHA-256.
- A film's sound today is its **score**, its **voice** and the brand's **onboarding sound reference**, through the mix.
  That's exactly what the first reels were planned to use.
- **Effect stems made another way** can still be used: designed by hand in a DAW (Logic, GarageBand) from the film's
  events and supplied in `sound/stems/` with a `stems.json` manifest (mix.md). The mix and every sound gate treat them
  like the engine's.
- The events are still exported by every act (slate-build), so the moment the engine opens, every film already has what
  it needs.

### When proof 3 is approved

1. The owner records the approval of the exact proof file (its SHA-256 is checked on every run).
2. The engine's port starts: re-inventory the perfected proof's tools, then spotting and rendering, with the starting
   palette and each brand's palette as data.
3. `sound/sound_cues.json` then records every cue with its beat, anchor rule and render, and the stems land in
   `sound/stems/` with their manifest.

### Never

- Never fake the engine with a synthesized stand-in for the tonal roles: tonal roles play on real sampled instruments or
  not at all.
- Never pull generic library effects in to fill the gap: sound is designed, not stock. A generated sound effect only
  fills a specific gap, and says so.

---

## Reference: Families: one sound per kind of interaction

### One family per kind, each its own material

Touch is wood, paper is paper, marks are graphite and ink, moves are air, chapter swells are tuned air or a pad, a
character has its own voice (its motif), and an act's one big landing has one deep, hollow sound. Each kind of beat gets
one family, consistent across every film of the brand, so the viewer learns the language: the same kind of thing always
sounds like the same kind of thing.

- **Be strong-willed about what each beat is.** The builders tag every beat with its kind and size (slate-build); a beat
  with the wrong kind gets the wrong sound.
- **No sound is shared between kinds.** A tap and a snap never borrow each other's sound.
- **Unknown kinds are reported, never silently dropped.**

### Variation that sounds played, not random

The same sample repeated reads as cheap: one film's first mix put 483 cues on 48 distinct sounds, with runs of up to
eleven identical hits. The fix was designed variation:
- variations within a family differ the way real playing does: pitch within the key's pentatonic, the material's colour,
  the strike, the timing of a second contact;
- the same variation never plays twice in a row (a shuffle that never repeats the last two);
- **bursts are gestures**: a list writing on is one writing gesture, a run of dots is one run walking up the scale, not
  twelve identical clicks;
- density stays readable (no more than about eight transients in half a second).

### Sizes

`s` a small detail, `m` normal, `l` a moment. Size scales the sound's weight, not just its volume: a large land is a
deeper knock, not a louder small one.

### Impacts

- At most **one impact per act**, and a film never reuses an impact file.
- A big impact gets a **tempo echo** on the score's beat (a dotted eighth or a quarter note), each repeat about 6.5 dB
  softer and darker, panned to the other side.
- Land it at the end of a sentence, so it plays in the voice's pause, and let music and hit land together.
- Before it, a held breath: the effects fall silent and the music stops dead.

### A character

A brand character's sounds are its motif (small felt notes, one per part of the mark, or a short phrase), a small wood
tick for pointing, and soft pads. One event per note, each on its own contact frame, and when two of its sounds land on
the same frame only one plays. The score yields to a pad under the character's motif, so its notes carry the melody.

---

## Reference: The mix

`slate mix` builds the delivery mix: the voice from its cue sheet, the score under the voice with ducking, any effect
stems at their palette levels, one fixed gain to the film's loudness target, and four delivery stems that sum to it.

### The balance hierarchy

Balance a film's sound as a deliberate hierarchy, not one level for everything:
1. **The narration is always fully intelligible.** Nothing covers a word.
2. **Small tactile accents** (wood clicks, knocks, felt notes) can stick out a little: that's what makes sound locked to
   picture feel intentional.
3. **Noise textures** (whooshes, swishes, air, reverse bursts, write-on scratch) and **tonal sweeps** (risers, pad swells,
   builds) sit well under the voice and duck harder while it speaks.
4. **Bright noise stays out from under words**: roughly 2 to 6 kHz is where consonants live.
5. **No effect is ever louder than the voice**, at any moment.
6. **The tonal bed** sits about 20 LU under the voice, and pads under speech are low-passed at or below about 1.4 kHz, so
   harmony stays out of the words.

The owner judges by ear; the gates check every level by measurement (the levels and clarity gates).

### What the mix does

```
slate mix                       # voice, score, effect stems
slate mix --no-score            # voice and effects only
slate mix --calibrate           # trim each effect stem to its palette level against the voice, and report the trims
slate mix --under 17 --duck 5   # the score's level under the voice and its ducking, for this mix
```

- **The voice** is placed from `timing/vo_cues.json`, each take levelled by its voiced loudness, protected by a
  zero-latency limiter on the voice alone (a limiter with latency once moved the voice 240 samples late).
- **The score** sits under the voice and is ducked under every word by a follower on the voice.
- **Effect stems** come from `sound/stems/` at the palette's levels against the voice; wood clicks don't duck.
- **One linear gain** takes the whole to the target (−14 LUFS integrated, true peak at or under −1 dBTP, 4× oversampled),
  any limiting as one linked curve on every stem, never a one-pass loudness normalizer (its stems couldn't sum).
- **The output**: `sound/mix/final_mix.wav` at 48 kHz, 24-bit, exactly as long as the picture (never trimmed to the
  shortest stream), and four delivery stems (dialogue, effects, ambience, music) in `sound/mix/stems/` that sum to it
  within one part in a million.

### Effect stems and their manifest

Stems made outside the effects engine (in a DAW, or by hand) go in `sound/stems/`, with `sound/stems/stems.json` naming
each role's file and whether it ducks:

```json
{"stems": {"ui": {"file": "ui.wav", "duck": false}, "fx": {"file": "fx.wav", "duck": true}, "amb": "amb.wav"}}
```

Roles: `ui`, `fx`, `verb` (they sum to the effects stem), `tonal`, `tverb` (music), `amb` (ambience). Without a
manifest, the mix takes whichever role files are present. Manual polish in a DAW is fine; the engine's timing stays the
reference.

### Levels and taste

- The approved proof put the effects about 11 LU and the UI clicks about 17 LU under the voice, clearly audible. Those
  are the starting palette's levels; a brand's own come from its sound reference.
- Calibrate a new design to the last approved level before comparing, so an A/B hears the design, not the volume.
- Don't bury the effects: a mix that put them 25 to 28 LU under the voice lost the thing the owner loved.

### After the mix

`slate verify` runs the sound gates (verification.md). Loudness targets differ by destination (platforms normalize
differently; −14 LUFS is a common web target, not a documented rule for every platform); the format sets the film's
target, and delivery can derive others.

---

## Reference: Sound palettes

A palette says what a brand's films sound like: which material plays each kind of beat, where each sits against the
voice, which instruments carry the tonal roles, what the score must never play, and what's banned. Slate ships one
starting palette (the approved proof's), and each brand's pack overrides it key by key (`sound.palette` in brand.json).

### The starting palette

| Kind of beat | Family | Stem |
|---|---|---|
| tap (a row, check, chip or button) | wood block | UI |
| type (text writing on) | soft air | effects |
| land (a card, sheet or panel landing) | wood knock | UI |
| snap (a state flips) | clave | UI |
| count (a numeral counting) | tuned wood clicks | UI |
| draw (a line or chart drawing) | air on the draw's ease | effects |
| data (a value, bar or marker lands) | a small felt note | tonal |
| page (a sheet slides, deals or turns) | swish | effects |
| stamp (a group completes, a seal sets) | temple block with a felt note | UI |
| whoosh (a view carries into the next) | air | effects |
| swell (the picture fills or opens) | a sampled string pad | tonal |
| character (the brand's mark gestures) | small felt notes, the motif | tonal |
| impact (an act's one big landing) | a sub with a hollow temple knock | effects |

**Levels against the voice** (integrated, measured on the approved proof's stems): UI clicks about 17 LU under, effects
about 11 LU under, within about 2 LU. The voice is levelled by the loudness of its voiced part; every other cue by its
peak.

**Ducking under speech:** tonal and ambience about 6 dB, effects about 3 dB, reverb about 4 dB; the UI clicks stay crisp.

**Rules the palette carries:** no glides, no slide-ups, no drone, one sound per kind, no sound shared between kinds, no
identical repeats, every sound within a frame of its beat, tonal roles on sampled instruments.

**Materials** the effects are made of (wood block, temple block, clave, knock, rim, felt marimba and the like): the
composed score never plays them.

**Pads are space**: low, slowly breathing chords hold the harmony under whole passages and open up at the big moments.
Under the voice they stay low-passed, so the harmony stays out of the words.

**Designed, not generated**: generated sound-effect and music models only ever fill a specific gap, and say so; the
film's effects are designed from its palette.

**Banned timbres:** bells, chimes, glockenspiel, celesta, crotales, tubular bells, vibraphone, music box, metallic hits,
glass, buzzers.

### A brand's palette

Onboarding (slate-brand) makes it, from the brand's own world:
- its **key and tempo range** (every pitched effect sits on the key's pentatonic, so nothing clashes with the score, and
  nothing sits on a leading tone);
- its **materials** and **banned timbres**;
- its **motif** (a few notes that belong to the brand or its character) and the instrument that plays it;
- its **instrumentation** for the score;
- its **reference levels**, measured from its approved 10 to 20 second sound reference against its voice.

The owner's palette is where every brand starts, and a brand's own world decides where it goes.

### Instruments

Tonal roles (small notes, pads) play on Apple's sampled instruments, found in place on the machine (installed with
GarageBand's sound library and Logic) and never redistributed. If they're missing, `slate doctor` fails and says what to
download; there's no synthesized stand-in for a tonal role. Plate ambience from a generated shot can serve as a bed
(it came back as usable wind and air on the first films), high-passed and well under the voice.

### Changing a palette

A palette approved with a brand's sound reference changes only on purpose, with the owner's approval, and is checked
against the reference by measurement (levels against the voice, brightness, sync). Notes on it are perfecting notes.

---

## Reference: The score: the Eleven Music playbook

A composed score is part of most films: Eleven Music on its best model (named explicitly in every request, because the
API's default is an older model), composed per act, assembled by measurement, and gap-checked. Every rule below is a
lesson the first films paid for.

Why a composed score at all: synthesized tonal layers sounded cheap. Music is composed (a score per act), tonal effects
play on real sampled instruments, and synthesis is kept for air, ink, beads and subs, where it shines.

### The steps

```
slate score plan                  # sound/score/plan.json and one plan per part, cut to the shots
slate score compose --dry-run     # what it will cost, nothing spent
slate score compose               # composes the missing takes; takes are kept, locked takes never redone
slate score assemble              # sound/score/score.wav and score.json
slate score qa                    # silence and noise spans in every take and the score
```

Compose runs through the ledger (estimated and budget-checked before the first call) and replays offline in tests.

### Planning (why each rule exists)

- **One composition per act**, not one for the film: a single six-minute composition came back with 21 seconds of
  silence over the film's biggest moment and 18 seconds of noise near the end.
- **Split any part longer than about 90 seconds** at a story turn: longer plans ran out of material and went silent early.
- **Every section at least 3 seconds.**
- **A 3-second pre-roll**, cut at assembly, and every part runs at least 3 seconds past its hand-over: Eleven Music fades
  in and out at a take's edges regardless of the plan.
- **An exact moment must be a part boundary on the word's time**, not a section inside a take.
- **The score never plays the effects' materials** (they go in its negative styles), so the two never blur together.
- **Leave room for the narrator** in the style, and let the score yield to a pad under a character's motif.

### Directions: sound/score/directions.json

The one hand-edited file in the score's folder. It says where the music does something special:

```json
{"parts": {"act3": {"end": "stop", "stop_before_s": 0.5},
           "act4": {"join": "bloom", "landing_event": "key_value_lands"}},
 "split": {"act2": ["S09"]},
 "planned_stops": [{"from": 0.0, "to": 1.0, "why": "the film opens out of silence"}],
 "styles": {"positive": ["felt piano", "soft low strings"], "negative": []},
 "section_styles": {"S05": ["opens up, wider"]},
 "shape_db": {"act1": -1.0},
 "seeds": [7, 21]}
```

- **Joins** (how a part comes in): `start` (the film's first frame), `act` (an equal-power crossfade centred on the cut),
  `bloom` (the bloom lands exactly on a landing: an event, a time or a word), `lift` (a small arrival nudged onto its
  beat), `arrive` (an end-card cadence).
- **Ends**: `handover` (the next part's join) or `stop` (stops dead just before the next landing: a held breath,
  recorded as a planned stop).
- **Planned stops** always carry a `why`; the gap check treats anything else as a hole.

### Musical choices that worked

- The score gives way at a film's key line: one held pad under a key word, thinner under a heavy line.
- Stillness is a held note, not silence, so the music never simply drops out (except at a planned stop).
- An act break with no voice for a couple of seconds is a natural place for the score to breathe.
- Typical planned stops: a silent opening second, a held breath before a hero moment, half a second before a reveal, and
  the ending.
- At a big moment, the music and the hit land together.

### Takes

- **Measure every take at its landing**, and keep every take. Eleven Music doesn't reliably deliver a requested dynamic:
  a requested swell rose 1.1 dB, and four retries never lifted it (1,204 credits).
- **Choose or splice from takes on hand before re-composing**: an unused take spliced in measured better than a new part.
  When no take delivers a moment, pick the best measured take and make a small fader move rather than keep paying.
- **Place takes by their measured entry**, never by plan time: takes open with their own silence (a bloom once entered
  0.75 s late).
- Score QA thresholds were tuned on one model's takes; re-check them when the model changes. Measure levels in stereo:
  a mono fold faked a 3.8 dB rise that wasn't there.
- Plan files are immutable once composed, and seeds are fixed, so a record of what was sent stays true.
- Concurrency is limited per plan (two music requests at once on the plan the films used); the queue's lock handles it.

### Assembly

- **Equal-power joins** (sine and cosine gains): squared gains dip about 3 dB between different takes.
- **Close holes in place** by freezing the previous chord with an equal-power hand-over (about 0.8 s); moving parts to
  close a hole cascades into the next seams.
- **The gap check**: no half-second window of the music under −60 dBFS outside the planned stops, predicted at assembly
  and measured again after the mix (the score's own QA misses holes under about 1.5 s and the last second).
- The end holds and is silent on the film's final frame.

### Level and licence

- The mix sets the score under the voice and ducks it under speech (the starting palette: about 15 LU under, ducked about
  4 dB; the owner found one score "a teeny bit loud" and it went about 1.5 dB lower). Adjust by ear per brand and per
  film (`slate mix --under`, `--duck`).
- Online commercial use is fine on paid plans; film, TV and radio need an Enterprise plan. The music-licence gate flags a
  broadcast format.

---

## Reference: Spotting: from the picture's beats to sounds

Spotting decides what each moment of the film sounds like. It starts from the picture's own beats, so every sound has a
visible cause, and it follows the picture's own eases, so sound moves the way the picture moves.

### Where the beats come from

- `timing/visual_events/act<N>.json`: every beat that lands, with its kind, size, time and a note (slate-build). An act
  that's silent says so, with a reason.
- Captures' taps, beat-mapped onto the voice's words.
- A character's gestures, one row per note, on their contact frames.
- The score's own landings, from `sound/score/directions.json`.

Every sound's attack sits on its beat's frame (for air and swells, the peak), within one frame. Sound never comes before
the picture.

**Tell the sound exactly what each beat is.** Each kind of interaction has its own family of sounds with several
variations, and that only works when every beat names its kind (and its size). A beat with a loose or wrong kind gets the
wrong sound; an unknown kind is reported, never guessed.

**Land the film's impact at the end of a sentence**, so its sound and its ripple play in the voice's pause.

### Moment patterns that worked

- **Lists and step sequences** land on small notes rising up the scale, one per item.
- **State chips** flip on wood clacks pitched by meaning: positive bright, neutral middle, negative low; a negative state
  never sounds like an error buzzer.
- **Privacy and locks** sound reassuring: soft wood clacks, never metallic.
- **Stepping back in time** re-counts a number as a descending run of clicks, then rising again for now.
- **Answers streaming on screen** sit over a very low, soft texture; documents writing get a soft paper texture.
- **A sonic logo mirrors the logo build**: each construction line clicks in on a light woodblock, the fill is a soft
  swell, the mark lands on a hollow knock with one small note; the ending reverses it and lands on the same knock.
- **A brand's signature motif can have a sound**: a warm filtered tone born when the motif draws, splitting when it
  splits, resolving when the key value lands, and returning at the end on the same note. It never glides.
- **The widest moment opens the whole mix**: ambience, the motif's tone, a full pad, and the brand line landing per word
  on small notes.
- **One big sound moment per film**: the pad under the build-up stops dead for a held breath, then a sub, a pad bloom and
  a hollow knock land together.
- **In a held moment** the score drops to one pad and only one small sound plays, heard alone; text writing on during it
  stays under the pad or silent.

### Following the picture

- Envelopes, filter sweeps and swells run on the film's own named eases, so a whoosh peaks where the move peaks.
- Pads are space: low, slowly breathing chords that hold the harmony under whole passages and open up at the big
  moments.
- Keep harmony out of the words: under the voice, pads are low-passed (at or below about 1.4 kHz) and tonal beds sit
  about 20 LU under it.

### Silence

Plan silence as deliberately as sound: a silent opening second, a held breath before a hero moment, half a second before
a reveal, and the ending on the last frame. Planned stops are written down (score.md), so the gap check knows they're on
purpose.

### A spotting sheet

For a proof or a film, write a per-shot table (the shot, its time, its voice line, and what the sound does, with its
sources) generated from the script's sound notes and the events, so it can't drift from the film. The builders' score
cues in their NOTES.md (where the score should drop or thin) go into it.

---

## Reference: Sound taste

The owner's taste, as it was stated and as the films proved it. It's the starting point for every brand; a brand's own
palette can change the materials and the key, never the principles.

### The bar

The approved proof: "intentional", the sound "stuck out but wasn't too loud, and it truly matched exactly what was going
on in the video". Sound effects locked to the picture are a signature the owner loves: every visible beat (a card
landing, a chip flipping, a check, a count) gets a small, quiet sound, within a frame.

### The rules

1. **Pads, small soft felt notes, hollow wood clicks and clacks.** No chimes, no bells, nothing metallic or glass, no
   buzzers. (The first proof was "very chime-heavy"; the approved one had none.)
2. **Designed, not stock.** Build it the way a sound designer would, not from a library of generic effects. Generated
   sound effects and music models only fill a gap.
3. **Real instruments for tonal roles.** A synthesized tonal layer (pads, a hum, felt notes made from oscillators) was
   "the problem… an entire rework". Tonal roles play on real sampled instruments; synthesis stays for air, subs and
   textures where it shines.
4. **Never glide a sustained tone's pitch.** A held tone that slides reads as an air-raid siren. Move between notes by
   crossfading held notes, the way a pad changes chord.
5. **No room-tone drone.** A bed under everything read as "a microwave".
6. **One family per kind of interaction**, each its own material, consistent across a brand's films, with designed
   variation between repeats. "The same tone that plays a million times in a row" is bad.
7. **The voice first.** Effects "a little bit too loud" is a fault; so are effects buried so far under a score that they
   stop standing out. The balance hierarchy is in mix.md.
8. **Restraint.** Only what the eye follows makes a sound.
9. **Silence is a tool.** A held breath before a landing (effects fall silent, the music stops dead), opening out of
   silence, and ending on the last frame.
10. **Big moments get an impact with an echo**, on the score's tempo; rare (at most one per act).
11. **A character's sounds** are soft felt notes (its motif), a small wood tick and soft pads.
12. **Reassurance sounds soft**: privacy and locks are soft wood clacks, never metallic; a negative state is a low clack,
    never an error buzzer.

### Where taste is judged

By ear: the owner listens to proofs and approves them. Measurements (levels against the voice, brightness, repeats,
glides, drones) protect an approved sound from drift; they never approve one.

---

## Reference: Verifying the sound

`slate verify` runs the sound gates on the mix and records them in `qa/gates.json` (and `sound/mix/verify.json`). It
exits 0 only when every gate passes. `slate verify loudness gap` runs just those.

### The gates

| Gate | Passes when |
|---|---|
| `sound.loudness` | the mix is on target (−14 LUFS within 0.5 LU by default) with the true peak at or under −1 dBTP, by a BS.1770 meter cross-checked against ffmpeg's |
| `sound.stems_sum` | the four delivery stems add up to the mix, sample for sample, within one part in a million |
| `sound.gap` | no half-second window of music under −60 dBFS outside the planned stops |
| `sound.voice_sync` | every take sits exactly on its cue (found again in the dialogue stem by cross-correlation) |
| `sound.cue_sync` | every effect's audible anchor is within one frame of its beat |
| `sound.repeats` | no identical sound plays twice in a row |
| `sound.glides` | no sustained tone slides in pitch |
| `sound.drone` | no room-tone bed under the effects |
| `sound.levels` | each stem sits at its palette level against the voice, within tolerance |
| `sound.reference` | the mix matches the brand's approved sound reference (UNCHECKED when there isn't one) |
| `sound.clarity` | the voice stays clear: nothing louder than it, no bright noise under the words |
| `sound.music_licence` | the score's licence covers the destination (broadcast formats need an Enterprise music licence) |

### How sync is measured

- Each cue is rendered alone and its **anchor** measured the way the ear hears it: a strike's first sample within 12 dB
  of its peak; paper's first audible sound; for air and swells, their loudest 20 or 50 ms; for a lift or a drawn line,
  where it ends.
- A cue passes when its anchor is within one frame of its beat. On the first films the worst of hundreds of anchors was
  about 24 ms.
- A pencil stroke's tip tick once led its letter by up to 200 ms, and a broad swell's peak sat almost a second off: that's
  why designed sounds get designed envelopes, placed by their perceptual onset.
- Documented exceptions (a character's anticipation, designed to land a few frames before its word) are listed with a
  reason, and still locked to the picture.

### Statuses

Only PASS counts. UNCHECKED means the gate couldn't run and says what to do (mix first, approve a sound reference);
replayed audio in tests is UNCHECKED, never passed. `slate qa` includes the sound gates in the film's full run (slate-qa).

### By ear, too

The gates protect an approved sound; they don't approve one. Proofs go to the owner in the packet, as a preview with the
picture and a labelled spectrogram if it helps, and the owner decides.
