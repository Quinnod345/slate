---
name: "slate-generate"
description: "Decide whether a Slate film should use generated footage or images, and make it well when it should. Covers the policy (rarely by default, as much as the requester wants, code first for anything designed), real people, real scenes and stock-style shots where code can't go, estimates, takes and judging them (at least two, and ugly or AI-looking takes never ship), the best models, grounding in the brand, conforming plates, mattes, and spend on the Higgsfield Cloud API. Use when a Slate film might need a generated shot, plate, bridge or still, when takes need judging, or when someone asks what generation will cost."
---

> Knowledge-only edition of Slate's `slate-generate` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-generate

Generated shots can lift a film or cheapen it. On the first films, generated pixels where code or real footage belonged
read as AI and were rejected; generated atmosphere, used carefully, earned its place. So Slate generates rarely by
default, only what code can't make, judges every take, and never ships an ugly one.

This is stage 8 of the production. Every generation runs on the Higgsfield **Cloud API** (the one funded lane), through
Slate's ledger, estimated first.

## 1. When to generate

- **The requester decides how much**: each film has a generation setting, `none`, `rarely` (the default) or
  `where-it-helps`.
- **Code first for anything designed**: UI, type, data, charts, logos and brand graphics are drawn by code, always. A
  generated plate never carries UI, text, charts or logos.
- **Generation is for what code can't make**: real-looking people, a real place or scene, a stock-style shot. On
  `where-it-helps` it can also be used where it genuinely adds something, or as a matte (its shape only), each with a
  written reason.
- **Drafts use no plates.** Autonomous films may generate under the same rules, but every generation waits for the
  owner's yes.
- **Generated people on screen need the requester's sign-off**, and a generated shot never implies a claim or a
  testimonial.

See [policy](#reference-the-generation-policy).

## 2. Ask for it in the script

A shot that may be generated carries a `generate` block in `script/script.json`:

```json
"generate": {"reason": "real-scene", "why": "a real coastline at dawn, which code can't draw",
             "prompt": "…", "duration": 5, "image": "refs/start.png", "takes": 2}
```

`reason` is one of `real-people`, `real-scene`, `stock`, `adds-something`, `bridge-matte`; `contains` must list nothing
designed. File inputs are film-relative paths, `take:<shot>` (another shot's approved take) or `brand:<path>` (a file in
the brand pack, sent only when the brand allows uploads).

## 3. Plan, estimate, generate, judge, pick, conform

```
slate plates plan                          # every generate block: allowed or not and why, the model, takes, the estimate
slate gen estimate --shot S05              # the free estimate for this shot's takes
slate gen run --shot S05                   # at least two takes, each submitted once, ledger row first
slate gen judge --shot S05                 # a contact sheet and numbers for each take, and a REVIEW gate
slate gen pick --shot S05 --take t2 --by <the person who chose>
slate plates conform --shot S05            # the approved take, at the film's frame rate and size
```

- A rerun polls takes still running; it never pays twice. `--detach` runs a batch as a queued job.
- **Only a person picks.** The pick records the take's SHA-256 and locks it; the conform refuses a take that no longer
  matches the pick.
- Autonomous films ask first: `slate gen request-approval --shot S05`, then run with the approval id once the owner's yes
  is recorded.

## 4. Judge every take

At least two takes per shot, judged side by side at full size and in motion, against the brand's references. **Ugly or
AI-looking takes never ship, however much they cost.** Reject takes that drift off-look (painterly, off-hue, the wrong
sky), invent their own elements (a guide line drawn beside the film's line), or break the brief (an extra element).
Inspect interpolation on every conformed plate. See [judging takes](#reference-judging-takes).

## 5. Make it good

- **The best models by default** (from `registry.json`, pinned per film at first use), overridable per film or shot.
  See [models](#reference-models).
- **Ground every generation in the brand**: its references wired in, its tokens and rules spelled into the prompt. See
  [grounding](#reference-grounding-every-generation-in-the-brand).
- **Full visual context and long, explicit prompts** when the brand allows uploads: start and end frames, reference
  frames, the look. See [prompting](#reference-prompting-generators-well).
- **Continuity across plates**: generate later plates from the film's own frames or an earlier selected plate. See
  [plates](#reference-plates-generated-atmosphere-in-a-code-built-film).

## 6. Mattes: a generation's shape, never its pixels

Where the film's code-built world meets real footage, a generated transition can help, but its pixels on screen read
as AI. Use it as a **matte**: the generation's shape reveals real frames inside and the film's own ground outside, and
the code draws its lines and words on top. `slate plates matte --shot S05 --base <image> --real <shot>` builds it. See
[mattes](#reference-mattes-using-a-generations-shape-not-its-pixels).

## 7. Spend

Every call is estimated first (the estimate's `usd` is the price; `discount.usd` is only the saving), checked against
the film's budget and the month's cap, recorded in the ledger with its request id before waiting, and sent with an
Idempotency-Key, so a lost answer is resent with the same key and body and charged once. Video plates are 720p unless
the owner chooses 1080p (2.46x the price). Slate never buys credits. Higgsfield's own skills (the fast lane)
bill app credits, a separate pool that isn't funded by default. See [spend](#reference-spend-on-generation).

## References

- [policy](#reference-the-generation-policy): the generation setting, reasons, what's never generated, autonomous approvals.
- [prompting](#reference-prompting-generators-well): full references, explicit prompts, templates per brand.
- [grounding](#reference-grounding-every-generation-in-the-brand): wiring the brand kit into every generation.
- [models](#reference-models): choosing and pinning models, routing, what the API can't do.
- [judging-takes](#reference-judging-takes): two takes or more, the review sheet, what gets rejected.
- [plates](#reference-plates-generated-atmosphere-in-a-code-built-film): atmosphere plates, continuity, conforming, type over footage.
- [mattes](#reference-mattes-using-a-generations-shape-not-its-pixels): bridges as mattes over real frames.
- [spend](#reference-spend-on-generation): estimates, the ledger, two wallets, costs from the first films.

---

## Reference: Grounding every generation in the brand

Ungrounded moodboards on the first film drifted into generic grey glass. From then on, every generation (moodboards,
keyframes, plates, video) was grounded in the brand's real design system, and the drift stopped.

### The method

1. **Fetch the brand's kit.** The brand pack names its grounding kits (`grounding` in brand.json: an ElevenLabs brand
   kit id, a Higgsfield brand kit id) and its own reference assets.
2. **Wire its reference assets into the generation**: the logos, the palette, the typography rules, reference frames from
   the brand's website and product, when the brand allows uploads.
3. **Spell the brand's tokens and rules into the prompt**: its palette by name and value, its light (a product world, an
   inverse brand world), what's banned (glows, glass, stock grids, the brand's never-list).
4. **Grade toward the palette**: generated plates are graded toward the brand's palette tokens after conforming.

### A brand's two worlds

Most brands have a light product world (the product's own page and surfaces) and a darker or more saturated brand world
(for statements). Tell the generator which world a shot lives in, and ground it in that world's references.

### When the brand has no kit

A brand with no design system can bootstrap one during onboarding (a brand-kit tool can propose a palette, marks and
type), and the owner approves it before anything is generated from it (slate-brand).

### Checking a grounded take

Judge it against the brand's approved look reference, side by side (judging-takes.md): palette, light, texture, the
absence of anything banned. A take that drifts off-look is rejected even if it's beautiful.

---

## Reference: Judging takes

Every generated shot is judged from at least two takes, by a person, at full size and in motion. "Sometimes the AI
videos are bad, ugly, and they don't help": an ugly or AI-looking take never ships, however much it cost.

### The review

```
slate gen judge --shot S05
```

builds a contact sheet of every take side by side and measures each one: black or flat frames, freezes, flicker, size
and length against the request. It records a REVIEW gate: nothing passes until a person picks.

Look at each take:
- **in motion**, at full speed and slower: interpolation artifacts, morphing, swimming textures, flicker;
- **at full size**: detail, edges, faces, hands, text-like shapes the model invented;
- **against the brand's approved look**, side by side: palette, light, texture, mood;
- **in its place**: with the shots either side, and the film's line and type over it where they'll be.

### Reject a take when

- it reads as AI: a floating or drifting line, a synthetic texture, morphing forms, uncanny people;
- it drifts off-look: painterly when the film isn't, off-hue, the wrong sky;
- it invents its own elements: a guide line drawn beside the film's line, mirrored forms, an extra branch;
- it breaks the brief: an element the prompt didn't ask for, the wrong subject, the wrong move;
- it fails a measurement: black or frozen frames, flicker, the wrong length or size.

### Picking

```
slate gen pick --shot S05 --take t2 --by <who chose> --reject t1 --why "painterly, off-palette"
```

The pick records the approved take's SHA-256 (the conform refuses a take that no longer matches) and the rejections with
their reasons. If every take is rejected, the gate fails: generate again with a better prompt or references (and a new
estimate), or give the shot to code.

### After picking

- Conform the approved take (plates.md) and check every shot that uses it for interpolation artifacts.
- Grade it toward the brand's palette tokens.
- Check the joins numerically where a plate meets code-built frames (the tone of the ground per frame, the steps across
  the boundary).
- Keep every take and its record: the rejected ones are evidence of what the model does.

---

## Reference: Mattes: using a generation's shape, not its pixels

### The lesson

The requester suggested using generation "to bridge gaps between clips". In a code-built film the acts join on shared
contract frames, so there are no literal gaps; the one place a generated bridge adds something code can't is where the
code's world meets photographic footage (a paper world opening into a real landscape).

The first version played the generated bridge on screen, under the code's words. The owner liked the paper bleeding into
the landscape, and not what followed: "you can obviously tell it's AI-generated. That line that's tracing the mountain
keeps floating." A version generated between background-only frames did worse: it drew its own guide line 60 to 100 px
off the film's line, and mirrored forms.

**What worked:** only the generation's **shape** survived. It became a matte:
- the generated clip becomes a monotonic, hole-filled matte (its difference from its first frame), spread with a soft,
  organic front;
- inside the matte, the **real** plate (an approved take, or real captured frames);
- outside it, the film's own ground;
- the generation's own texture shows only in the thin edge band, where it reads as ink or water;
- the code draws the line, the dot and the words on top, exactly where they belong.

### Building one

```
slate plates matte --shot S05 --base <the film's ground frame> --real <shot, capture:<name> or a folder of frames>
```

The generate block for the bridge says `"reason": "bridge-matte"` with a `why`, which needs the film's generation setting
to be `where-it-helps`. `--preview` writes a quick look before the full sequence.

### Rules

- **Never put generated motion on screen where code or real footage exists.** Mine generations for shape, timing or
  texture, and composite real pixels through them.
- **Generate between the film's own frames**, never between background-only frames.
- **Judge at least two takes** of the bridge, as with any generation.
- **Check every cut numerically**: the ground's tone per frame across the reveal, and the steps at the hand-over to the
  plate, which should match the plate's own motion.
- The film's code still draws everything designed.

---

## Reference: Models

Slate doesn't work without the best models, so the best one for each role is the default: recorded in `registry.json`
with the date it was verified, pinned per film at first use, and overridable per film (film.json `models`), per user
(`slate.toml`) or per shot (the generate block's `model`).

### Roles

The role follows from what a shot's generate block gives it:

| Role | When | Typical inputs |
|---|---|---|
| a still | no image, video or duration | a prompt |
| animate a plate | an `image` (and optionally an `end_image`), or a `duration` | a start frame, an end frame |
| style-locked from references | `reference_images` | several stills that set the look |
| extend a plate | a `video` | an earlier selected plate |

`slate plates plan` shows each shot's role, model and estimate before anything is spent.

### Routing

- **Keep a routing table and a plate review sheet.** Models differ in brief fidelity: on the first films one family came
  out painterly and off-palette, another broke the brief with an extra element, and a third matched the keyframes.
- **Resolution and length caps differ**: some video models stop at 720p; use a higher-resolution model for hero plates.
- **Availability varies**: a model can be temporarily unavailable. Have a fallback per shot.
- **Native frame rates differ** (plates often arrive at 24 fps); the conform handles it (plates.md).
- **Re-check the catalogue** at the start of a project and before assuming a gap: the catalogue changes monthly, and
  model knowledge in any agent is older than the catalogue.

### What the Cloud API can't do

- **Voice and music**: no voice or music models. Voice and music come from ElevenLabs (slate-voice, slate-sound).
- **Product-true UI or exact brand type**: generated UIs aren't the product; UI and type stay in code.
- Some app-only models and workflows (a cloud video editor, narrated explainer workflows) exist only on the app-credit
  side, which isn't funded (spend.md).

### Pinning

`slate gen run` pins a shot's model at first use. A registry refresh never changes a pinned film; re-pinning is
explicit, tested and approved, so a re-generation in week three matches week one.

---

## Reference: Plates: generated atmosphere in a code-built film

A plate is a generated background shot the film plays from its own clock: a landscape, weather, a real place. It's
atmosphere only: the film's own code draws everything designed over it.

### Rules on screen

- **Plates are never covered with UI, charts or logos.** Only the film's signature line and type sit over them.
- **No extra blur on plate footage**: its motion blur is baked in; blur only the graphics over it.
- **Keep type legible over footage** with a soft brand-colour grade behind it, never a box.
- **Place type over footage where the plate is darkest and least textured**, measured from its frames (the first films
  used luma 45 to 85, with texture within a few levels), never guessed; the access gate's contrast check confirms it.
- **A thin accent line over footage of a similar colour nearly vanishes**: give code-drawn elements over footage a paper
  edge and a soft shadow, so they read as objects laid on the image.
- **Reveal a plate the brand's way**: parting the page along a line, a mask, a portal; never a crossfade
  (slate-motion, transitions.md).
- **Show stress on footage as an atmosphere change** (a shadow front over the land, the sky kept clean), never as a
  cover over the image.

### Continuity

Generate later plates from the film's own stills and frames of an earlier selected plate (reference-to-video), or extend
a selected plate, so the world stays the same world across shots.

### Plate briefs are templates

Every brand keeps its own reference pack for generations, and every approved plate's brief (its prompt, references,
model and seed) becomes the template for that brand's next plates (prompting.md).

### Conforming

```
slate plates conform --shot S05
```

- Only the approved take (its SHA-256 must still match the pick).
- Motion-compensated to the film's frame rate from the clip's native rate (plates often arrive at 24 fps), then written
  as a JPEG sequence at the film's size in `plates/<shot>/plate/frames/`, which scenes play from film time (video decoders
  crash long parallel renders).
- Native audio, if any, is kept as a 48 kHz, 24-bit ambience file for the mix, high-passed and well under the voice.
- Optionally a ProRes 422 HQ copy at the native rate, for After Effects.
- `plate.json` records the provenance: request id, model, sizes, rates, duration, the estimated and actual cost, and who
  approved it.

**Inspect interpolation on every shot that uses a conformed plate**: motion-compensated conforms can tear on thin
features and haze.

**Uneven steps get repaired, not re-generated.** A generated plate can hitch once a second where the model joins its
chunks (a dropped or a frozen frame). `slate plates repair <shot>` measures each
step of the approved take on the plate's moving band, puts the frames on a true-time axis (a missing frame takes about
1.8 units, a frozen frame none), makes every film frame at its even place with optical flow (or a blend) and moves the
plate's edge track through the same warp. It stages everything with a report first and installs only when no step is
over 1.3 times its neighbours (`--install`), keeping the old sequence; the approved take is never touched. The conform
warns when a plate hitches, and `--dry-run` measures without writing.

### Drawing on a plate

When the film's line has to sit exactly on a plate's feature (a ridge, a horizon), track it:
`slate plates track --shot S05 --hue <range>` finds where the land meets the sky per sample, with the colours as data.
Trackers hop between near-equal features and drift outside their reliable window: follow features, hold outside the
window, and smooth over time.

When the footage settles, bring it to exactly full frame at 1:1 scale: the track is in plate pixels, so any scale left
on the footage moves the line off the feature.

### Provenance and delivery

Every plate carries its request id, model, prompt, cost and approval. A plate from a replay (tests) is marked so and
never ships in a final delivery; neither does a plate without an approved take.

---

## Reference: The generation policy

The owner's rule: generation is rare by default, and the person asking decides how much. Code builds anything designed;
generation is for real people, real scenes and stock-style shots code can't make, or where it genuinely adds something.
Every take is judged, and ugly or AI-looking takes never ship. The best models by default, configurable.

### The film's setting (the requester's choice)

| Setting | What may generate |
|---|---|
| `none` | nothing |
| `rarely` (default) | only what code can't make: `real-people`, `real-scene`, `stock` |
| `where-it-helps` | also `adds-something` and `bridge-matte`, each with a written `why` of at least a sentence |

Set it at intake (`slate new --generation`) from what the requester says; ask when a brief implies generated footage
("a shot of a crowded street at night") and the setting doesn't allow it.

### What's never generated

Anything designed: UI, app screens, text and type, copy, logos and wordmarks, charts and graphs, data, numbers,
diagrams, icons, brand graphics. A generate block whose `contains` lists any of these is refused: code draws it. A
generated plate is atmosphere only, with only the film's line and type over it.

### Where generation has earned its place

- **Atmosphere plates**: a landscape, weather, a city at night, where the film's world opens up.
- **Real people and real places** the film needs and can't capture or draw (with the requester's sign-off for people).
- **Stock-style shots** a film would otherwise license.
- **A bridge used as a matte** where the code's world meets real footage (mattes.md).
- **Native ambience**: some video models return usable ambience with a plate (wind and air, no music), at a small extra
  cost.

### Where it failed

- Generated pixels on screen where code or real footage existed read as AI: a generated line tracing a ridge "keeps
  floating" and was rejected; only the generation's shape survived, as a matte.
- Stylized generated explainers aren't brand work: they're stylized clips, not the brand's type or real UI.
- Background-only first and last frames made a model draw its own guide line 60 to 100 px off the film's line.

### Autonomous films

Autonomous films generate under the same rules, and every generation waits for the owner's yes:
1. `slate gen request-approval --shot <S>` writes the request (never edited afterwards) and asks the owner by iMessage and
   push (never in tests or replay).
2. The owner's yes is recorded as a spend approval with an id.
3. `slate gen run --shot <S> --approval <id>` spends; without the approval the ledger refuses (exit 4).

### Brand material and uploads

- Brand, UI and video material goes to a generator only when the brand's owner allows it: the pack's
  `grounding.uploads_allowed`. Text-only prompts are always fine.
- A film's own generator outputs (its takes) can be sent back to the generator (for continuity); that isn't brand
  material.
- Company source code never goes anywhere; credentials are never uploaded, printed or written to a file.
- Only generic design queries go to third-party inspiration services.

### The lane

Every Slate generation runs on the Higgsfield Cloud API: the one funded lane, callable by any agent with a key, pay per
generation. When the API has a real gap (it has no voice or music models), the next direct vendor fills it (ElevenLabs
for voice and music), never an unfunded lane. Re-check the API catalogue before assuming a gap still exists.

Other routes bill other pools, and Slate doesn't use them:
- **Higgsfield's CLI** (and the skills built on it) bills the app-credit pool, separate from the Cloud API; it estimates
  with its own cost command and signs in by browser OAuth, which only a person runs, in their own Terminal.
- **Higgsfield's hosted connector** serves After Effects recipes as free text, but generating inside them spends the
  app-credit pool, not the Cloud API balance.
- **ElevenLabs' connector** also exposes third-party image and video models and lipsync; generations there bill
  ElevenLabs credits and bypass Slate's ledger.

Spend made in a chat through a connector is caught by the session's balance snapshots, never by the ledger.

---

## Reference: Prompting generators well

Text-only prompts had the first films' generator "flying blind": it could only make atmosphere. Given full visual context
and explicit prompts on the top models, it matched keyframes.

### Give the model everything it's allowed to see

When the brand allows uploads (`grounding.uploads_allowed`):
- **a reference pack**: the brand's look (its kit's reference frames), UI frames and reference-film frames where they
  help set the look (never to be reproduced on screen);
- **start and end frames**: the film's own frames either side of the shot, so the generation joins the film;
- **reference-to-video** inputs for continuity: an earlier selected plate, or stills from it (plates.md);
- the shot's **duration**, **aspect** and **size** (Slate fills these from film.json).

When uploads aren't allowed, the prompt carries the brand in words (grounding.md), and continuity comes from the film's
own takes, which are the film's material, not the brand's.

### Write long, explicit prompts

- Describe the shot as a cinematographer would: subject, setting, time of day, light, lens and camera movement, depth,
  colour, texture, mood, pace.
- Spell out the brand's palette tokens and rules (the colours to grade toward, what never appears).
- Say what must **not** appear: no text, no UI, no logos, no extra elements, no invented guide lines.
- One shot per prompt. Don't ask a clip to do two things.
- Keep the wording of a successful prompt as the template for the next shot of the same kind.

### Templates per brand

Plate briefs are templates, and every brand keeps its own reference pack for generations. Once a plate prompt has
produced an approved take, record it (with its model, seed and references) in the film's records and reuse it as the
starting point for the brand's next plates.

### First and last frames

- Generate **between the film's own frames**: the model then works inside the film's geometry.
- Don't hand the model background-only frames and hope it keeps the film's elements: it will draw its own versions of
  them, off by tens of pixels.
- The film's code draws its own lines and type over a plate; the generation never draws them.

### Stills

Keyframes and stills (for a plate to animate, or a look test) follow the same rules; image models vary in how they take
a palette lock, a background colour or type (never use generated type as final type).

---

## Reference: Spend on generation

### How a generation is paid for

1. **Estimate first**: `slate gen estimate --shot <S>` asks the API's free estimate endpoint (nothing spent, no ledger
   row); `slate plates plan` totals every shot. In the answer, **`usd` is the price** (after any discount) and
   **`discount.usd` is the saving**, never the price: the ledger books `usd`, and the list price is the two added up.
   Some models (Seedance 2.5) answer with a description instead of a number; then the registry's price for the
   resolution asked for stands in.
2. **Budget check**: the film's Higgsfield budget (a hard stop) and the month's cap for the film's mode.
3. **An in-flight ledger row** with the request id, written before waiting.
4. **The result**: the take, its cost, its record.

- **Every submit carries an Idempotency-Key**, derived from its ledger row, so the same request always has the same
  key. When an answer is lost (a timeout, a dropped connection, a 5xx), Slate sends it again **with the same key and
  the same body**, a few times: Higgsfield answers a repeat with the original request and charges once. A rerun after
  a crash does the same. Only a submit sent without a key is never retried.
- **An answer that never came** after those tries closes the row as failed but counts the quoted price (it may have
  created a billed job). With a key it's safe to run again later, so a queued job goes back in the queue by itself
  (exit 75); without one, check the console first.
- **A rate limit or the account's concurrency cap** created nothing: it's busy (exit 5), and the queue retries later.
- **A rerun polls, never pays twice**: a request id that reached the ledger but not the take record is adopted and polled.
- **A yes covers what it asked for, one call each**: an autonomous film's approval request for N takes spends as N
  slots (`<yes>#1` to `<yes>#N`), each recorded on its own ledger row, so one yes can't be spent twice. A slot whose
  call failed or was cancelled (nothing billed) is free again.
- **Cancel only reaches queued requests**; stopping polling doesn't cancel. `slate gen cancel --shot <S>` cancels properly.
- **Failed and moderated jobs aren't charged.**
- **Download outputs at once**: the vendor keeps output URLs only for a limited time. Slate does.

### Two wallets

| Wallet | Pays for | Status |
|---|---|---|
| **Cloud API balance** | every Slate generation (`slate gen`) | the one funded lane |
| **App credits** | Higgsfield's CLI, app and hosted connector, including its own skills (the fast lane) and its After Effects recipes | not funded by default |

Generations made in a chat through a hosted connector bypass Slate's ledger; the session's balance snapshots catch them
(slate, budgets.md). The ElevenLabs connector's third-party image and video models bill ElevenLabs credits, and bypass the
ledger too.

**Slate never buys credits, tops up a balance or upgrades a plan.** It can say when a plan would pay for itself (the
smallest plan, one month first), and the owner decides.

### What the first films cost

| Use | Roughly |
|---|---|
| A still (keyframe or look test) | cents |
| Animating a plate, 5 seconds, on a workhorse model | about $0.25 to $1 |
| A long, high-quality plate (10 to 12 seconds on a top model) | about $11 to $15 |
| A hybrid film: about 40 s of generated plates, a few takes each | about $8 to $30 |
| An all-generated six-minute cut | roughly $55 to $95 |
| An explainer's 0 to 2 generated shots | about $15 to $30 each, including one reject |

Prices move (discounts come and go, and `registry.json`'s price notes say when each one ends); budget at list price,
and check `registry.json`'s verified-on date before a big batch.

**Resolution is a spend decision.** Video plates render at 720p by default. Seedance 2.5 also offers 1080p on every
plate workflow, at 2.46x the price (about $5.69 for a 5-second plate instead of $2.31); moving up is the owner's call,
recorded once in Slate's settings (`[gen] video_resolution`) or on one shot (`resolution` in its generate block).
