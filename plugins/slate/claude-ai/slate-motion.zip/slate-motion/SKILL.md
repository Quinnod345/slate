---
name: "slate-motion"
description: "The motion law and motion craft for Slate films. Covers named eases by job, the duration scale, staggers and their caps, landing moves on the voice's words, look and motion development, camera, transitions, morphs and shared elements, signature moments, a brand mark moved as a character, the anti-glitch rules and the glitch catalogue, read time and safe areas, with The Browser Company's craft as the north star (the feeling, never their brand) and Material 3, IBM Carbon and Apple HIG as alternative motion systems. Use when designing, building, reviewing or fixing how anything moves in a Slate film, writing a brand's motion law, animating a brand mark or motif as a character, or chasing a jitter, pop, strobe or flicker."
---

> Knowledge-only edition of Slate's `slate-motion` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-motion

Motion is where a film feels made by hand or made by a template. Slate's films earned their motion the hard way: a
motion law measured from reference films and the product's own tokens, a catalogue of every glitch that shipped to a
review and why, and a character spec rewritten after "it's super glitchy". This skill carries all of it, generalized
for any brand.

The law is data, the kit enforces it, and a gate checks it:
- the brand's **motion law** lives in its pack (`motion` in brand.json, written at onboarding);
- the Remotion kit moves things only by the law's names and exact-endpoint eases, and records every move;
- `slate emit-events` writes each act's motion trace, and `slate qa motion` checks it.

## 1. The north star and the bar

- **The Browser Company's craft and warmth** is the north star: motion that feels hand-made, where every move has one
  reason and lands with its sound. Borrow the feeling, never their brand; express it inside the brand's own tokens.
- **The visionary bar:** beautiful enough to make someone cry. One signature moment per act; correct but ordinary
  isn't enough (slate-story sets the moment, this skill stages it).
- **Intentionality:** one carrier per act, one idea per beat, every move tied to the voice's word or to the idea.
  Fewer, better moves. Stillness is part of the design.

## 2. The motion law

Every brand's law names its eases by **job**, and scenes move things only with those names:

| Job (kit role) | What it moves | Shape |
|---|---|---|
| entrance | type, cards, UI arriving, draw-ons, count-ups | fast start, long settle |
| move | rest-to-rest moves: camera push, pull and truck; carries | starts and ends at rest |
| relayout | short make-room re-layouts (0.4 s or less) | quick, soft |
| state | a chip flips, a check lands, a toggle | the product's own state-change ease, unchanged |
| exit | anything leaving | accelerates away, 0.75 times its entrance |
| settle spring | named container morphs only | a settle, never a bounce |

Durations come from the brand's scale (tick, quick, base, broad, camera, signature), exits are 0.75 times their
entrance, nothing but a state flip moves in under 0.2 s, and an act gets at most one signature duration. Staggers are
capped (a group's spread at most 0.6 s and half its entrance). A move lands (90% of its travel) within 2 frames of the
word it illustrates: the kit's `landOn` and `startFor` do the maths. A brand with no law draws with the kit's neutral
law until onboarding writes one, and the kit records that as a problem.

In depth: [motion law](#reference-the-motion-law), [eases](#reference-eases-springs-and-landing-on-the-word),
[durations and staggers](#reference-durations-and-staggers).

## 3. Look and motion development

A brand's look is built from its own design language (its components, tokens and product motion), never from generic
prompts, and it's approved from a **moving** 10 to 15 second test with sound: stills don't count. The kit's looks
library starts it (`flat` by default; `paper-2.5d` only for brands whose own language is papery; `editorial`;
`blueprint`; the After Effects bridge's looks by name). Onboarding runs this once per brand (slate-brand); a film's own
look test happens only when the brand's look isn't approved yet.

Composition: whole designed objects in generous space, one clear focal object and a clear hierarchy per frame. A thin
line on a big empty field reads as empty. See [look development](#reference-look-development-and-composition).

## 4. The craft, move by move

- [camera](#reference-camera): drift to keep the world alive, rest for exact frames, one camera move per act.
- [transitions](#reference-transitions): every scene change is a carry, a portal, a mask or a whip; no hard cuts
  or crossfades except the reasoned ones.
- [morphs and shared elements](#reference-morphs-and-shared-elements): one object across a cut, keeping its label.
- [techniques](#reference-techniques): tilt-to-flat, component zoom and pull-back, mask reveals, per-character type.
- [signature moments](#reference-staging-signature-moments): staging the held breath, the landing and its echo.
- [logo build](#reference-building-a-logo-and-the-sting): constructing a mark, and the bookend that replays it.

## 5. A brand mark as a character

When a brand's motif or mark becomes a character, it gets a small, fixed gesture vocabulary, each gesture with one
meaning and one word it keys to, and a pose that's a pure function of the film frame. Its parts move in whole-frame
phases (unison, pairs or a wave), never faster than a 16-frame swing, at most 30 px a frame and 8 px a frame squared
at a 1080-line frame, start and end at rest, draw as one flat plane in fixed sheets, never clip, and move as a whole at
small sizes. Between gestures it is exactly the brand's mark: stillness is the default. The kit's `MarkCharacter`,
`MotifMark` and `gesture()` implement the method. Full method: [character and motif motion](#reference-a-brand-mark-as-a-character-the-method);
one-page checklist: [character motion](#reference-character-motion-the-one-page-checklist).

## 6. Anti-glitch

Most glitches that reached a review came from a handful of causes:
- a move that starts at full speed (the entrance ease leaves rest fast) smears on one frame and goes sharp on the next
  under motion blur: run big moves on the rest-to-rest ease;
- oscillation near 4 Hz makes motion blur pulse near 8 Hz, where flicker is most visible: no wobbles, no idle loops;
- sub-frame staggers put parts at different shutter phases: offsets are whole frames;
- things that pop: an entrance starting part-way into the frame, a mask eased twice, a colour or shadow switching at a
  threshold, a label reflowing in one frame;
- planes that cross or share a depth, and slice or z-fight under the shutter;
- text that snaps to whole pixels while shapes glide, reading as jitter.

Run the [glitch catalogue](#reference-the-glitch-catalogue-a-pre-render-checklist) as a checklist before every render; the reasons and fixes
are in [anti-glitch](#reference-anti-glitch-rules), and what's banned (with its reasoned exceptions) in
[banned moves](#reference-banned-moves-with-their-reasoned-exceptions).

## 7. Read time and safe areas

- Every on-screen statement holds, once fully built, at least max(1.5 s, 0.4 s + 0.3 s per word); numbers 2 s after
  they land. Fix a short hold by extending the settled hold inside the shot, never by moving words or cuts
  ([read time](#reference-read-time)).
- Text stays inside the title-safe area and each platform's safe zones; body text at least 28 px at a 1080-line frame;
  text contrast from the brand's colour pairs; no more than three flashes a second ([safe areas](#reference-safe-areas-legibility-and-accessibility)).

## 8. Other motion systems and principles

Material 3, IBM Carbon and Apple's HIG are alternative motion systems: Material 3 for brands built on Material, Carbon's
productive curves for product UI shown inside a film and its expressive curves for the film's own big moments, Apple's
guidance for restraint. The twelve animation principles and UX in Motion's twelve apply with one caution: only easing
carries over directly from character animation to interface motion. See [motion systems](#reference-motion-systems-the-north-star-and-the-alternatives),
[principles](#reference-animation-principles-applied-to-film-and-interface-motion) and [sources](#reference-sources-for-the-motion-rules).

## 9. Checking motion

- `slate emit-events` writes each act's visual events and motion trace; `slate check <act>` is the builder's hand-in
  check; `slate qa motion` checks every trace: the brand's eases, durations and stagger caps, entrances from at least
  85% scale, at most 30 px a frame and 8 px a frame squared (at 1080 lines), no loop faster than a 16-frame period,
  symmetric mark rigs, plus a pixel cross-check for fast motion the trace doesn't explain.
- `slate qa glitch` scans the rendered acts for one- and two-frame glitches, skipping flags within 3 frames of a planned
  beat; triage the rest (slate-qa).
- Look as well as measure: stills at the changed frames, contact sheets, a preview at quarter speed with sound. For any
  move, check its start, anticipation, fastest frame, overshoot, settle and last frame with motion blur at delivery
  settings.

## References

- [motion-law](#reference-the-motion-law) · [eases](#reference-eases-springs-and-landing-on-the-word) · [durations-and-staggers](#reference-durations-and-staggers)
- [look-development](#reference-look-development-and-composition) · [camera](#reference-camera) · [transitions](#reference-transitions)
- [morphs-and-shared-elements](#reference-morphs-and-shared-elements) · [techniques](#reference-techniques)
- [signature-moments](#reference-staging-signature-moments) · [logo-build](#reference-building-a-logo-and-the-sting)
- [character-and-motif-motion](#reference-a-brand-mark-as-a-character-the-method) · [character-motion](#reference-character-motion-the-one-page-checklist)
- [anti-glitch](#reference-anti-glitch-rules) · [glitch-catalogue](#reference-the-glitch-catalogue-a-pre-render-checklist) · [banned-moves](#reference-banned-moves-with-their-reasoned-exceptions)
- [read-time](#reference-read-time) · [safe-areas](#reference-safe-areas-legibility-and-accessibility)
- [motion-systems](#reference-motion-systems-the-north-star-and-the-alternatives) · [principles](#reference-animation-principles-applied-to-film-and-interface-motion) · [sources](#reference-sources-for-the-motion-rules)

---

## Reference: Anti-glitch rules

Every rule here is a glitch that reached a review on the first films, with its cause. The pre-render checklist version
is [the glitch catalogue](#reference-the-glitch-catalogue-a-pre-render-checklist).

### Speed, blur and flicker

- **Blur length follows speed.** A wobble at f Hz makes motion blur pulse at 2f; flicker sensitivity peaks near 8 Hz.
  A 4 to 4.5 Hz damped wobble on every beat read as jitter. Keep any oscillation well below 4 Hz, or better, don't
  oscillate.
- **Sub-frame staggers** (1.05 and 1.65 frames) mean no two parts sit at the same phase of the shutter, so every part's
  blur differs. Offsets between parts are whole frames.
- **A strong out-ease leaves rest at over six times its average speed**, so the blur jumps from nothing to a long streak
  in one frame; an exit that ends fast does the same at the end. Big moves run on the rest-to-rest ease.
- **Strobing is too much change between adjacent frames**, not a frame-rate problem. Keep a fast move's speed and
  acceleration bounded (30 px a frame, 8 px a frame squared at a 1080-line frame) and its duration long.
- **A whip so fast it doubles an element in the blur** is a defect; re-time the beats so the carry is a glide.
- **Stacked out-of-phase loops read as swimming.**

### Entrances and exits

- **Nothing appears from nothing.** An entrance moves in from fully outside the frame, or fades in as one sheet over a
  real duration, or starts from at least 85% scale in place. It never starts part-way through its move, and never
  starts partly inside the frame.
- **An opacity fade on a strong out-ease** is mostly done in its first frames and reads as a pop: fade-ins need a
  gentler curve or a longer duration, and objects lay in from just above rather than from deep behind.
- **Nothing vanishes in one frame.** Every element leaves on the exit ease, including the heads and endpoints of lines
  that fall or finish.
- **Exits leave the frame as opaque objects**, front one first, and are removed once off frame; cards fading out over
  each other read as cards seen through cards.
- **Return an object by carrying it back** (rising from below), not by fading it up from depth: a fade read as a ghost.
- **Carried elements leave with their page**; nothing lingers half-cropped at the frame edge into the next section.
- **Deal new cards in** rather than leaving an empty frame between screens, and keep content visible during a morph.

### Morphs and overlaps

- **Never crossfade one version of a card into another**, and never let two headings cross-fade: sequence the morph so
  one leaves before the next arrives, and hold existing copy while new items drop in.
- **Never duplicate an object to animate it.**
- **Never ease a value twice** (a mask fed through two eases filled in one frame).
- **Animate corner radii before a split or merge**; don't let them snap on the first frame.
- **A container and its contents share timing**, or the edge runs ahead of what it holds.
- **Two moves on the same path sum into an overshoot**: drive them from one clock and measure the path.
- **When an element lifts off a chart**, its attached parts (area fill, head marker) go with it or fade gradually;
  removing them all on the hand-off frame changed 23,654 pixels in one frame.
- **Draw merged segments as one continuous path** so no seams show.

### Depth and stacking

- **Surfaces crossing through other planes get sliced** for a few frames: nothing crosses, and exits finish before
  entrances take the space. Keep moving cards in front of the planes they pass.
- **A card flip lifts toward the camera** and never passes behind its neighbours.
- **Deal cards as opaque paper**, parallel to the deck and always in front of it, with only in-plane rotation: a
  translucent, depth-turned card let the card under it show through and got sliced.
- **Show supporting surfaces one at a time**, rising and sinking in place, each in its own layer: surfaces never slide
  past or under each other.
- **Connecting threads route through gaps** and never cross words.

### Text and layout

- **Never land a line of type while the layout around it is still moving**; wait for it to settle.
- **Never write glyphs into space that's still occupied**: clear each glyph's space before it arrives, and let an impact
  ring out before the end card forms.
- **Keep layouts stable when data changes**: leave out explanatory lines that would make a column reflow (a reflow
  became a fast 112 px move).
- **Count a value once**; re-count only when it really changes, from its old value.

### Fine detail

- **Fine regular patterns shimmer and moire**, worst in downscaled copies: a field of 2,560 small dots on a tight pitch
  rang and sparkled. Use fewer, larger elements jittered off any lattice, move each only a little, pin the pattern to
  the screen while the camera travels, and check it at the smallest delivery size.
- **Thin rotating lines (about 1 px) crawl with jaggies**: use strokes of 3 px or more, and give every moving line a
  cause.

### Character marks

- **A mark whose parts overlap by design** shows seams and double shadows when each part is drawn separately with its
  own opacity, paper edge and shadow; parts placed in 3D at the same depth z-fight; and a spread that hovers near the
  point where the mark splits apart flickers between fused and split. Draw the parts as two fixed sheets, opacity and
  shadow per sheet, flat, and never rest near the split point.
- **Parts cut off at container edges**: nothing had checked the mark's envelope against the containers that clip it.
- **A colour mixed by distance from an edge** flickers at that edge; mix by flight progress instead.

The full method is in [character and motif motion](#reference-a-brand-mark-as-a-character-the-method).

### Renderer-specific

Headless Chrome and Remotion have their own traps (text snapping to whole pixels under slow motion, depth-sorting races,
clip paths that fail silently). Those are builders' rules: slate-build, remotion-gotchas.md and headless-chrome.md.

---

## Reference: Banned moves, with their reasoned exceptions

Banned by default in every brand's law. A brand can add to the list; it can loosen an item only with a reason recorded
in its MOTION.md and the owner's approval.

| Banned | Why | Reasoned exception |
|---|---|---|
| **After Effects' default Easy Ease** (33.3% influence, 0 speed on both sides) | It's the look of a template. Measured reference moves were nowhere near it (the nearest fit was off by 11.6%), so the ban is a fact, not a taste. | None on anything visible. Only on invisible utility keys, where no curve is ever seen. |
| **Linear moves** (position, scale, rotation) | Mechanical starts and stops. | Continuous drifts that start before the shot and end after it; things that represent time (progress bars, timelines, loaders, streaming text); a constant spin on a "thinking" indicator. |
| **Hard cuts** | They break the carried-pieces grammar and read as a slideshow. | Cuts masked by motion (inside a whip or a defocus); a few musical hit cuts on downbeats if the brand's law allows them; UI state cuts with the camera locked. |
| **Crossfades between shots** | They double-expose type into mud and hide motion. | Light or atmosphere changes within one shot; a blend of at most 4 frames hiding a seam in the same generated shot; audio. |
| **Scaling from zero** | Nothing in a good product scales from nothing. | Entrances start from at least 85% scale. |
| **Bounce or overshoot** | Good products settle; they don't bounce. | The brand's settle spring, on named container morphs only, within its stated peak; a character's one allowed dip, if its spec has one. |
| **Opacity-only entrances for hero text** | Flat and cheap. | Hero text must also move at least 16 px or unmask. Opacity-only is fine for secondary labels. |
| **Stock presets and effects**: glows, light leaks, lens flares, glitch effects | Off-brand, and they read as a template. | None. |
| **Glowing orbs and other AI-glow tropes** | Generic and off-brand. | None. |
| **Extruded 3D type** | Dated and generic. | None. |
| **Stock-photo grids** | Generic. | None. |
| **Typewriter text** | A gimmick. | Where the product really streams text that way (an assistant's streaming answer). |
| **Traffic-light gradients or colour ramps for status** | Status colours are the brand's tokens. | None. |
| **Radial light or edge shading on flat brand fields** | Reads as a glow. | None. |
| **Squash and stretch on paper-like marks** | Paper doesn't squash; parts keep the brand's shape. | None. |
| **Anything off-brand on a character**: glows, particles, lens effects, extra colours | The character is the brand's own mark. | None. |
| **UI the product doesn't have** | Nothing is invented. | A concept screen with the requester's explicit sign-off and a visible "concept" treatment. |
| **Confetti and particles as a celebration** | A template's idea of delight. | None: the brand's own objects carry the moment. |

### Checking

- `slate qa motion` fails an act whose trace uses an ease the brand doesn't name, a stagger past its cap, or an entrance
  from under 85% scale.
- The rest are checked by eye at review: contact sheets, the preview at quarter speed, and the review checklist
  (slate-qa).

---

## Reference: Camera

The camera is the viewer's guide. It moves to reveal and to carry, it rests when geometry must be exact, and it never
moves just to fill time.

### When it moves and when it rests

- **A slow drift keeps the world alive.** A drift that starts before the shot and ends after it can be linear, because
  its start and stop are never seen.
- **The camera rests** for UI state cuts, and wherever geometry must be screen-exact: act contracts, hand-overs between
  screen space and a card, rest frames that must be pixel-exact.
- **One camera move per act** is plenty. Prefer bringing a card forward, at the product's own size, over pushing the
  camera in: whatever needs a closer read comes forward off its surface.
- **Fewer, better moves.** Don't pan out to one thing and back when one draw-back can show both; don't push onto a page
  and straight back out.
- **The camera can step down a list** as the voice reaches each line.

### How it moves

- Camera moves run on the brand's rest-to-rest ease, at the camera duration or longer.
- **Anything that travels a long way travels soft and slow**, and comes into focus as it arrives.
- **Land detailed content only once the camera has all but stopped.** Small type rushing past a moving camera strobes
  and trips the glitch scan. The rhythm that works: the camera travels, comes to rest, then the station speaks. Measure
  a travel's screen speed frame by frame, and keep its frame-to-frame change small.
- **Never a giant fast pull-back as a transition**: a 4,000 px truck with a big zoom-out in under a second moved 267 px
  a frame, read as a whip, popped objects in from nothing and landed on things too small to read. Fold or carry from
  where the camera is.
- **Zoom in log space**, and prefer a 2D camera over poses: huge `translateZ` zooms rasterize badly.
- A world authored at film scale and screen-aligned at rest keeps rest frames pixel-exact.

### Depth of field

- 3D camera moves keep depth of field on, with focus keyed to the rest-to-rest ease, and an aperture that blurs
  off-focus UI past legibility (so it doesn't compete).
- A rack focus between focal elements is a lens effect, allowed; it never counts as a crossfade.
- For a weighty line, hold everything still except a slow focus pull that leaves one element standing alone.

### Framing

- **Close-ups never crop text mid-line.**
- Keep the focal object inside the title-safe area and the platform's safe zones (safe-areas.md).
- When the frame will be derived to another aspect, keep the action where a re-staged layout can still hold it
  (slate-finish, derived-films.md).

### The kit

`Camera` (a look-at camera, dolly in z) for 3D; `WorldLayer` (2D, identity at rest) for flat worlds; `camAt`, `lerpCam`,
`cam2DAt`, `drift2D` for paths. Draw objects that move against each other in separate cameras, so their stacking is plain
document order and can't flip.

---

## Reference: A brand mark as a character: the method

When a brand's motif or mark becomes a character (a character-led film, an assistant's mark, a mascot built from the
logo), it needs its own motion spec. Every rule in it is either sourced (from research, cited by label in sources.md)
or computed from the brand's artwork and the film's own word timings. This method was written after a character's
first version was called "super glitchy"; the second, built to it, was approved as perfect.

**The bar:** playful and fluttery is compatible with perfectly synchronized, as long as the parts move as one system,
on one clock, a few times, cleanly, with stillness in between. Motion that feels hand-made, where every move has one
reason and lands with its sound.

Frame counts below are at about 30 fps and speeds at a 1080-line frame; scale both to the film's own rate and size.

### What went wrong the first time

| What the owner saw | The cause |
|---|---|
| Jitter | A 4 to 4.5 Hz damped wobble on nearly every beat: a swing every 3.3 frames. Motion blur pulses at twice that (8 to 9 Hz), where human flicker sensitivity peaks. Per-part spins made it worse. |
| No coordination | Staggers of 35 and 55 ms, which are 1.05 and 1.65 frames: no two parts ever sat at the same phase of a frame or of the shutter, so every part's blur looked different. |
| Speed jumps | A strong entrance ease leaves rest at over six times its average speed and covers a third of a 16-frame move in its first frame: the blur goes from none to a long streak in one frame. |
| Clipping | Parts cut off at container edges (nothing checked the character's envelope), and a colour mixed by distance from an edge flickered at that edge. |
| Overlap glitches | Parts that overlap by design, drawn one at a time with their own opacity and shadow, showed seams and double shadows; parts at the same 3D depth z-fought; a spread hovering near the point where the mark splits apart flickered between fused and split. |

### 1. Study the mark as a system

- **Geometry**: the parts, their shape, where they sit (often on a ring), their rest rotations, as fractions of the
  disc or frame they live in. Tabulate part size, ring radius and ink radius at every size the film uses.
- **One part, N times**: a radial mark is often one part rotated N times. Then it's a replicator: motion defined once
  for part 0, copied with a rotation and a whole-frame delay, stays symmetric by construction.
- **Overlaps by design**: if parts tuck under their neighbours, the eye sees one shape. The brand's own paint order
  defines two sheets (the parts drawn first, the parts drawn over them).
- **The split point**: compute how far the parts can spread (all together, or one group alone) before the fused shape
  splits into separate parts, where parts of the same group first touch when pulled in, and where the centre closes.
- Store the result in the brand's pack (`motif`: parts, shape, sizes, groups, curves, mark ratio, gestures).

### 2. Channels: the only things that move

- **The whole mark**: its turn (rests at multiples of its symmetry angle), the whole avatar's scale, the mark's scale
  inside its disc, and the mark's offset from the disc's centre.
- **Each part**: its radial offset (in ring radii), its scale, and, for a part sent away, its place off the ring.
- Nothing else. No per-part angle, no per-part spin.

### 3. One clock

- **The pose is a pure function of the film frame**, including every sub-frame sample the renderer asks for. Nothing is
  carried between frames, no part has its own timer, and there's no randomness or noise.
- **Everything is in whole frames**: every key, and every per-part offset. Then the part in slot k at frame f is exactly
  the part in slot 0 at frame f minus its offset, rotated, blur samples included, so the blur streaks are rotated copies
  of one another instead of per-part noise.
- **Why**: every clean multi-part loader works this way. A circle spinner delays each of its 12 dots by the cycle over
  12; a replicator's delay is its duration over its count; After Effects' follow-the-leader rig reads each layer's value
  at time minus index times delay. Biology calls a fixed lag between neighbours a metachronal rhythm; perception calls
  it common fate: parts that move with the same timing read as one object.

### 4. Three phase relationships, and no others

| Mode | Offset for the part in slot k | Symmetry | Typical use |
|---|---|---|---|
| **Unison** | 0 | full, at every frame | nods, leans, holds, returns, a greeting's breath, flights |
| **Pairs** | one group a fixed whole number of frames behind the other | within each group | a breath, an entrance in the product's own bloom order |
| **Wave** | k times a fixed whole-frame step, counted from the wave's start slot | across time | the one flutter |

- Derive the pairs lag from the product's own loader timing (a loader running one group 8% of a cycle behind became a
  4-frame lag on a 48-frame breath).
- The wave's step is its cycle over the part count, in whole frames (a 24-frame cycle over 8 parts is 3 frames), which
  also lets each accent register: hold an accent at least two frames.
- Order by slot (where parts are now, counted round the ring), not by part: a turn moves every part one slot along.

### 5. Symmetry at every frame

- **Spoke lock**: every part's centre stays on its spoke; only its distance from the centre changes. The one exception
  is an entrance where a group spirals in as one rigid piece.
- **Orientation lock**: a part's own turn is always its rest turn plus the mark's turn. A part never spins on its own.
- **Deliberate exceptions**: gestures whose meaning is breaking the ring (sending one part away to point at something,
  gathering parts round a point). The parts left on the ring stay exactly at rest.
- Good radial marks change the whole mark at once: a ring that moves outward to respond and inward to listen, dots
  rooted in consistent paths and timing, a breathing flower driven by one container animation with no per-part delay.

### 6. No high frequencies

- **Minimum half-period of 8 frames**: consecutive reversals of any channel at least 8 frames apart, so a full swing
  takes at least 16 frames (under about 2 Hz).
- **At most one overshoot per gesture**, and only in the one gesture that needs it (a wave's small dip).
- **Nothing loops except a breath**, with a cycle of at least 44 frames. No idle loop.
- Why: blur length follows speed, so a wobble at f Hz makes the blur pulse at 2f, and flicker sensitivity peaks near
  8 Hz. Material 3 fires even its bounciest spring once per transition and its effects springs never overshoot; Apple
  defaults to no bounce and advises against sustained oscillation. Stacked out-of-phase loops read as swimming.

### 7. Speed limits, and no abrupt velocity changes

- **Zero velocity at both ends** of every move, or hand the exact velocity to the next move. Parts use only rest-to-rest
  curves: a sine in-out for nearly everything, and a zero-bounce-spring shape for a quick turn that settles onto itself.
  Never the entrance, exit, state or linear eases.
- **At most 30 px a frame** for every point of every part. The renderer spreads 16 samples over a 180-degree shutter, so
  the gap between samples is the speed over 32; 30 px a frame keeps it under 1 px. Up to about 48 only at the crest of
  a long flight the beat can't afford to slow.
- **At most 8 px a frame squared**: a point's movement per frame changes by no more than 8 px from one frame to the
  next, so its blur length changes by no more than 4 px.
- **A flight takes at least max(16, chord ÷ 19) frames**, so its crest stays under 30 px a frame.
- Why: strobing is too much change between adjacent frames, not a frame-rate problem; an ease curve stops abruptly where
  a spring keeps its velocity; AE's old 16-sample blur cap left visible echoes on fast objects.
- **Model every gesture numerically** at the smallest, typical and largest size it appears before building it, and
  record the worst case.

### 8. Nothing ever clipped

- Draw the character in an overlay layer above everything its parts visit, with no clipping ancestor.
- Every clip contains a clear circle round the character (about 0.85 of its disc's diameter covered the disc, its
  shadow and every gesture's reach) plus the whole path of any part sent away.
- Tabulate the envelope (the farthest ink from the centre) for every gesture.
- Inside a scroll view, it crosses the view's edge only when calm.
- A part that leaves the disc takes its colour by flight progress, never by distance from the disc's edge.

### 9. Overlaps without seams or z-fights

- **Two sheets, fixed for good**, in the brand's paint order. Membership is never re-sorted, so a turn never pops a
  layer. (Overlapping parts drawn one at a time can't have a consistent order round a ring.)
- **Opacity** on the whole mark or a whole sheet, never on a single part.
- **Paper mode**: one shadow and one paper edge per sheet (a drop shadow on the sheet's group shadows the union), never
  one per part.
- **2D only**: no 3D transforms on parts. To tilt the character, render it flat into one layer and tilt the layer.
- **Stay clear of the split point**: a spread either stays inside the fused band or goes decisively past it and crosses
  at speed, once out and once back. Never ease to a stop near it. Parts of the same group never touch.

### 10. At small sizes it moves as a whole

- Per-part choreography needs room. The films used three regimes: full choreography at about 88 px and up; unison only
  (no lags, the wave in unison) from about 56 to 87 px; and no per-part motion below about 56 px, where spread becomes
  the whole mark's scale (flights still work). Below about 80 px, as a rule of thumb, the whole mark moves as one.
- Choose the regime once per gesture, from the size at its contact frame, so nothing switches mid-move.
- Drop any per-part motion under 2 px at the current size: it reads as shimmer, not gesture. Hold parts on stable
  sub-pixel positions (a spinner's jitter was cured by keeping successive frames within a fifth of a pixel).

### 11. Stillness is the default

- Between gestures it doesn't move: consecutive frames are identical. No float, no idle, no breathing on its own.
- **Nothing is driven by the voice's loudness.** Speech loudness fluctuates mostly between 2 and 8 Hz, right in the
  jitter band, and a film knows every word in advance: key motion to events, never to amplitude.
- Knowing when not to move matters as much as moving; even audio-first products script their states. Delight means more
  from something that never exaggerates.

### 12. Keyed to the voice, landed with its sound

- **S** is the frame where the stressed syllable of the key word starts, and **C**, the contact frame, is two frames
  later: C = S + 2 (anywhere from S + 1 to S + 5 when a beat needs it, never later than the end of the stressed
  syllable).
- The key pose lands on C: 90% of travel for a landing, the apex for a peak. The move's top speed falls a few frames
  before C, near the vowel.
- **Early, never late.** A gesture's top speed coincides with the stressed vowel and its apex falls inside the stressed
  syllable; a gesture precedes or ends at the stressed syllable but doesn't follow it. Gestures 500 ms early didn't hurt
  recall in studies; 500 ms late did.
- **Later stress** (a word stressed on its second syllable): measure S from the take's loudness envelope (the stop
  consonant before a stressed syllable leaves a clean gap) and record it in the act's beats.
- **Sound sits on contact frames**: every sound's attack is on a contact frame, every note has its own visible contact,
  and sound never comes before the picture. One event per note, each on its own whole frame; when two land on the same
  frame, one plays, by a fixed priority. Viewers notice sound from about 45 ms early or 125 ms late.

### 13. The gesture vocabulary

- **A small, fixed vocabulary**, each gesture with one meaning and one kind of word it keys to. The kit's defaults:
  hello (an entrance and a breath), yes (a turn that lands on itself), attention (a lean), thinking (a breath), answering
  (a pulse), delight (a wave), care (a hold), landing (a ripple), home, goodbye (a turn). A brand defines its own in its
  pack (`motif.gestures`).
- **Never use a gesture outside its meaning.** When a treatment asks for a feeling the vocabulary doesn't cover, use
  staging instead.
- **Tempo carries meaning** (a fast pulse reads as an error, a slow one as rest); a small vocabulary on consistent paths
  reads as a character; a defined start and end, anticipation then release, reads as intentional.
- **Porting a product animation** to the rig: keep its choreography and replace its strong out-ease with the rig's
  rest-to-rest curve.
- **A gesture's spec**: its meaning, the word it keys to, each channel's keys in frames relative to C, its phase mode,
  its contacts, its sounds, how it behaves at each size, and what it never does (never a wobble after a landing).

### 14. How gestures combine

1. One momentary gesture at a time, with at least 4 still frames between one's end and the next one's start.
2. Held states (a lean's offset, a hold, parts sent away) persist until changed. Momentary gestures may run on top,
   except that nothing runs during a hold, and only a lean or a hold while parts are away.
3. Never two gestures on the same channel at once.
4. Every act starts and ends with the character calm: the brand mark exactly, turned to a multiple of its symmetry
   angle.
5. A builder's own moves of the character (placing it, resizing it for a gesture) are part of its motion: the rig's
   curve and its speed limits apply.

### 15. Staging a character

- **Introduce it up close**, assembled large, then a step back: assembled at its small lockup size, it read as a speck.
  See it made, let it turn to you, step back, then name it.
- Resize it into its full-choreography size before a gesture that needs it (enlarging over about 20 frames before a
  wave).
- Never show the character twice in one frame (a second copy as a chat avatar splits it).
- Check a flight's path against the marks it passes, and choose the part and placement that clear them.
- Place it where its later UI will open into empty space, not over content.
- Its sounds are soft felt notes (its motif), a small wood tick and soft pads, never chimes (slate-sound).

### 16. Acceptance tests

1. **Determinism**: any frame rendered on its own is bit-identical to the same frame rendered in sequence.
2. **Calm**: at rest the frame after every gesture ends, and at both ends of every act.
3. **Symmetry** at every sub-sample: unison parts equal; pairs equal within each group and lagged exactly; wave slots
   lagged exactly.
4. **Speed**: every point at most 30 px a frame (48 only at a long flight's crest), acceleration at most 8 px a frame
   squared.
5. **Frequency**: reversals at least 8 frames apart; the one allowed overshoot only where it's allowed.
6. **The split point**: the gap between neighbours changes sign at most once out and once back per gesture, across all
   sub-samples.
7. **Clipping**: whenever it isn't calm, every clipping ancestor contains the clear circle and any away part's path.
8. **Sound**: every character event on a whole frame, one event per note, no offsets added by the sound engine.
9. **Eye**: the gesture sheet at the smallest and largest sizes, at full and quarter speed, with sound. Nothing
   shimmers, pops or strobes, and every note lands on something you can see.

### The kit

`MarkCharacter` (the disc with the motif in it) and `MotifMark` draw the rig; `gesture(meaning, {t | frame})` makes
track entries from the vocabulary; `motifBeats()` lists the character's sound events (kind `character`, one per note);
`motifLint()` lists anything the combination rules forbid (an empty list is a clean track); `registerMotifTrace()`
records the rig for `slate qa motion`, which checks symmetry and the speed limits; `isCalm()` checks rest. The research
behind each rule is in [sources](#reference-sources-for-the-motion-rules).

---

## Reference: Character motion: the one-page checklist

Run this before handing in any act where a brand mark, motif or character moves. Each line is a rule from the full
method in [character and motif motion](#reference-a-brand-mark-as-a-character-the-method); the reason is there.

### Clock and phase

- [ ] The pose is a pure function of the film frame, sub-frame samples included. No timers, no randomness, no noise.
- [ ] Every key and every per-part offset is a whole number of frames. No sub-frame staggers (35 or 55 ms offsets put
      parts at different shutter phases and read as jitter).
- [ ] Only three phase modes: unison, pairs (a fixed whole-frame lag), a wave (a fixed whole-frame step per slot).
- [ ] Parts stay on their spokes and never spin on their own.

### Curves and speed

- [ ] Every move starts and ends at rest, or hands its exact velocity on. No entrance, exit, state or linear ease on
      the parts (the fast-out entrance ease leaves rest at over six times its average speed and smears under blur).
- [ ] Every point at most 30 px a frame and 8 px a frame squared, at a 1080-line frame.
- [ ] No oscillation faster than a 16-frame swing; nothing loops but a breath; at most one overshoot per gesture.
- [ ] Nothing is driven by the voice's loudness (it modulates at 2 to 8 Hz, the jitter band).

### Drawing

- [ ] Drawn as one flat plane in two fixed sheets, in the brand's paint order; never 3D parts in a shared 3D context
      (they z-fight under the 16-sample shutter).
- [ ] Opacity, shadow and paper edge per sheet or whole mark, never per part.
- [ ] Nothing clips it: an overlay layer, a clear circle in every clip, the envelope checked per gesture.
- [ ] A spread never rests near the split point.

### Size

- [ ] Below the small-size threshold (about 80 px as a rule of thumb) the whole mark moves as one.
- [ ] Per-part motion under 2 px is dropped.
- [ ] The regime is chosen once per gesture, from the size at its contact frame.

### Meaning and timing

- [ ] Each gesture has one meaning and keys to its word: contact C = S + 2, early never late.
- [ ] One momentary gesture at a time, at least 4 still frames between.
- [ ] Still between gestures; calm (the exact brand mark) at both ends of every act.
- [ ] The mark returns to the exact brand mark at rest and at every act boundary.
- [ ] Every sound on its own contact frame, one event per note.

### Proof

- [ ] `slate check <act>` passes; `slate qa motion` passes on the act's trace.
- [ ] The gesture sheet reviewed at the smallest and largest sizes, full and quarter speed, with sound.

### Designing a new character

Start from research, not taste alone: a sourced survey of how voice-assistant and loader marks move (assistant rings and
glows, dot marks, loaders, orbs, cursors) is the reference material for designing a mark's gestures. The findings that
matter are in [sources](#reference-sources-for-the-motion-rules): take the principle, never the look.

---

## Reference: Durations and staggers

### The duration scale

Seconds are the source of truth; frames come from the film's own rate. A brand's scale names its tokens; the kit's
neutral scale, and what each token is for:

| Token | Seconds (neutral) | Use |
|---|---|---|
| tick | 0.20 | chip flips, checks, a dot lighting, a glyph morph committing |
| quick | 0.33 | small UI elements, icon morphs, make-room re-layouts |
| base | 0.50 | standard entrances: a line of type, a card |
| broad | 0.80 | panels, mask and band wipes, short count-ups |
| camera | 1.20 | camera push, pull and truck; shared-element carries |
| signature | 1.80 | logo construction beats, portal zooms, the big pull-back |

A brand's own values come from its product's duration tokens and its measured references (slate-brand).

**Rules**
- Exits are 0.75 times their entrance.
- Nothing moves in under 0.2 s except state flips.
- Anything longer than the signature token is a continuous camera drift or time-based data.
- At most one signature-length move per act. Signatures work because they're rare.
- Big moves run long: a page scroll at the signature length, a large rise over about 2 s, so no frame jumps far.

### Frame heuristics

At 30 fps (scale for other rates): 2 to 4 frames reads as a snap, 4 to 6 as anticipation, 6 to 10 as a settle, 8 to
12 as a quick transition, 18 to 30 as a slower entrance. A head turn in 2 in-betweens reads as a nervous twitch; a
stroke of about 10 frames reads as deliberate.

### Staggers

**Units** (the neutral law; brands set their own): per character about 0.05 to 0.067 s, per word 0.1 s, per line, list
row or card about 0.133 s, per major block 0.2 s. At a given frame rate these are whole frames.

**Caps**
- A group's total spread is at most 0.6 s and at most half of the group's own entrance duration.
- More than 8 items are grouped; they're never staggered one by one.

**What staggers:** only entrances, exits and state changes. Rest-to-rest moves travel as one piece.

**Exits** stagger in reverse at two thirds of the unit, or leave together on the exit ease when a camera move is
carrying the scene away.

### Order

- **Reading order** for type and lists.
- **Along the data's direction** for charts: low to high, baseline to latest reading, the product's own order.
- **From the focal element outward** for grids.
- **The product's own order** for rows and steps: cascade lists and rows out at about 0.2 s intervals.

### Sync

- The first element of a group lands within 2 frames of the voice's word it illustrates.
- Groups without a voice line land on the music's beat grid.

### Type

- **Hero lines** (6 words or fewer, at most two per act) write on per character; lines write on per word; lists per
  line.
- Hero text must move at least 16 px or unmask; opacity alone is flat and cheap (fine for secondary labels).
- The kit's `PerChar`, `PerWord` and `Arrive` already cap their spread; don't re-implement them.
- Lay out text with room for words that arrive later, so no make-room move is needed.

---

## Reference: Eases, springs and landing on the word

### Exact endpoints

An ease solved by bisection never returns exactly 0 or 1: it returns something like 1e-15 before a move starts. On the
first films that made every "has it started?" check open early: a bar drawn twice, copies of a later shot on screen from
the start, characters drawn at opacity 7e-15. The kit's eases return exactly 0 before and exactly 1 after; never wrap
them in your own, and never gate on `u > 0` with anything else.

**Never ease a value twice.** A mask fed through two eases filled its hollow in one frame.

### Landing a move on a word

A move "lands" when it reaches 90% of its travel (T90). Sync means the landing is within 2 frames of the voice's word:
- `landOn(word(...), 'base', 'enter')` gives a move's frame in and frame out so it lands on the word;
- `startFor(land, dur, ease)` gives the start time for a landing time;
- gate each element's entrance on the first word it shows, not a later one, or it appears already part-way through.

Word lookups (`word()`) never throw: a miss is estimated and recorded, and the hand-in check refuses the act until the
miss list is empty.

### Rest-to-rest versus entrance

- An entrance ease leaves rest at several times its average speed: a strong one covered a third of a 16-frame move in
  its first frame, so under motion blur the streak goes from nothing to long in one frame.
- An exit ease that ends fast does the same at the other end.
- So big moves (camera, carries, anything travelling far) run on the rest-to-rest ease, and characters use only curves
  with zero velocity at both ends.

### Springs settle, they don't bounce

- Good motion systems use springs that settle: Material 3 fires even its bounciest spring once per transition, and its
  effects springs never overshoot; Apple defaults to a bounce of 0, calls about 0.3 noticeable and above about 0.4
  exaggerated for UI, and starts every spring at full damping.
- Container morphs (one container changing size) use a gentle damped settle, not a bounce.
- Ease curves stop abruptly where springs keep their velocity; when two moves hand over, pass the exact velocity or
  start and end both at rest.

### Splines and chains

- Catmull-Rom through unevenly spaced keys overshoots and backtracks (a camera once drifted 274 px past its path). The
  kit's monotone spline (Fritsch-Carlson) never does.
- Chain moves so each segment starts where the last ended, at rest or at matching velocity; two moves that overlap on
  the same path sum into an overshoot. Drive them from one clock and measure the path.

### Measuring a reference's curve

Study reference films at full frame rate, fit the curve of a clean move frame by frame (`slate.motion.fit`, run by
onboarding's analysis), and keep the fit with its RMS error and the closest standard curve. A fit with high error or a
contaminated measure (blur, clipping at the frame edge) is read qualitatively, not trusted.

### The kit's names

| Function | Use |
|---|---|
| `ease(name, u)` | the brand's named ease at progress u, exact at 0 and 1 |
| `tw(t, t0, dur, name)` | a tween of film time on a named ease |
| `dur(token)`, `durFrames` | the brand's duration scale |
| `staggerAt`, `staggered` | capped staggers |
| `landOn`, `startFor`, `t90Of` | landing moves on words |
| `defineMotion({...})` | registers a move for the act's motion trace (what `slate qa motion` checks) |
| `monoSpline`, `chain` | monotone paths and chained moves |

---

## Reference: The glitch catalogue: a pre-render checklist

Thirty classes of glitch the first films shipped to a review or caught on the way, each with the rule that prevents it.
Walk the list before every render that matters; the reasons are in [anti-glitch](#reference-anti-glitch-rules).

| # | Glitch | Prevent it by |
|---|---|---|
| 1 | "Has it started?" checks open early, because an ease returned 1e-15 instead of 0 | the kit's exact-endpoint eases; never your own wrapper |
| 2 | One word lookup that throws at module load breaks every composition in a bundle | lookups that never throw; an empty miss list at hand-in |
| 3 | One half-written act breaks the shared bundle | the type-check and module-load parts of the hand-in check before any render |
| 4 | Opacity or a filter on a 3D group flattens it; a translucent card shows its thickness through its face | opacity and blur on leaves; fading cards render as one flat sheet |
| 5 | The browser's 3D sorting races with many parallel planes: a card face drops for two frames | few parallel planes; one explicit stacking order, each layer its own context; moderate render concurrency |
| 6 | Parts placed in 3D inside a tilted group z-fight under the shutter | characters drawn as one flat plane in passes |
| 7 | Surfaces crossing through other planes get sliced | nothing crosses; exits finish before entrances take the space |
| 8 | Pop-ins: a first frame mid-motion inside the frame, a mask eased twice, a shadow or colour switching at a threshold, a label reflowing in one frame | enter from off frame or from 85% scale or zero opacity; blend colour over the tick duration on a snap; continuous morphs |
| 9 | Moves that start at full speed smear one frame and go sharp the next | big moves on the rest-to-rest ease |
| 10 | Fast carries streak under the shutter (a quick carry peaked at 310 px a frame) | a speed audit per move; big moves at the camera or signature duration |
| 11 | Oscillation reads as noise | one clock, explicit phases, swells instead of wobbles, no loops |
| 12 | A spline through uneven keys overshoots and backtracks | the kit's monotone spline |
| 13 | CSS `clip-path: path()` fails silently in headless Chrome; SVG data-URI masks decode after the frame is taken | `polygon()` clips and CSS gradient masks |
| 14 | A clip path on a transformed element rides its transform | clip on untransformed full-frame wrappers |
| 15 | A zero-length dashed line still renders a dot | guard zero-length strokes |
| 16 | Video decoders crash long parallel renders | footage as JPEG sequences played from film time |
| 17 | The headless browser can't see locally installed web-kit fonts | fonts loaded explicitly; the font gate fails the render on substitution |
| 18 | Huge `translateZ` zooms rasterize badly | a 2D camera over poses, zooming in log space |
| 19 | CSS transforms change the raster (shadows by a few levels): "same picture" isn't "same pixels" | rest states drawn untransformed; contract frames pixel-diffed |
| 20 | The GPU renderer isn't bit-exact run to run (about 1 level) | "changed" only when a frame differs from both of two baseline renders |
| 21 | Temporary bundles fill the disk | the engine deletes each bundle after use |
| 22 | Impact marks still fading at a shot's end blink out on the cut | everything settles out over the last 0.6 s before a contract; the boundary check |
| 23 | Per-character type with no spread cap | the kit's capped `PerChar`; never your own |
| 24 | Parallel builders overwrite each other's scratch files | a scratch folder per builder |
| 25 | New data rendered with old code | code and data always move together; one bundle per source hash |
| 26 | A tracker hops between near-equal features, or drifts outside its reliable window | follow features, hold outside the window, a temporal median |
| 27 | Generated pixels on screen read as AI | a generation only as a matte or shape over real frames (slate-generate) |
| 28 | A second count of a value already on screen, two overlapping texts crossfading, a fade up from depth | count once; state changes snap; carries rise from below |
| 29 | Per-part character motion at small sizes reads as noise | the whole mark moves as one below its size threshold |
| 30 | Positioned type in a zero-width container wraps one word per line | `white-space: nowrap` on positioned type |

### Also check

- Text that steps a pixel at a time while shapes glide (slow drifts, the tails of eases): move with transforms, give
  moving layers the kit's raster hints, and keep one raster through a rest (slate-build, remotion-gotchas.md).
- Fine regular patterns that shimmer at the smallest delivery size.
- A UI state cut under the shutter renders as one mixed frame: expected, not a glitch.

### After the render

`slate qa glitch` scans every act for one- and two-frame glitches and skips flags within 3 frames of a planned beat;
triage what's left (slate-qa, triage.md). When one pop is found, scan the whole act frame by frame for others and fix
them together.

---

## Reference: Building a logo, and the sting

A brand's logo arriving is usually a film's first signature moment and its bookend. The kit builds it from the brand's
own SVG and a build spec, so the construction is the brand's own geometry, not a template.

### A logo build that worked

1. **Construction guides and vertex squares** drawn on the mark's own grid (dashed lines from the shapes' edges).
2. **An outline draw** of the mark.
3. **A left-to-right fill**.
4. **A line writing the name**.
5. **A held breath**: the keystone element (an accent dot, a square) hangs over its empty slot.
6. **The keystone drops into place** with a damped jolt of a few pixels (the one allowed impact overshoot), on the word.
7. **Relief rings with echoes and a contact shadow** answer the impact.
8. **Every mark settles** before the next contract frame, so nothing is still fading on the cut.

### The kit

- `LogoBuild` takes the parsed logo (paths, per-glyph boxes from the path bounds, a designated keystone, construction
  guides from the edges, the keystone's colour from the artwork) and a build spec (guides, vertices, order, keystone,
  timing). `settleBy` makes every mark finish before a given time.
- `LogoSting` is the short form for endings and stings; `stingLength()` says how long it runs.
- `logoEvents()` lists the build's beats for the sound: each construction line, the fill, the keystone's landing.
- The logo's SVG and build spec live in the brand pack (slate-brand, logo-and-motif.md).

### Rules

- **Never rotate a mark that has a fixed orientation**, even in a portal zoom.
- **Zero-length dashed strokes still render a dot**: guard them, or the build shows specks before it starts.
- **Bookends reuse the same kit component** as the opening (the same logo build with the closing's timing), never a
  redraw, so they match exactly.
- **When a shot hands from an act's own drawing to the logo build mid-shot**, the component's start state must match the
  drawing exactly (weight, caps, dot size and position); check the switch frame pixel by pixel.
- **The sonic logo mirrors the build**: each construction line clicks in, the fill is a soft swell, the keystone lands on
  one hollow knock with one small note; the ending reverses it and lands on the same knock (slate-sound).

### Checking it

Render the build's key frames as stills at full size: the first guide, the fill's midpoint, the held breath, the
landing frame, and the last frame before the contract. The landing frame should be the sound's contact frame, and the
last frame should be the contract's rest state exactly.

---

## Reference: Look development and composition

The first film looked right only after its look was built from the brand's own design system: four generic looks were
rejected first (flat shapes that didn't look polished, a 3D filament with no hierarchy, glossy futuristic glass, a
generated look that read as AI). What worked was the brand's own components and tokens, staged in space, approved from
a moving test.

### The north star

The design north star is The Browser Company's craft and warmth, channelled inside the brand's own tokens: borrow the
feeling (hand-made, warm, every move with a reason), never their brand (motion-systems.md).

### How a look is developed

1. **Start from the brand's own language**: its website's components and tokens, its app's screens, its guidelines.
   Rebuild components for film at film scale; borrow the look language, don't import website code.
2. **Moodboards, then grounded moodboards.** At least two directions, then the same directions grounded in the brand's
   kit (its real references wired in). Ungrounded moodboards drift to generic grey glass.
3. **A moving look test** of 10 to 15 seconds, with sound, in the kit's review sheets. Stills don't count: motion is
   half of a look.
4. **The owner picks.** Open questions (an opening colour, a ground) get their own side-by-side look tests; the
   coordinator confirms the call.
5. **Roll it out only after approval.** A look shown for the first time across a whole film is a look that gets
   rebuilt.

The kit's looks library is the starting point: `flat` (the default until a brand chooses), `paper-2.5d` (only for
brands whose own language is papery), `editorial` (type-led, for statements, kinetic type and stings), `blueprint`, and
the After Effects bridge's looks by name when a look calls for AE.

### Composition

- **Compose whole designed objects in generous space**: complete cards, rows and charts, with one clear focal object
  and a clear hierarchy per frame. A thin line on a big empty field reads as empty; four camera variants of a line
  close-up all failed for that reason.
- **Stage beats as objects**: one card splitting into two identical cards, the broken one falling away, rather than
  tracking close-ups of a line.
- **Every element has a job.** Cut on-screen words and decorations that don't (an unexplained lone word, a line with no
  cause, a decorative underline).
- **One focal card at a time** in a paper look: the previous card steps back into depth of field, with blur only on the
  ones that leave focus. Cards behind the focal card step back and soften with blur; they never thin out with opacity.
- **Supporting elements never cover the hero's words**; they settle around the hero, touching only its edge.
- **A spare statement shot that reads too quiet** gets a gentle camera move, not more elements.
- **First passes tend to be too flat-on and sparse.** Plan stronger camera pushes, depth and a signature before the
  first review.

### Colour and light

- **The accent colour keeps one meaning** for the whole film (the line that matters is always the accent; competing
  lines are ink, never the accent).
- **Status colours are the brand's tokens**, never traffic-light gradients or colour ramps.
- **Depth comes from a soft cast shadow that follows an element's height**, never a glow; the element keeps its colour
  and weight.
- **No radial light or edge shading on flat brand fields**: a soft light on a flat disc read as a glow.
- A signature motif keeps one colour through the film and changes form only at designed moments.

### Settling open questions

When a look question is genuinely open (which ground opens the film, how dense a chart should be), don't argue it in
words: build both in the kit's review sheet, side by side, at full size and in motion, and let the owner choose.

---

## Reference: Morphs and shared elements

A shared element persists across a scene change and keeps its identity while the world changes around it. It's how
the product itself carries objects between views, and it's the film's strongest grammar: the eye stays on one thing
while everything else changes.

### Shared elements

- **Use hand-offs the way the product carries objects between views**: a mark landing as the nav logo, a value and its
  chart carried from one screen to the next. Mirror the product's own view transitions.
- **A carried object keeps its label**: a caption travels with the value it describes across the boundary.
- **Carry by the product's own structure**: a checklist row lifts out and opens into its step (its header as the shared
  element), new steps are dealt in from one side while old ones leave the other, and one home card is the place the act
  keeps returning to.
- **Carries follow the product's own navigation order** (scroll down to the next section) rather than inventing an
  in-place transform.
- **Draw a carried element over its destination for the whole carry**, and let the destination take it over on the
  landing frame. Switching its layer mid-carry makes it slip behind, then jump in front.
- **Hand an object between components only at rest**, or on a morph's first moving frame, with one shared count
  function and one position for each label. A mid-count hand-over made a numeral jump three values and a label jump
  4 px.
- **Never duplicate an object to animate it** (a copy slides away while the original stays): move the one object.

### Morphs

- **A morph's first frame equals its source exactly**, and every property blends through it: no mid-flight flips of
  glyphs, line breaks, weight, border, font or sharpness. A chip that swapped font on its first frame popped.
- **Never crossfade one version of a card into another**: it double-exposes headers, figures and charts for several
  frames. Morph the shared elements so nothing is drawn twice.
- **Route shared elements around each other** (one goes down, then left, passing under another) so nothing travels
  through anything; the destination's own new parts arrive only once the shared parts have all but landed.
- **When many pieces morph into shapes**, their union becomes the destination shape on arrival, and the solid shape takes
  over on that frame. Never fade in a second set at the destination while the first is still moving.
- **When a small card grows into a large one**, its position leads its growth, so it grows out of where it is.
- **Animate corner radii before a split or merge**: corners that snapped from 28 px to 8 px on a split's first frame
  popped.
- **When segments merge into one shape** (a donut's groups into a ring), draw it as one continuous path once merged, so
  no seams show.
- **A container and its contents share timing.** A card that shortened on a spring while its contents travelled on
  another ease let its edge run ahead and left a chart's baseline on the bare page.
- **Open detail below an anchor without moving the anchor**, so everything attached to it stays put. Open a panel in
  its final place; don't open it centred and then glide it aside.
- **Don't drop a large object into streaming text**; carry it out beside the text so the text stays intact.

### Path morphs: the signature line

- A brand's signature line (one stroke in the accent colour at a fixed weight) can carry a whole film through its forms:
  a progress rule, a data curve, a then-to-now mark, a landscape ridge, the underline under the last line. It never
  changes colour, so the eye can follow it through every scene.
- Its weight changes in exactly one place, the reveal, and there it copies the product (drawing heavy and settling to a
  hairline).
- When the script asks for several connecting lines, draw one thread through a node on each item and on into the
  target: one signature line.
- An object that becomes a line arrives moving along that line's direction, and the line draws out of it as it shrinks
  into the line's start, so dot and line are one object.
- **Build:** shapes with equal vertex counts (resample every target to the same count), the first vertex left-most, no
  reversed winding. Path keys use the rest-to-rest ease for moving shapes and the state ease for committing state;
  draw-ons use a trim reveal on the entrance ease.

### Word and glyph morphs

Set the word as shapes (one group per glyph) and morph them into the target icon's paths on the state ease at the quick
duration, and back. Pair it with the make-room move when a new word pushes the block.

### Counting

- **Count a value once.** Never re-count from zero after it's been shown: shown, reset and counted again reads as a
  glitch. Re-count only when the value really changes, from its old value.
- Count-ups run on the entrance ease over the broad duration, with tabular figures and the product's real range; each
  figure holds at least three frames.

---

## Reference: The motion law

A brand's motion law is how everything in its films moves: a few named eases, each with one job; a duration scale; stagger
rules; morph techniques; motion-blur settings; the read-time rule; a banned list with reasoned exceptions; and a motion
check per shot. It's written once per brand at onboarding (slate-brand, look-and-motion.md), stored as data in the
brand's pack, and explained in a brand MOTION.md that records where every number came from.

### Where it lives

`brand.json` → `motion`:

| Key | What it holds |
|---|---|
| `eases` | each name maps to a cubic-bezier `[x1, y1, x2, y2]`, or `"sine"`, `"linear"` or `{"kind": "spring0"}`, with its `lineage` (where it came from) |
| `durations` | the duration scale, `{token: seconds}` |
| `staggers` | stagger units, in seconds or `{frames, at_fps}` |
| `stagger_cap` | `{seconds, fraction}`: a group's spread at most this many seconds and this fraction of its entrance |
| `exit_factor` | exits as a fraction of their entrance (0.75 is the norm) |
| `roles` | which named ease does each job: `entrance`, `move`, `state`, `exit`, `relayout` |
| `overshoot` | `{allowed, max, where}`: normally not allowed, or only for named container morphs |

The kit reads it through `motionLawFrom()` (the Python mirror is `slate.motion.law_from`), and both are held to the
same shared test vectors. A name a scene uses that the brand doesn't define is recorded, never thrown, and the hand-in
check refuses the act until it's fixed. A brand with no law gets the kit's neutral law (standard CSS curves and a plain
duration scale), recorded as a problem: it's a stand-in so placeholders render, never a brand's look.

### Anchor the law in the product

- The film's motion grammar comes from the product's own grammar (one clock, the camera as the guide, pieces carried
  between beats), so the film feels like the product, only bigger.
- **The state-change ease stays identical to the product's**, so a state change feels the same in the app and the film.
- **Film entrances decelerate harder than the product's UI entrance curve**: film travel is 5 to 20 times UI travel and
  needs a longer settle to read as calm.
- **Soften an in-out for camera moves**: a quart in-out lurches over 1 to 3 second camera moves, and good reference
  camera moves start and end at rest.
- **A website's scroll easing is a different vocabulary** from a film's law; don't reuse web-scroll eases for film moves
  without measuring.
- Measure reference films frame by frame and fit their curves (slate-brand, reference-analysis.md). Good references use
  hand-tuned curves; neither clean measurement on the first films came anywhere near After Effects' default Easy Ease.

### The jobs

- **entrance**: everything that enters (type, cards, UI arriving, count-ups, draw-ons). A fast start and a long settle.
- **move**: rest-to-rest moves already on screen: camera push, pull and truck; shared-element carries. Starts and ends
  at rest, so it never smears under motion blur.
- **relayout**: short make-room re-layouts: a new line pushes a block, a list re-sorts, a card steps aside. 0.4 s or
  less.
- **state**: state changes: a chip flips, a check lands, a toggle, a glyph morph commits, a bar segment lights.
- **exit**: anything leaving accelerates away, 25% shorter than its entrance.
- **settle spring**: one persistent container that changes size (a card growing into a page, an island opening) uses a
  damped settle, never a bounce, and only for named container morphs.

When a brief's ease note conflicts with the law's ease for that job (a make-room move written with an entrance ease),
use the law's ease and record the deviation in the act's notes.

### Standing rules

- **Intentionality**: one carrier, one idea per beat, and every move tied to the voice's word or to the idea. The
  approved first film's bar was one object carrying each act, with each phrase of the voice doing one legible thing to
  it.
- **Fewer, better moves**: don't pan out to one thing and back when one draw-back can show both.
- **Add motion purposefully**, aim for brevity and precision, and avoid anything that oscillates in a sustained way.
- **No idle wobble** unless asked. Overshoot and follow-through share physical logic and decay to a stable endpoint.
- **Linear is for time**: continuous drifts that start before the shot and end after it, and things that represent time
  (progress bars, timelines, loaders, streaming text, a constant spin on a "thinking" indicator). Never for a move that
  starts or stops on screen.
- **Crossfades** only for atmosphere inside one shot, a seam blend of at most 4 frames within the same generated shot,
  and audio.
- **Hard cuts** only when motion masks them (inside a whip or a defocus), for a few musical hit cuts on downbeats if the
  brand's law allows them, and for UI state cuts with the camera locked (the product itself changes state instantly).
- **Nothing scales from zero**: entrances start from at least 85% scale.
- **Banned by default**: glows, light leaks, flares and glitch presets; typewriter text except where the product really
  streams text (banned-moves.md).

### Motion blur

- Rendered, never faked: the renderer averages 16 sub-frame samples across a 180-degree shutter (4 in draft). Don't add
  blur in scene code.
- Generated footage gets no extra motion blur; it's baked in. Blur only the graphics over it.
- Depth of field sits on the 3D camera, with focus pulls keyed to the rest-to-rest ease.

### After Effects values

AE stores an ease as speed and influence. For a segment of duration T moving a distance Δ, the average speed is v = Δ/T:
- the out handle (x1, y1): influence = x1 × 100%, speed = (y1 / x1) × v;
- the in handle (x2, y2): influence = (1 − x2) × 100%, speed = ((1 − y2) / (1 − x2)) × v;
- AE's minimum influence is 0.1%, so a vertical tangent can't be drawn exactly.

Multi-dimensional properties take one ease per dimension, and the build reads every ease back after setting it.
AE's default Easy Ease (33.3% influence, 0 speed on both sides) is banned on anything visible: it's the look of a
template.

### The motion check, per shot

1. Every visible move uses one of the brand's named eases, or its settle spring on a named container.
2. No Easy Ease, and no linear keys on transforms outside the listed exceptions.
3. Every read-time rule holds.
4. Motion blur is on for every moving graphic and off for footage.
5. Every scene change is a carry, a portal, a mask, a whip or an allowed exception.
6. Representative frames are reviewed on contact sheets, the way the references were studied.

`slate qa motion` checks the traces; a person checks the frames.

---

## Reference: Motion systems: the north star and the alternatives

A brand's motion law comes from its own product and its measured references (motion-law.md). These systems are where
to look when a brand has no motion language of its own, when a brand is built on one of them, and for the feeling the
films aim for.

### The north star: The Browser Company's craft

The design north star is The Browser Company's craft and warmth: interfaces with personality, physical and springy
motion that still settles, and animation that feels made by hand, where every move has one reason and lands with its
sound. Take the **feeling**, expressed inside the brand's own tokens. Never take their brand: no copied marks, colours,
type or signature animations.

### Material 3

For brands built on Material, or wanting its feel.

| Duration tokens | ms |
|---|---|
| short 1 to 4 | 50, 100, 150, 200 |
| medium 1 to 4 | 250, 300, 350, 400 |
| long 1 to 4 | 450, 500, 550, 600 |
| extra-long 1 to 4 | 700, 800, 900, 1000 |

| Easing | cubic-bezier |
|---|---|
| standard | (0.2, 0, 0, 1) |
| standard decelerate | (0, 0, 0, 1) |
| standard accelerate | (0.3, 0, 1, 1) |
| emphasized decelerate | (0.05, 0.7, 0.1, 1) |
| emphasized accelerate | (0.3, 0, 0.8, 0.15) |

The emphasized curve is really a path, not one bezier. Material 3 Expressive uses springs (stiffness and damping):
spatial springs damp at 0.9 (default about 700, fast about 1400, slow about 300 stiffness), and effects springs at 1.0,
so effects never overshoot. Its loading indicator adds exactly a quarter turn per morph on one spring, riding a slow
spin, so any cycle can end on the rest shape.

Film travel is longer than UI travel: scale Material's durations up for film-sized moves and soften the settle, and
measure the result against a reference.

### IBM Carbon

Carbon splits motion into **productive** (efficient UI moves) and **expressive** (prominent moments). In a film, that
maps cleanly: **product UI shown inside the film moves productively; the film's own big moments move expressively.**

| Duration | ms | Use |
|---|---|---|
| fast-01 | 70 | micro-interactions |
| fast-02 | 110 | fades |
| moderate-01 | 150 | the default |
| moderate-02 | 240 | expansion, toasts |
| slow-01 | 400 | large expansion |
| slow-02 | 700 | hero moments, dimming |

| Easing | Productive | Expressive |
|---|---|---|
| standard | (0.2, 0, 0.38, 0.9) | (0.4, 0.14, 0.3, 1) |
| entrance | (0, 0, 0.38, 0.9) | (0, 0, 0.3, 1) |
| exit | (0.2, 0, 1, 0.9) | (0.4, 0.14, 1, 1) |

### Apple's Human Interface Guidelines

- Add motion purposefully, supporting the experience without overshadowing it; gratuitous animation can leave people
  feeling disconnected or physically uncomfortable.
- Make motion optional, don't rely on it alone to communicate, and let people cancel it.
- Aim for brevity and precision in feedback motion.
- In visionOS, avoid sustained oscillation (especially around 0.2 Hz) and motion at the edges of the field of view.
- Springs: bounce 0 by default, about 0.3 is noticeable, above about 0.4 feels exaggerated for UI.

### Principles to cite

Disney's twelve principles (from *The Illusion of Life*) and the twelve UX in Motion principles (easing, offset and
delay, parenting, transformation, value change, masking, overlay, cloning, obscuration, parallax, dimensionality, dolly
and zoom). Only easing carries over directly from character animation to interface motion. How each applies:
[principles](#reference-animation-principles-applied-to-film-and-interface-motion).

### Frame heuristics

At 30 fps (scale for the film's own rate): 2 to 4 frames reads as a snap, 4 to 6 as anticipation, 6 to 10 as a settle,
8 to 12 as a quick transition, and 18 to 30 as a slower entrance. Use them to sanity-check a brand's duration scale, not
to replace it.

### Choosing

| The brand | Start from |
|---|---|
| Has product motion tokens (CSS easing variables, SwiftUI springs) | its own tokens, scaled for film (slate-brand) |
| Is built on Material | Material 3, scaled for film |
| Is an enterprise product with no motion language | Carbon: productive for product UI, expressive for moments |
| Is an Apple-platform app | its SwiftUI springs (response and damping) and the HIG's restraint |
| Has nothing at all | the kit's neutral law as a stand-in, then onboarding writes a real one |

Whatever the source, the brand's law still names its eases by job, caps its staggers and bans the same things
(motion-law.md, banned-moves.md).

---

## Reference: Animation principles, applied to film and interface motion

### The twelve principles

Thomas and Johnston's twelve, from *The Illusion of Life*: squash and stretch, anticipation, staging, straight-ahead and
pose-to-pose, follow-through and overlapping action, slow in and slow out, arcs, secondary action, timing,
exaggeration, solid drawing, appeal. How they apply in a Slate film:

| Principle | Applied |
|---|---|
| **Timing** | Timing gives movement meaning. A turn with two in-betweens reads as a nervous twitch; a stroke of about 10 frames reads as deliberate. |
| **Anticipation** | Short, in one direction, and never longer than the action it prepares: a tuck before a turn, an inhale before a greeting, a lift before a flight. |
| **Slow in, slow out** | Every segment leaves and arrives at rest (or hands its exact velocity on). |
| **Arcs** | Flights travel on arcs, entrances can spiral in, turns carry parts on circles. |
| **Follow-through and overlapping action** | From whole-frame trails (a spread trailing its growth by 2 frames), never from a wobble on every beat. |
| **Secondary action** | Supports the main move and never competes with it. |
| **Staging** | One clear focal object per frame; the camera and composition point at it. |
| **Squash and stretch** | Not on paper-like marks: paper doesn't squash, and parts keep the brand's shape. |
| **Exaggeration** | Rarely. Delight means more from something that never exaggerates. |
| **Appeal** | The feeling of craft: hand-made, every move with a reason. |

### UX in Motion's twelve

Issara Willenskomer's twelve principles for interface motion: easing, offset and delay, parenting, transformation,
value change, masking, overlay, cloning, obscuration, parallax, dimensionality, and dolly and zoom. Motion supports
usability through expectation, continuity, narrative and relationship.

The caution that matters: **only easing carries over directly** from character animation to interface motion. The rest
of the twelve animation principles need translating, not copying.

| UX principle | In a Slate film |
|---|---|
| Offset and delay | whole-frame staggers, capped, in reading or data order |
| Parenting | a container parents its contents; they share its timing |
| Transformation | a shared element changes form without losing identity |
| Value change | a count-up counts once, from its real value |
| Masking | reveals through a shape, never particles |
| Obscuration | depth of field steps back what isn't the focus |
| Parallax | layers at different depths drift at different rates, from one clock |
| Dimensionality | tilt-to-flat and paper depth, one 3D object at a time |
| Dolly and zoom | one camera move per act; bring a card forward rather than pushing in |

### Checking a move against the principles

For any move that matters, step through: its start, its anticipation, its fastest frame, any overshoot, its settle and
its last frame, with motion blur at delivery settings. If any of those frames looks wrong alone, the move is wrong.

### Restraint

Knowing when not to move matters as much as moving. Even audio-first products script their states rather than moving
constantly; a film that holds still before its big moment makes the moment land.

---

## Reference: Read time

Text on screen is only useful if it can be read. The rule is counted from the frame the text has **fully settled** (the
end of its entrance), not from its first frame.

### The rule

- **Hold at least max(1.5 s, 0.4 s + 0.3 s per word).** That's about 200 words a minute, plus time to find the text.
- **Numbers and statistics:** at least 2 s after the count lands.
- **Labels of three words or fewer:** at least 1 s.
- **Lines the voice also says:** on screen at least as long as the voice takes to say them, and never gone before the
  voice finishes them.
- **Density:** at most 12 on-screen words per shot; body text at least 28 px at a 1080-line frame; on-screen text about
  40% of what the voice says in the shot, or less.

A cross-check for supers: a slow reader at about 200 words a minute should be able to read it twice (hold at least
max(1.2 s, words × 0.3 s × 2)). When the two disagree, take the longer hold. Captions have their own rule: at most 17
characters a second, 2 lines of 42 (slate-voice).

### Where it's checked

1. **The script** (`slate script build`): the planned hold, from the shot's length minus its entrance and exit, against
   the rule, per shot (slate-story).
2. **The rendered film** (`slate qa readtime`): OCR reads the picture every 0.25 s and times each on-screen statement
   from the frame it's fully built (in order, with its last word) to the frame it's gone. This catches what the script
   can't: a camera that leaves early, a statement that builds slowly, text that's too small to read.

Logo lockups and stylized marks are left to the contact-sheet review: OCR misreads them.

### Fixing a short hold

- **Extend the settled hold inside the shot**: start the next camera move later, or land the text earlier within its
  shot. Don't move word timings or shot boundaries; they're the voice's clock.
- When you retime one move to fix read time, choose its new start and ease so every downstream key position stays
  identical (the camera still reaches the next fold exactly where it did), and nothing after it moves.
- If the hold can't grow, cut words: the density rule is usually what's really broken.
- Run a read-time audit on the first full preview, before the look is locked: moving a line earlier is cheap then and
  expensive after the renders.

### Text that moves

- Don't land a line of type while the layout around it is still moving; the clock starts when everything has settled.
- Small type rushing past a moving camera can't be read and strobes; land detailed content only once the camera has all
  but stopped.
- A statement that rides a camera move across a cut must stay legible across the cut (check the strip of frames either
  side).

---

## Reference: Safe areas, legibility and accessibility

A frame that looks right on the editing screen can lose its text under a platform's buttons, flash too fast for some
viewers, or be unreadable on a phone. These rules keep every frame safe wherever it's shown.

### Title-safe and action-safe

- **Action-safe** is the central 93% of the frame; **title-safe** the central 90% (SMPTE ST 2046-1 and EBU R 95). At a
  1920 × 1080 frame, title-safe is 1728 × 972, 96 px in from each side and 54 px from the top and bottom; scale with the
  film's own size from film.json.
- Keep text and anything that must be read inside title-safe; keep essential action inside action-safe.

### Platform safe zones

Vertical platforms put buttons, captions and profile details over the frame. Each format file carries its platforms'
safe zones (fractions of the frame from each edge), and film.json inherits them.
- Keep text and faces inside the safe zones for every platform the film is going to.
- Burned-in captions sit inside them too, above the lower overlays.
- `slate qa access` checks 9:16 films' text against the platforms' zones by OCR (UNCHECKED without OCR), and the contact
  sheet shows the zones for review.
- A derived film (a new aspect) re-stages its layout for its own safe zones; it never just crops (slate-finish).

### Legibility

- Body text at least 28 px at a 1080-line frame (the kit's type scale does this, as fractions of the short side).
- Text contrast from the brand's colour pairs: at least 4.5:1 for body text and 3:1 for large text. The kit derives
  missing roles with contrast guaranteed, and `slate qa access` checks the brand's pairs.
- Type over footage stays legible with a soft brand-colour grade behind it, never a box.
- Tabular figures on every number that changes, so digits don't jump sideways.
- Close-ups never crop text mid-line.

### Flashes and motion sensitivity

- At most three flashes a second (WCAG 2.3.1, general and red flashes). `slate qa access` checks it.
- A film embedded on a web page and playing longer than 5 seconds needs a way to pause or stop it (WCAG 2.2.2): that's
  the page's job, but say so when delivering a hero loop.
- Avoid sustained oscillation and fast motion at the edges of the frame.

### Captions

At most 2 lines of 42 characters, 17 characters a second, at least 1 s on screen, never overlapping, word for word the
script (slate-voice builds them; `slate qa captions` checks them).

### Checking

Review the contact sheet with the platform zones overlaid, at the smallest size the film will be shown. What's readable
on a laptop at full size can vanish on a phone.

---

## Reference: Staging signature moments

Each act has one signature moment (slate-story chooses it). This is how to stage it so it lands: stillness before it,
one clean landing, an echo after, and the sound on the same frame. Stay inside the brand's language: no glows, flares,
particles or bounce.

### Anatomy of a landing

A hero moment needs more than a correct animation:
1. **A held breath**: everything still, often an empty slot waiting, the music stopped dead.
2. **The drop**: the key mark lands, on the word, on the brand's own ease.
3. **An impact that echoes**: a ripple through the ground, a ring, hairline echoes, the construction grid flaring once.
4. **A text entrance worthy of it**, landing after the impact, not on top of it.
5. **The camera exhales**: a small release after the hit.

The ending can replay the same component as a bookend (logo-build.md).

### A landing in a paper look

For a papery brand's biggest moment: a held breath with everything still; a press down; on the landing, focus snaps
sharp and the shadow merges; an embossed ripple (a lit crest and a soft trough, no light, no glow) runs through the page
and lifts the line it crosses; a hairline echo ring expands and fades; the page gives by well under 1% and recovers with
no bounce; and the camera exhales. A pressed object can leave a trace where it was pressed (a shallow dish in the page),
so the page remembers the moment.

### Other patterns

- **A signature move uses the act's one signature duration** and carries follow-through: the leading part first, the
  rest a beat behind, the camera moving with it.
- **An impact can be a small, damped camera hit**, with the lines shuddering at the stress point, once per act.
- **Land the impact at the end of a sentence**, so its sound and ripple play in the voice's pause.
- **A world can dissolve into the ground and leave its imprint**: the far distance mists away while the words hold, then
  the ground, leaving a shallow deboss with the signature line on its rim; then the imprint relaxes flat.
- **When a character cites data**, the data travels from its source into the sentence exactly as the voice reaches its
  words, after selection marks wipe around the facts it will cite.
- **To show that something won't be stated**, make it a ghost that never lands: faint and blurred in a dashed slot,
  digits rolling without settling, a thread reaching for a source, finding none and pulling back. The sound gives it no
  landing.
- **For a weighty line**, hold everything still (camera and character) except a slow focus pull that leaves one element
  standing alone.

### Timing it

- Give the moment room: still frames before (the held breath) and a settle after, before anything else moves.
- Everything decorative from the impact settles out before the act's contract frame (at least the last 0.6 s), or it
  blinks out on the cut.
- The sound's one big landing (slate-sound) and the picture's contact frame are the same frame.

### Reviewing it

Review the moment on its own, at full speed and quarter speed, with sound, against the visionary bar: would the owner
say they've never seen that? A correct but ordinary moment is sent back, however clean it is.

---

## Reference: Sources for the motion rules

The motion rules cite their research by label. Read the sources yourself when a rule needs defending or updating;
paraphrase them, and quote only briefly and exactly.

### Principles and systems

- **[Disney 12]** Frank Thomas and Ollie Johnston, *The Illusion of Life* (1981): the twelve basic principles of
  animation. Overview: https://en.wikipedia.org/wiki/Twelve_basic_principles_of_animation
- **[UX in Motion]** Issara Willenskomer, the twelve principles of UX in motion; and his note that only easing carries
  over directly from character animation to interface motion:
  https://blog.adobe.com/en/publish/2016/11/08/redesigning-the-12-principles-of-animation-for-motion-design
- **[M3 tokens]** Material 3 motion tokens (durations, easing, springs), in the material-web source:
  https://github.com/material-components/material-web
- **[M3 loader]** Material 3's loading indicator (quantized turns on one spring), in the androidx source:
  https://github.com/androidx/androidx
- **[Carbon]** IBM Carbon's motion tokens (productive and expressive):
  https://github.com/carbon-design-system/carbon/blob/main/packages/motion/src/dtcg/motion.json
- **[HIG]** Apple's Human Interface Guidelines, Motion:
  https://developer.apple.com/design/human-interface-guidelines/motion
- **[WWDC23]** Apple, "Animate with springs": https://developer.apple.com/videos/play/wwdc2023/10158/
- **[WWDC18]** Apple, "Designing Fluid Interfaces": https://developer.apple.com/videos/play/wwdc2018/803/

### Multi-part marks and loaders

- **[SpinKit]** Tobias Ahlin's SpinKit: the circle spinner's delays in exact steps of cycle over parts.
  https://github.com/tobiasahlin/SpinKit
- **[Replicator]** Core Animation's replicator layer: an instance delay of duration over count.
- **[Follow-the-leader]** After Effects expressions reading each layer's value at time minus index times delay (the
  classic rig, as documented by Dan Ebberts).
- **[Metachronal]** Metachronal rhythm: a fixed lag between neighbours, as in cilia and legs.
- **[Common fate]** Gestalt common fate: parts moving with the same timing read as one object.

### Perception and timing

- **[Flicker]** Temporal contrast sensitivity peaks near 8 Hz, which is why a 4 Hz wobble (blur pulsing at 8 Hz) reads
  as flicker.
- **[Speech envelope]** Speech loudness modulates mostly between 2 and 8 Hz (Ding and colleagues, 2017), which is why a
  character is never driven by the voice's loudness.
- **[Gesture timing]** Ye, McQueen and Bosker (2025), summarizing Leonard and Cummins and Roustan and Dohen: a gesture's
  top speed coincides with the stressed vowel, and its apex falls inside the stressed syllable.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC12331874/
- **[McNeill's rule]** Nirme, Gulz, Haake and Gullberg (2024): a gesture precedes or ends at, but doesn't follow, the
  stressed syllable; gestures moved 500 ms early didn't hurt recall, 500 ms late did.
  https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2024.1345906/full
- **[AV sync]** ITU-R BT.1359 (viewers detect sound from about 45 ms early to 125 ms late) and EBU R37 (+40 / −60 ms).

### Read time, safe areas and accessibility

- **[Read it twice]** The practitioner rule that supers stay up long enough for a slow reader to read them twice.
- **[Subtitles]** Broadcaster and streaming timed-text guides: about 160 to 180 words a minute, and at most 17 to 20
  characters a second.
- **[Safe areas]** SMPTE ST 2046-1 and EBU R 95: action-safe 93%, title-safe 90%. https://tech.ebu.ch/publications/r095
- **[WCAG]** WCAG 2.2: 2.3.1 (three flashes) and 2.2.2 (pause, stop, hide).
  https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide.html

### How good marks move (studied for character design)

Voice-assistant and loader marks were studied for how they move, not copied: a ring that moves outward to respond and
inward to listen; dots rooted in consistent paths and timing; a breathing flower driven by one container animation; an
assistant cursor that pairs every move with a matched sound; tempo carrying meaning (a fast pulse for an error, a slow
one for do-not-disturb); scripted states rather than live loudness; stillness as a design decision. Take the principle,
never the look.

---

## Reference: Techniques

Moves that worked on the films, generalized. Each is a way to show one idea clearly; none is a template to apply
everywhere.

### Clarity moves

- **Tilt-to-flat resolve.** UI enters tilted (about 30 degrees on X, depth of field on) and lands flat and sharp as the
  idea lands. Use it as the beat of clarity.
- **Component zoom, data, pull-back.** Push into one card, let its chip snap and its numbers count, then pull back to
  the whole page or product. A pull-back from one detail to the whole product reveals context.
- **Lift a key value off its surface** as its own object: hand it to a screen-space copy on the same pixels, bring it
  forward with a soft shadow, and quiet the surface behind under a light wash so its statement reads cleanly.
- **Frame brackets** (when the brand has them as an icon) crop into a detail like a viewfinder, then open back out.

### Staging the voice

- **Stage only what the voice names**: three spoken items get three taps, not twelve.
- **Stage the script's spatial words literally** when you can ("underneath" means pages slide out from under).
- **Show an analysis step as the signature line reading the data**, so the pattern has a visible cause. Decoration
  without a cause goes.

### Reveals

- **Reveal a field of elements with a mask morph, not particles**: every element sits on its grid, appears from at
  least 85% scale as the mask clears it, and only elements wholly inside the final shape exist, so nothing is left
  half-faded at rest.
- **Words can exist before they're seen**: a blind deboss in the ground (shade on the upper edges, a lit lower edge, no
  ink) that inks in letter by letter as the voice says the word.
- **Show the world as many quiet peers**, nearest ring first, with ours the only one in the accent colour; the peers
  carry no names or numbers.

### Stress and contrast

- **Show stress on footage as an atmosphere change** (a shadow front masked to the land, the sky kept clean), never as a
  cover over the image.
- **A stress moment can be a passing band** that re-renders everything inside it in the inverse palette, then leaves,
  returning the scene to normal.
- **Stage an analogy as two parallel objects built alike** (header, number, curve, caption) side by side, joined by the
  signature line across both.

### Per-character type

For hero lines only (6 words or fewer, at most two per act): each character rises a little (about 24 px at a 1080-line
frame), fades in and un-blurs on the entrance ease, staggered by the character unit. Lines go per word, lists per line.
The kit's `PerChar`, `PerWord` and `Arrive` do this with the stagger cap built in.

### Count-ups

Always on the entrance ease over the broad duration, with tabular figures, and only real values in the product's real
range. Never linear. Each figure holds at least three frames so the eye can read the change.

### Product UI in motion

Load product surfaces the way the product loads them: the curve draws, the numeral counts, the marker settles, the
statement lands. Highlight items on their spoken word with the product's own hover or selection state. The rules for
product UI are in slate-build (app-ui.md).

---

## Reference: Transitions

Every scene change is a **carry** (an element continues across), a **portal**, a **mask**, a **whip** (a motion-masked
cut), or a documented exception. Hard cuts and crossfades between shots aren't allowed by default: hard cuts break the
carried-pieces grammar and read as a slideshow; crossfades double-expose type into mud and hide motion.

### Carries

- The default: something the viewer is already watching continues into the next shot
  ([morphs and shared elements](#reference-morphs-and-shared-elements)).
- Hand-offs inside one builder's span are carries per the script's transition column, with no pop or cut.
- Move the least possible: a new section rises as an edge over a still page instead of scrolling the whole page, so
  only the edge travels.
- A new section can enter like the next sheet of paper sliding over the last, with its shadow on the page above its
  edge.

### Whips

- Blur whips (defocus or motion-blurred whips that carry the cut) are the only kind of cut the carried-pieces grammar
  allows by default; the cut happens inside the blur, where the eye can't see it.
- Hold the frame still for about half a second before a whip, so the whip reads as deliberate.
- A whip out mirrors the next act's whip in: the same direction and a matching rotation, over the last few frames
  (6 frames on the first films, with a real rotation), blurred by the real sub-sampled render, never an effect blur.
- A whip so fast it doubles an element in the blur is a defect: re-time the beats so the carry can be a gentle glide.

### Portals and masks

- **A brand mark as a portal** between acts: it scales from lockup size through the frame on the rest-to-rest ease at
  the signature duration, and its window shape becomes the next act. At most three times in a film, only at act breaks.
- A portal zoom targets a clean area of the object, so it lands on bare ground.
- **Never rotate a mark with a fixed orientation**, even in a portal zoom.
- **Reveal footage by parting the page** along a line, like paper: two sheets slide apart, each with an edge and a soft
  shadow on the footage underneath. No crossfade.
- A window growing out of a thin element reads as a white box on the ground; open a section by pulling a sheet away with
  a moving, shadowed edge instead.
- Brand icons such as frame brackets can crop into a detail like a viewfinder, then open back out.

### Rack focus

A depth-of-field rack between focal elements is a lens effect: allowed, and never counted as a crossfade.

### The reasoned exceptions

| Exception | When |
|---|---|
| Motion-masked cut | inside a whip or a defocus: it counts as a transition |
| Musical hit cuts | a few, on downbeats, only if the brand's law allows them |
| UI state cut | a tab switch in the product with the camera locked, because the product changes state instantly; under sub-frame motion blur it renders as one mixed frame, which is expected, not a glitch |
| Crossfade | atmosphere inside one shot; a blend of at most 4 frames hiding a seam in the same generated shot; audio |

### Act boundaries

Acts meet on contract frames: a named rest state both sides render exactly, held still for at least 6 frames each side,
with everything decorative settled out over the last 0.6 s before it (slate-build, contracts.md). A transition inside
an act is designed; a transition between acts is a contract.
