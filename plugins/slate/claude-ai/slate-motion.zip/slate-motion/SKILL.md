---
name: "slate-motion"
description: "The motion law and motion craft for Slate films. Covers named eases by job, the duration scale, staggers, landing moves on the voice's words, look and motion development, camera, transitions, morphs and shared elements, signature moments, a brand mark moved as a character, the anti-glitch rules and glitch catalogue, read time and safe areas, with The Browser Company's craft as the north star (the feeling, never their brand). Use when designing, building, reviewing or fixing how anything moves in a Slate film, writing a brand's motion law, animating a brand mark or motif as a character, or chasing a jitter, pop, strobe or flicker."
---

> Knowledge-only edition of Slate's `slate-motion` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-motion

Motion is where a film feels made by hand or made by a template. Slate's films earned their motion the hard way: a
motion law measured from reference films and the product's own tokens, a catalogue of every glitch that shipped to a
review and why, and a character spec rewritten after "it's super glitchy". This skill carries all of it, generalized
for any brand.

The law is data, the kit enforces it, and a gate checks it:
- the brand's **motion law** lives in its pack (`motion` in brand.json, written at onboarding);
- the Remotion kit moves things only by the law's names and exact-endpoint eases, and records every move;
- `slate emit-events` writes each act's motion trace, and `slate qa motion` checks it.

Read `slate history context --topic motion` when a private history is selected. Preserve what each correction was
about: jitter, depth conflicts and unreadable text are defects; fast travel, flutter, bounce and stillness are
creative choices. The values below are starting presets. The current brief can choose a different grammar; record
that choice in the brand's motion data and measure the result against it. Do not turn one film's fixes into universal
bans or smooth away the energy the requester wanted to keep.

## 1. The north star and the bar

- **The current brief's references govern the creative direction.** Study their sequence, construction and iteration
  history, then pursue that level of craft inside the current brand. The references below are useful starting points;
  they do not replace the requester's selected benchmark or prescribe one appearance for every film.
- **The Browser Company's craft and warmth** is the north star: motion that feels hand-made, where every move has one
  reason and lands with its sound. Borrow the feeling, never their brand; express it inside the brand's own tokens.
- **The visionary bar:** beautiful enough to make someone cry. One signature moment per act is a useful starting
  structure, not a quota for every film (slate-story chooses the structure, this skill stages it).
- **Intentionality:** make the viewer's attention and the movement's purpose clear. Earlier product films used one
  carrier per act and one idea per beat; the current brief may call for several voices, sustained motion or a still
  frame. Preserve the requested energy while keeping words, objects and transitions legible.

## 2. The motion law

Every brand's law names its eases by **job**. The kit also supports known curves by motion class; the trace must use a
curve the gate recognizes and match its measured shape. These role shapes are a starting recipe:

| Job (kit role) | What it moves | Shape |
|---|---|---|
| entrance | type, cards, UI arriving, draw-ons, count-ups | fast start, long settle |
| move | rest-to-rest moves: camera push, pull and truck; carries | starts and ends at rest |
| relayout | short make-room re-layouts | quick, soft; earlier films used 0.4 s or less |
| state | a chip flips, a check lands, a toggle | the product's own state-change ease, unchanged |
| exit | anything leaving | accelerates away; the starter uses 0.75 times its entrance |
| settle spring | container morphs and gestures where the brief calls for it | a controlled settle; bounce is a deliberate choice |

The starting duration scale uses tick, quick, base, broad, camera and signature. Earlier product films used exits at
0.75 times their entrance, a 0.2 s floor outside state flips, at most one signature duration per act, and a stagger
spread of at most 0.6 s and half the entrance. Choose the brand's scale and caps for the current direction; a signature
count is enforced when its duration token declares `max_per_act`. Current QA restricts stagger groups to entrance,
exit and state roles. A move illustrates a word by landing (90% of its travel) within 2 frames of that word: the kit's
`landOn` and `startFor` do the maths. A brand with no law draws with the neutral law until onboarding writes one, and
the kit records the missing law as a problem.

The current brief and authorized feedback govern creative revisions. Keep the original, the feedback and the revised
law together. A requested exploration does not need another approval of the same creative choice; the resulting
evidence and any separately required source or delivery approval still have to be current.

In depth: [motion law](#reference-the-motion-law), [eases](#reference-eases-springs-and-landing-on-the-word),
[durations and staggers](#reference-durations-and-staggers).

## 3. Look and motion development

Study a reference as a sequence. Name its rendered version and visible time window, the object that persists, and
how its geometry, content, camera and sound reach the next state. Read the actual source when available, distinguish
implementation evidence from notes, and record source-to-render gaps. Transfer the mechanism into this brand's own
design language. A beautiful final frame is useful, but its transitions and the feedback that shaped them explain
why the film works. See [morphs and shared elements](#reference-morphs-and-shared-elements).

A brand's look is built from its own design language (its components, tokens and product motion), never from generic
prompts, and it's approved from a **moving** 10 to 15 second test with sound: stills don't count. The kit's looks
library starts it (`flat` by default; `paper-2.5d` only for brands whose own language is papery; `editorial`;
`blueprint`; the After Effects bridge's looks by name). Onboarding runs this once per brand (slate-brand); a film's own
look test happens only when the brand's look isn't approved yet.

The earlier composition recipe used whole designed objects in generous space with a clear focal object. Choose the
composition for this film's purpose; sparse, dense and abstract frames can all work when attention is clear. The
earlier thin-line test read as empty because it did not carry its idea. See [look development](#reference-look-development-and-composition).

## 4. The craft, move by move

- [camera](#reference-camera): choose drift, travel or stillness for the idea; preserve exact contract frames.
- [transitions](#reference-transitions): carries, portals, masks, whips, cuts and crossfades have different uses;
  follow the film's chosen grammar and preserve its required handoffs.
- [morphs and shared elements](#reference-morphs-and-shared-elements): one object across a cut, keeping its label.
- [techniques](#reference-techniques): tilt-to-flat, component zoom and pull-back, mask reveals and mask morphs, paper
  techniques (ink, stamps, page turns), per-character type.
- [physical books](#reference-physical-books-a-carrier-with-memory): one object through cover, contact, comparison and audience views,
  hinged paper, continuous shadows and settled read holds.
- [continuous evidence](#reference-carry-one-idea-through-changing-forms): crowds becoming data, weighted objects becoming
  navigation, distance-paced curves and closing objects that retain their history.
- [signature moments](#reference-staging-signature-moments): staging the held breath, the landing and its echo.
- [logo build](#reference-building-a-logo-and-the-sting): constructing a mark, and the bookend that replays it.

## 5. A brand mark as a character

The kit's mark-character method uses a small gesture vocabulary and a pose that's a pure function of the film frame.
Its rig parts use whole-frame phases (unison, pairs or a wave). Current motion QA requires symmetric rig waveforms and
a loop period of at least 16 frames and no faster than 1.9 Hz; a brand can require a slower loop. Default rig limits are
30 px a frame and 8 px a frame squared at a 1080-line frame, with supported brand speed overrides. The earlier paper
character recipe starts and ends at rest, draws flat in fixed sheets and returns to the unchanged mark between
gestures. These are useful choices for that character, not a universal requirement that every character stay quiet.
The kit's `MarkCharacter`, `MotifMark` and `gesture()` implement this method; a different requested character still
needs truthful traces and the current technical checks. Full method: [character and motif motion](#reference-a-brand-mark-as-a-character-the-method);
one-page checklist: [character motion](#reference-character-motion-the-one-page-checklist).

## 6. Anti-glitch

Most glitches that reached a review came from a handful of causes:
- a move that starts at full speed can smear on one frame and go sharp on the next under motion blur: a rest-to-rest
  ease or a velocity-matched handoff often fixes the discontinuity;
- periodic motion can make shutter sampling pulse: test intentional flutter or idle motion in the final render and
  remove visible flicker without deleting the gesture;
- sub-frame staggers put parts at different shutter phases: offsets are whole frames;
- things that pop: an entrance starting part-way into the frame, a mask eased twice, a colour or shadow switching at a
  threshold, a label reflowing in one frame;
- planes that cross or share a depth, and slice or z-fight under the shutter;
- text that snaps to whole pixels while shapes glide, reading as jitter.

Run the [glitch catalogue](#reference-the-glitch-catalogue-a-pre-render-checklist) as a checklist before every render; the reasons and fixes
are in [anti-glitch](#reference-anti-glitch-rules), and the contextual concerns and current checks are in
[banned moves](#reference-motion-choices-and-the-defects-to-watch).

## 7. Read time and safe areas

- The starting read-time policy gives a statement at least max(1.5 s, 0.4 s + 0.3 s per word) once fully built;
  format and script settings can choose its reading policy. Numbers still need 2 s after they land. Fix a short hold
  inside the shot, or revise the script and rebuild its clock when an authorized timing change is needed
  ([read time](#reference-read-time)).
- Text stays inside the title-safe area and each platform's safe zones; body text at least 28 px at a 1080-line frame;
  text contrast from the brand's colour pairs; no more than three flashes a second ([safe areas](#reference-safe-areas-legibility-and-accessibility)).
- Smaller text is only for labels of three words or fewer, and type size is judged by its measured cap height at full
  resolution, never by the font size in code.

## 8. Other motion systems and principles

Material 3, IBM Carbon and Apple's HIG are alternative motion systems: Material 3 for brands built on Material, Carbon's
productive curves for product UI shown inside a film and its expressive curves for the film's own big moments, Apple's
guidance for restraint. The twelve animation principles and UX in Motion's twelve apply with one caution: only easing
carries over directly from character animation to interface motion. See [motion systems](#reference-motion-systems-the-north-star-and-the-alternatives),
[principles](#reference-animation-principles-applied-to-film-and-interface-motion) and [sources](#reference-sources-for-the-motion-rules).

## 9. Checking motion

Technical checks establish the properties they measure, including truthful content, valid timing, stable geometry
and legibility. They do not establish beauty. Review a moving example of the intended transformations with sound in
the target composition, and use the requester's specific feedback to improve the next version. Preserve comparison
versions and feedback, then extend successful choreography across the requested outputs with staging suited to each
aspect and duration. This is creative iteration within the authorized brief, not an additional approval gate.

- `slate emit-events` writes each act's visual events and motion trace; `slate check <act>` is the builder's hand-in
  check; `slate qa motion` checks every trace: the brand's eases, durations and stagger caps, entrances from at least
  85% scale, speed limits by what moves (at 1080 lines: a rig part 30 px a frame and 8 px a frame squared, a UI element
  60 and 16, a carried page, card or camera 170 and 45; a whip past those goes to a person), no loop faster than a
  16-frame period or faster than 1.9 Hz, symmetric mark rigs, plus a pixel cross-check for fast motion the trace doesn't
  explain. Brand speed limits can replace the defaults; the entrance scale floor and loop and rig checks remain
  current technical constraints. Read [motion law](#reference-the-motion-law) for the exact supported controls.
- **Tell the gate what moves.** A traced move names its `class` (rig, ui, carry or whip) when its name doesn't say it,
  and declares an exemption (`exempt`: a reading sweep, or a line whose steadiness is the meaning) with its `reason`.
  Other deliberately linear properties belong in the brand's `linear_props`; naming a linear ease alone is not enough.
  Long carries and camera drifts can use the kit's `even` curve (a third of the travel in each third of the time),
  which the gate knows by name. See [eases](#reference-eases-springs-and-landing-on-the-word).
- `slate qa stability` watches every act's render for judder a viewer feels before they can name it: pops, whole-pixel
  snaps, shakes, reversals, flicker and shimmer (slate-qa).
- `slate qa glitch` scans the rendered acts for one- and two-frame glitches, skipping flags within 3 frames of a planned
  beat; triage the rest (slate-qa).
- Look as well as measure: stills at the changed frames, contact sheets, a preview at quarter speed with sound. For any
  move, check its start, anticipation, fastest frame, overshoot, settle and last frame with motion blur at delivery
  settings.

## References

- [motion-law](#reference-the-motion-law) · [eases](#reference-eases-springs-and-landing-on-the-word) · [durations-and-staggers](#reference-durations-and-staggers)
- [look-development](#reference-look-development-and-composition) · [camera](#reference-camera) · [transitions](#reference-transitions)
- [morphs-and-shared-elements](#reference-morphs-and-shared-elements) · [techniques](#reference-techniques)
- [physical-books](#reference-physical-books-a-carrier-with-memory)
- [signature-moments](#reference-staging-signature-moments) · [logo-build](#reference-building-a-logo-and-the-sting)
- [character-and-motif-motion](#reference-a-brand-mark-as-a-character-the-method) · [character-motion](#reference-character-motion-the-one-page-checklist)
- [anti-glitch](#reference-anti-glitch-rules) · [glitch-catalogue](#reference-the-glitch-catalogue-a-pre-render-checklist) · [banned-moves](#reference-motion-choices-and-the-defects-to-watch)
- [read-time](#reference-read-time) · [safe-areas](#reference-safe-areas-legibility-and-accessibility)
- [motion-systems](#reference-motion-systems-the-north-star-and-the-alternatives) · [principles](#reference-animation-principles-applied-to-film-and-interface-motion) · [sources](#reference-sources-for-the-motion-rules)

---

## Reference: Anti-glitch rules

These diagnoses came from glitches that reached review on the first films. Their fixes are contextual craft recipes;
the current brief can choose fast travel, flutter, bounce, sustained motion, cuts or crossfades. Preserve that choice
while repairing the actual jitter, unreadability, clipping or discontinuity. Current technical gates still apply (see
[motion law](#reference-the-motion-law)). The pre-render checklist is [the glitch catalogue](#reference-the-glitch-catalogue-a-pre-render-checklist).

### Speed, blur and flicker

- **Blur length follows speed.** A wobble at f Hz makes motion blur pulse at 2f; flicker sensitivity peaks near 8 Hz.
  A 4 to 4.5 Hz damped wobble on every beat read as jitter. Current QA limits loop frequency to 1.9 Hz and requires at
  least a 16-frame period. Test a permitted intentional flutter under the final shutter and remove unwanted flicker;
  the failed wobble is not a general ban on oscillation.
- **Sub-frame staggers** (1.05 and 1.65 frames) mean no two parts sit at the same phase of the shutter, so every part's
  blur differs. Offsets between parts are whole frames.
- **A strong out-ease leaves rest at over six times its average speed**, so the blur jumps from nothing to a long streak
  in one frame; an exit that ends fast does the same at the end. A rest-to-rest curve or velocity-matched handoff can
  fix it; inspect the rendered continuity of a deliberately fast curve.
- **Strobing is too much change between adjacent frames**, not a frame-rate problem. Keep a fast move's speed and
  acceleration within its applicable class policy. At 1080 lines the default rig limits are 30 px a frame and 8 px a
  frame squared; UI and carries have different defaults and brands can set supported speed overrides.
- **Unexpected doubled edges during a whip** need inspection. Repair sampling, path or timing while preserving the
  intended gesture; a fast whip does not automatically need to become a glide.
- **Stacked out-of-phase loops read as swimming.**

### Entrances and exits

- **Nothing appears from nothing.** An entrance moves in from fully outside the frame, or fades in as one sheet over a
  real duration, or starts from at least 85% scale in place. It never starts part-way through its move, and never
  starts partly inside the frame.
- **An opacity fade on a strong out-ease** is mostly done in its first frames and reads as a pop: fade-ins need a
  gentler curve or a longer duration, and objects lay in from just above rather than from deep behind.
- **Unplanned one-frame disappearances** need repair. The carried-object recipe uses exits, including line endpoints;
  a deliberate cut or state change can be instantaneous when it serves the chosen grammar.
- **Exits leave the frame as opaque objects**, front one first, and are removed once off frame; cards fading out over
  each other read as cards seen through cards.
- **Return an object by carrying it back** (rising from below), not by fading it up from depth: a fade read as a ghost.
- **Carried elements leave with their page**; nothing lingers half-cropped at the frame edge into the next section.
- **A sheet's edge shadow fades out as the edge reaches the frame's border**, so the shadow band never vanishes in one
  frame.
- **Deal new cards in** rather than leaving an empty frame between screens, and keep content visible during a morph.

### Morphs and overlaps

- **Inspect overlapping cards and headings during crossfades.** Sequencing one out before another enters fixed the
  earlier muddy overlap. A deliberate blend can remain when its text is readable and its continuity is intentional.
- **Never duplicate an object to animate it.**
- **Never ease a value twice** (a mask fed through two eases filled in one frame).
- **Animate corner radii before a split or merge**; don't let them snap on the first frame.
- **A container and its contents share timing**, or the edge runs ahead of what it holds.
- **Two moves on the same path sum into an overshoot**: drive them from one clock and measure the path.
- **When an element lifts off a chart**, its attached parts (area fill, head marker) go with it or fade gradually;
  removing them all on the hand-off frame changed 23,654 pixels in one frame.
- **Draw merged segments as one continuous path** so no seams show.
- **When a layer splits in two along a line**, overlap the halves by about 2 px so no seam shows.

### Depth and stacking

- **Surfaces crossing through other planes get sliced** for a few frames: nothing crosses, and exits finish before
  entrances take the space. Keep moving cards in front of the planes they pass.
- **A card flip lifts toward the camera** and never passes behind its neighbours.
- **Deal cards as opaque paper**, parallel to the deck and always in front of it, with only in-plane rotation: a
  translucent, depth-turned card let the card under it show through and got sliced.
- **Show supporting surfaces one at a time**, rising and sinking in place, each in its own layer: surfaces never slide
  past or under each other.
- **Connecting threads route through gaps** and never cross words.

### Text and layout

- **Current motion QA rejects type entrances during another same-act carry moving above 2 px per frame at a 1080-line
  frame**, with an exemption for type on that same carried element. Preserve this check; inspect any other moving-text
  treatment for actual readability rather than assuming all moving layouts are prohibited.
- **Never write glyphs into space that's still occupied**: clear each glyph's space before it arrives, and let an impact
  ring out before the end card forms.
- **Keep layouts stable when data changes**: leave out explanatory lines that would make a column reflow (a reflow
  became a fast 112 px move).
- **Count a value once**; re-count only when it really changes, from its old value.

### Fine detail

- **Fine regular patterns shimmer and moire**, worst in downscaled copies: a field of 2,560 small dots on a tight pitch
  rang and sparkled. Use fewer, larger elements jittered off any lattice, move each only a little, pin the pattern to
  the screen while the camera travels, and check it at the smallest delivery size.
- **Thin rotating lines (about 1 px) crawl with jaggies**: use strokes of 3 px or more, and give every moving line a
  cause.

### Character marks

- **A mark whose parts overlap by design** shows seams and double shadows when each part is drawn separately with its
  own opacity, paper edge and shadow; parts placed in 3D at the same depth z-fight; and a spread that hovers near the
  point where the mark splits apart flickers between fused and split. Draw the parts as two fixed sheets, opacity and
  shadow per sheet, flat, and never rest near the split point.
- **Parts cut off at container edges**: nothing had checked the mark's envelope against the containers that clip it.
- **A colour mixed by distance from an edge** flickers at that edge; mix by flight progress instead.

The full method is in [character and motif motion](#reference-a-brand-mark-as-a-character-the-method).

### Renderer-specific

Headless Chrome and Remotion have their own traps (text snapping to whole pixels under slow motion, depth-sorting races,
clip paths that fail silently). Those are builders' rules: slate-build, remotion-gotchas.md and headless-chrome.md.

---

## Reference: Motion choices and the defects to watch

These are starting concerns from earlier films, not universal bans. Read the current brief and selected history.
Keep an intentional move that serves the film, including a fast carry, bounce, flutter, hard cut or crossfade.
Record the intended grammar in the brand's motion data so the gate measures that choice. An existing brand's explicit
restriction still applies until its direction changes; a technical failure remains a failure.

| Starting concern | What can go wrong | Deliberate use |
|---|---|---|
| **After Effects' default Easy Ease** | Applying one preset everywhere can erase the movement's purpose. | Use a curve that fits the move, including a preset when it earns its place. |
| **Linear moves** (position, scale, rotation) | Mechanical starts and stops. | Continuous drifts that start before the shot and end after it; things that represent time (progress bars, timelines, loaders, streaming text); a constant spin on a "thinking" indicator. |
| **Hard cuts** | A cut can break an intended shared-object handoff. | A deliberate contrast, musical hit or state change can need a cut. |
| **Crossfades between shots** | They can double-expose type and hide motion. | A deliberate overlap or atmosphere change can serve the film; inspect legibility during the blend. |
| **Scaling from zero** | A literal product element may lose physical continuity. | This can be a creative idea, but current motion QA fixes the entrance floor at 85% and exposes no brand override. Do not claim that recording the idea makes it pass. |
| **Bounce or overshoot** | Unwanted rebounds distract from a landing. | A character or expressive object can need follow-through; control its amplitude and endpoint. |
| **Opacity-only entrances for hero text** | Flat and cheap. | Hero text must also move at least 16 px or unmask. Opacity-only is fine for secondary labels. |
| **Stock presets and effects**: glows, light leaks, lens flares, glitch effects | An unconsidered preset can feel generic or off-brand. | Use an effect when the current treatment calls for it and its rendered result carries the idea. |
| **Glowing orbs and other AI-glow tropes** | A familiar trope can obscure the film's own idea. | Light can belong to a film's world; make its purpose specific. |
| **Extruded 3D type** | It may clash with a flat product language. | A dimensional treatment can call for it; preserve readable text and the chosen look. |
| **Stock-photo grids** | An arbitrary grid may fail to tell the story. | A photographic mosaic can be the requested idea when its sources and composition support it. |
| **Typewriter text** | A literal product demonstration can imply a streaming behavior the product lacks. | Streaming product text or an explicitly authored graphic text treatment, with truthful claims and measured reading time. |
| **Traffic-light gradients or colour ramps for status** | Unexplained colours can misrepresent real UI state. | Use the product's real status tokens for product evidence; an interpretive graphic can use a clearly chosen scale. |
| **Radial light or edge shading on flat brand fields** | Shading can contradict an intended flat field. | Use it when the selected look is lit or dimensional. |
| **Squash and stretch on paper-like marks** | Unwanted deformation can change the brand mark or material. | An authorized expressive character treatment can deform; preserve required brand geometry and current rig checks. |
| **Character effects**: glows, particles, lens effects, extra colours | Effects can compete with the character or conflict with its palette. | Choose them within the current character direction and applicable brand restrictions. |
| **UI the product doesn't have** | Nothing is invented. | A concept screen with the requester's explicit sign-off and a visible "concept" treatment. |
| **Confetti and particles as a celebration** | Generic effects can feel disconnected from the story. | Use them when the film's world and requested celebration call for them. |

Earlier narrow exceptions describe a product-film preset. They do not prohibit a different
brand or requested treatment. Source truth still matters: an interpretive UI can simplify or dramatize a real
capability, but cannot invent a capability or make an unsupported product claim.

### Checking

- `slate qa motion` checks allowed named and kit curves against their samples, durations, stagger roles and caps,
  fixed entrance and hero-text constraints, applicable speeds, loop periods and rig symmetry. A brand can set supported
  controls, not disable every technical check. See [motion law](#reference-the-motion-law).
- Inspect the result at full and quarter speed with sound and the current brief. A trace `exception` creates a REVIEW
  item requiring hash-bound human acceptance; it does not create an automatic pass or waive hard plan acceptance.

---

## Reference: Camera

The camera is the viewer's guide. Choose its movement for the current brief: a reveal, a carry, sustained energy or
stillness. The gentle product-film recipe below is a starting point. Exact contract frames and truthful motion
evidence remain technical requirements, whatever camera style the film chooses.

### When it moves and when it rests

- **A slow drift keeps the world alive.** A drift that starts before the shot and ends after it can be linear, because
  its start and stop are never seen.
- **The camera rests** for UI state cuts, and wherever geometry must be screen-exact: act contracts, hand-overs between
  screen space and a card, rest frames that must be pixel-exact.
- **One camera move per act** was the restrained starting recipe. Bringing a card forward can give it a closer read;
  another brief may need several camera moves or continuous travel.
- **Fewer, better moves.** Don't pan out to one thing and back when one draw-back can show both; don't push onto a page
  and straight back out.
- **The camera can step down a list** as the voice reaches each line.
- **Overlays on a plate take the plate's own transform** (labels, marks, UI over footage), its slow push included, so
  they never drift against it. A linear push starts and stops off screen.
- **A move bounded by a later beat shrinks to fit** rather than overrunning it after a re-voice, and keyed drift points
  stay at least 0.8 s apart.

### How it moves

- A rest-to-rest ease at the camera duration is a useful starting point. Long travel can also use a supported even
  curve, a deliberate continuous drift or a faster named treatment. Check its applicable speed policy and blur.
- **Give detailed content a readable interval.** Earlier small type strobed during travel; letting the camera rest
  before the station spoke fixed that film. Another treatment can keep moving when its actual text stays readable.
- **Inspect large fast pull-backs carefully.** A previous 4,000 px truck with a big zoom-out in under a second moved
  267 px a frame, read as a whip, popped objects in from nothing and landed on unreadable details. Those defects need
  repair; the measurement does not ban every fast pull-back. A declared whip beyond the carry limits goes to review.
- **Zoom in log space**, and prefer a 2D camera over poses: huge `translateZ` zooms rasterize badly.
- A world authored at film scale and screen-aligned at rest keeps rest frames pixel-exact.

### Depth of field

- 3D camera moves keep depth of field on, with focus keyed to the rest-to-rest ease, and an aperture that blurs
  off-focus UI past legibility (so it doesn't compete).
- A rack focus between focal elements is a lens effect, allowed; it never counts as a crossfade.
- For a weighty line, hold everything still except a slow focus pull that leaves one element standing alone.

### Framing

- **Close-ups never crop text mid-line.**
- Keep the focal object inside the title-safe area and the platform's safe zones (safe-areas.md).
- When the frame will be derived to another aspect, keep the action where a re-staged layout can still hold it
  (slate-finish, derived-films.md).

### The kit

`Camera` (a look-at camera, dolly in z) for 3D; `WorldLayer` (2D, identity at rest) for flat worlds; `camAt`, `lerpCam`,
`cam2DAt`, `drift2D` for paths. Draw objects that move against each other in separate cameras, so their stacking is plain
document order and can't flip.

---

## Reference: A brand mark as a character: the method

When a brand's motif or mark becomes a character (a character-led film, an assistant's mark, a mascot built from the
logo), it needs its own motion spec. Every rule in it is either sourced (from research, cited by label in sources.md)
or computed from the brand's artwork and the film's own word timings. This method was written after a character's
first version was called "super glitchy"; the second, built to it, was approved as perfect.

**The bar:** playful and fluttery is compatible with perfectly synchronized. The defect feedback below concerned
jitter, clipping and overlap; it did not ask every character to become quiet. The earlier radial mark method used
coordinated gestures with stillness between them. Keep that original direction, feedback and repair together, and use
the latest brief and authorized feedback for the current character.

This document describes the current kit's radial rig and a product-film choreography recipe, not a universal character
policy. The kit's channel, phase, lint, calm and clipping contracts still apply when this rig is used; current QA also
checks waveforms, loop period and applicable speeds. A requested different grammar needs an implementation that can
meet its applicable checks. Do not claim a supported creative choice automatically overrides those technical limits.

Frame counts below are at about 30 fps and speeds at a 1080-line frame; scale both to the film's own rate and size.

### What went wrong the first time

| What the owner saw | The cause |
|---|---|
| Jitter | A 4 to 4.5 Hz damped wobble on nearly every beat: a swing every 3.3 frames. Motion blur pulses at twice that (8 to 9 Hz), where human flicker sensitivity peaks. Per-part spins made it worse. |
| No coordination | Staggers of 35 and 55 ms, which are 1.05 and 1.65 frames: no two parts ever sat at the same phase of a frame or of the shutter, so every part's blur looked different. |
| Speed jumps | A strong entrance ease leaves rest at over six times its average speed and covers a third of a 16-frame move in its first frame: the blur goes from none to a long streak in one frame. |
| Clipping | Parts cut off at container edges (nothing checked the character's envelope), and a colour mixed by distance from an edge flickered at that edge. |
| Overlap glitches | Parts that overlap by design, drawn one at a time with their own opacity and shadow, showed seams and double shadows; parts at the same 3D depth z-fought; a spread hovering near the point where the mark splits apart flickered between fused and split. |

### 1. Study the mark as a system

- **Geometry**: the parts, their shape, where they sit (often on a ring), their rest rotations, as fractions of the
  disc or frame they live in. Tabulate part size, ring radius and ink radius at every size the film uses.
- **One part, N times**: a radial mark is often one part rotated N times. Then it's a replicator: motion defined once
  for part 0, copied with a rotation and a whole-frame delay, stays symmetric by construction.
- **Overlaps by design**: if parts tuck under their neighbours, the eye sees one shape. The brand's own paint order
  defines two sheets (the parts drawn first, the parts drawn over them).
- **The split point**: compute how far the parts can spread (all together, or one group alone) before the fused shape
  splits into separate parts, where parts of the same group first touch when pulled in, and where the centre closes.
- Store the result in the brand's pack (`motif`: parts, shape, sizes, groups, curves, mark ratio, gestures).

### 2. The radial kit's channels

- **The whole mark**: its turn (rests at multiples of its symmetry angle), the whole avatar's scale, the mark's scale
  inside its disc, and the mark's offset from the disc's centre.
- **Each part**: its radial offset (in ring radii), its scale, and, for a part sent away, its place off the ring.
- Nothing else. No per-part angle, no per-part spin.

### 3. One clock

- **The pose is a pure function of the film frame**, including every sub-frame sample the renderer asks for. Nothing is
  carried between frames, no part has its own timer, and there's no randomness or noise.
- **Everything is in whole frames**: every key, and every per-part offset. Then the part in slot k at frame f is exactly
  the part in slot 0 at frame f minus its offset, rotated, blur samples included, so the blur streaks are rotated copies
  of one another instead of per-part noise.
- **Why**: every clean multi-part loader works this way. A circle spinner delays each of its 12 dots by the cycle over
  12; a replicator's delay is its duration over its count; After Effects' follow-the-leader rig reads each layer's value
  at time minus index times delay. Biology calls a fixed lag between neighbours a metachronal rhythm; perception calls
  it common fate: parts that move with the same timing read as one object.

### 4. The radial kit's three phase relationships

| Mode | Offset for the part in slot k | Symmetry | Typical use |
|---|---|---|---|
| **Unison** | 0 | full, at every frame | nods, leans, holds, returns, a greeting's breath, flights |
| **Pairs** | one group a fixed whole number of frames behind the other | within each group | a breath, an entrance in the product's own bloom order |
| **Wave** | k times a fixed whole-frame step, counted from the wave's start slot | across time | the one flutter |

- Derive the pairs lag from the product's own loader timing (a loader running one group 8% of a cycle behind became a
  4-frame lag on a 48-frame breath).
- The wave's step is its cycle over the part count, in whole frames (a 24-frame cycle over 8 parts is 3 frames), which
  also lets each accent register: hold an accent at least two frames.
- Order by slot (where parts are now, counted round the ring), not by part: a turn moves every part one slot along.

### 5. Symmetry at every frame

- **Spoke lock**: every part's centre stays on its spoke; only its distance from the centre changes. The one exception
  is an entrance where a group spirals in as one rigid piece.
- **Orientation lock**: a part's own turn is always its rest turn plus the mark's turn. A part never spins on its own.
- **Deliberate exceptions**: gestures whose meaning is breaking the ring (sending one part away to point at something,
  gathering parts round a point). The parts left on the ring stay exactly at rest.
- Good radial marks change the whole mark at once: a ring that moves outward to respond and inward to listen, dots
  rooted in consistent paths and timing, a breathing flower driven by one container animation with no per-part delay.

### 6. Loop checks and the earlier gesture recipe

- **Current loop floor:** at least 16 frames and no faster than 1.9 Hz; a brand can demand a slower loop, not loosen
  this floor. The earlier 30 fps recipe spaced consecutive reversals at least 8 frames apart.
- **Earlier overshoot recipe:** one small dip in the wave. Other expressive peaks are creative choices, but the chosen
  curve and brand overshoot policy must support them and the kit's applicable checks must still pass.
- **Earlier loop recipe:** a breath with a cycle of at least 44 frames and no other idle loop. Sustained motion may
  serve another brief; preserve current rig symmetry, determinism, loop and hand-in constraints.
- **A loop that turns** (a thinking loop that turns the mark as it breathes) turns exactly one symmetry step per cycle,
  so every cycle ends on the rest mark. Never turn it linearly and round to rest afterwards.
- Why: blur length follows speed, so a wobble at f Hz makes the blur pulse at 2f, and flicker sensitivity peaks near
  8 Hz. Material 3 fires even its bounciest spring once per transition and its effects springs never overshoot; Apple
  defaults to no bounce and advises against sustained oscillation. Stacked out-of-phase loops read as swimming.

### 7. Speed limits, and no abrupt velocity changes

- **Zero velocity at both ends** of every move, or hand the exact velocity to the next move. Parts use only rest-to-rest
  curves: a sine in-out for nearly everything, and a zero-bounce-spring shape for a quick turn that settles onto itself.
  Never the entrance, exit, state or linear eases.
- **The default is at most 30 px a frame** for every point of every part. The renderer spreads 16 samples over a 180-degree shutter, so
  the gap between samples is the speed over 32; 30 px a frame keeps it under 1 px. Up to about 48 only at the crest of
  a long flight the beat could not afford to slow was an earlier recipe exception, not an automatic QA allowance.
  Current brand speed configuration or a hash-bound review item must account for a move beyond the default.
- **At most 8 px a frame squared**: a point's movement per frame changes by no more than 8 px from one frame to the
  next, so its blur length changes by no more than 4 px.
- **A flight takes at least max(16, chord ÷ 19) frames**, so its crest stays under 30 px a frame.
- Why: strobing is too much change between adjacent frames, not a frame-rate problem; an ease curve stops abruptly where
  a spring keeps its velocity; AE's old 16-sample blur cap left visible echoes on fast objects.
- **Model every gesture numerically** at the smallest, typical and largest size it appears before building it, and
  record the worst case.

### 8. Nothing ever clipped

- Draw the character in an overlay layer above everything its parts visit, with no clipping ancestor.
- Every clip contains a clear circle round the character (about 0.85 of its disc's diameter covered the disc, its
  shadow and every gesture's reach) plus the whole path of any part sent away.
- Tabulate the envelope (the farthest ink from the centre) for every gesture.
- Inside a scroll view, it crosses the view's edge only when calm.
- A part that leaves the disc takes its colour by flight progress, never by distance from the disc's edge.

### 9. Overlaps without seams or z-fights

- **Two sheets, fixed for good**, in the brand's paint order. Membership is never re-sorted, so a turn never pops a
  layer. (Overlapping parts drawn one at a time can't have a consistent order round a ring.)
- **Opacity** on the whole mark or a whole sheet, never on a single part.
- **A fade finishes while the parts are still clear of their overlap.** A fade on part of the mark is done by the time
  its parts could touch: when a group is fully opaque, it's far past the point where parts meet.
- **Paper mode**: one shadow and one paper edge per sheet (a drop shadow on the sheet's group shadows the union), never
  one per part.
- **2D only**: no 3D transforms on parts. To tilt the character, render it flat into one layer and tilt the layer.
- **Stay clear of the split point**: a spread either stays inside the fused band or goes decisively past it and crosses
  at speed, once out and once back. Never ease to a stop near it. Parts of the same group never touch.

### 10. At small sizes it moves as a whole

- Per-part choreography needs room. The films used three regimes: full choreography at about 88 px and up; unison only
  (no lags, the wave in unison) from about 56 to 87 px; and no per-part motion below about 56 px, where spread becomes
  the whole mark's scale (flights still work). Below about 80 px, as a rule of thumb, the whole mark moves as one.
- Choose the regime once per gesture, from the size at its contact frame, so nothing switches mid-move.
- Drop any per-part motion under 2 px at the current size: it reads as shimmer, not gesture. Hold parts on stable
  sub-pixel positions (a spinner's jitter was cured by keeping successive frames within a fifth of a pixel).

### 11. Stillness in this kit's choreography

- The earlier recipe holds between gestures. The current kit's character hand-in checks also require stillness between
  its gestures and calm after them. That constraint must be reported honestly if a requested sustained treatment does
  not fit this implementation; it is not a reason to reinterpret the request as a universal preference for stillness.
- **Nothing is driven by the voice's loudness.** Speech loudness fluctuates mostly between 2 and 8 Hz, right in the
  jitter band, and a film knows every word in advance: key motion to events, never to amplitude.
- Knowing when not to move matters as much as moving; even audio-first products script their states. Delight means more
  from something that never exaggerates.

### 12. Keyed to the voice, landed with its sound

- **S** is the frame where the stressed syllable of the key word starts, and **C**, the contact frame, is two frames
  later: C = S + 2 (anywhere from S + 1 to S + 5 when a beat needs it, never later than the end of the stressed
  syllable).
- The key pose lands on C: 90% of travel for a landing, the apex for a peak. The move's top speed falls a few frames
  before C, near the vowel.
- **Early, never late.** A gesture's top speed coincides with the stressed vowel and its apex falls inside the stressed
  syllable; a gesture precedes or ends at the stressed syllable but doesn't follow it. Gestures 500 ms early didn't hurt
  recall in studies; 500 ms late did.
- **Later stress** (a word stressed on its second syllable): measure S from the take's loudness envelope (the stop
  consonant before a stressed syllable leaves a clean gap) with `slate timing stress <shot> <word>` (`--gap 2` when the
  word has two stops, as ex-CLU-sive does), and put the `stress_start` and `stress_end` it prints on the gesture in the
  act's beats. With no stop in the word it answers with the word's start, which is always safe: early, never late.
  Measure again after any re-voice.
- **Sound sits on contact frames**: every sound's attack is on a contact frame, every note has its own visible contact,
  and sound never comes before the picture. One event per note, each on its own whole frame; when two land on the same
  frame, one plays, by a fixed priority. Viewers notice sound from about 45 ms early or 125 ms late.

### 13. The gesture vocabulary

- **A small, fixed vocabulary**, each gesture with one meaning and one kind of word it keys to. The kit's defaults:
  hello (an entrance and a breath), yes (a turn that lands on itself), attention (a lean), thinking (a breath), answering
  (a pulse), delight (a wave), care (a hold), landing (a ripple), home, goodbye (a turn). A brand defines its own in its
  pack (`motif.gestures`).
- **Keep a gesture's meaning clear.** When the current treatment asks for another feeling, author its vocabulary in the
  brand's pack or use staging within the kit's supported channels; do not let the default vocabulary veto the brief.
- **Tempo carries meaning** (a fast pulse reads as an error, a slow one as rest); a small vocabulary on consistent paths
  reads as a character; a defined start and end, anticipation then release, reads as intentional.
- **Porting a product animation** to the rig: keep its choreography and replace its strong out-ease with the rig's
  rest-to-rest curve.
- **A gesture's spec**: its meaning, the word it keys to, each channel's keys in frames relative to C, its phase mode,
  its contacts, its sounds, how it behaves at each size, and what it never does (never a wobble after a landing).

### 14. How gestures combine

1. One momentary gesture at a time, with at least 4 still frames between one's end and the next one's start.
2. Held states (a lean's offset, a hold, parts sent away) persist until changed. Momentary gestures may run on top,
   except that nothing runs during a hold, and only a lean or a hold while parts are away.
3. Never two gestures on the same channel at once.
4. Every act starts and ends with the character calm: the brand mark exactly, turned to a multiple of its symmetry
   angle. At a contract frame the mark rests at exactly its rest turn, not an equivalent multiple of its symmetry
   angle: at 90 degrees the picture matches but the pixels don't, and a bit-identical contract fails.
5. A builder's own moves of the character (placing it, resizing it for a gesture) are part of its motion: the rig's
   curve and its speed limits apply.

### 15. Staging a character

- **Introduce it up close**, assembled large, then a step back: assembled at its small lockup size, it read as a speck.
  See it made, let it turn to you, step back, then name it.
- Resize it into its full-choreography size before a gesture that needs it (enlarging over about 20 frames before a
  wave).
- **Staging is separate from gestures.** For a close-up, the mark's scale inside its disc and its offset from the
  disc's centre are staging (`MarkCharacter`'s `markScale` and `markOffset`, in disc diameters), and they come back to
  1 and 0 on the rig's curve as the camera pulls back. They never change a gesture: the track draws the same pose,
  scaled and moved with the mark.
- Never show the character twice in one frame (a second copy as a chat avatar splits it).
- Check a flight's path against the marks it passes, and choose the part and placement that clear them.
- Place it where its later UI will open into empty space, not over content.
- **Every point the character uses** (its position, a lean's target, where parts are sent) is in the coordinate space
  of the layer it's drawn in: screen pixels in a full-frame layer, world pixels inside a camera, card pixels inside a
  card.
- **Carry it between surfaces on its own curve in screen space**, whatever the camera does. Each carry ends no earlier
  than any camera move it overlaps (a carry that ended first kinked the character's velocity at about 8 px a frame
  squared), and lands on a fixed target, never a moving point.
- The earlier warm sound recipe used felt notes, a wood tick and pads. The current sound palette can choose other
  materials, including chimes when its measured timbre policy allows them (slate-sound).

### 16. Sending parts away

Sending parts off the ring, to point at something or gather round a group, is the one deliberate break in the ring's
symmetry (section 5), so it has rules of its own:

- **Which part goes**: the part whose spoke points closest to the target at lift-off; ties go clockwise. The rest hold
  still and the ring keeps the gap.
- **Its path**: an arc that bulges away from the centre, a quadratic curve whose control point is the chord's midpoint
  pushed outward by min(0.12 × chord, 80 px). Size and colour change by flight progress, never by distance, and the
  part never spins.
- **Several parts to several targets**: sort the targets by angle around the centre and rotate the assignment to the
  least total angle error, so no two paths cross. The longest chord sets the flight length for all of them.
- **A ring opening around a group of targets** moves its centre on an arc and grows to an ellipse, each part at its own
  slot angle so order and orientation are kept, then holds perfectly still until it goes home.
- **One flight at a time**: a flight never lifts off before the previous one has seated.
- **Size a flight from its on-screen chord**, the camera's scale included: under a close camera, a flight sized in its
  own layer moves faster on screen. Keep a floor so a signature flight stays unhurried, and never shorter than
  max(16, chord ÷ 19) frames (section 7).

### 17. Acceptance of this method

Keep the original recipe's tests as evidence of what it achieved. The current hard plan acceptance and kit hand-in
checks still require their own proof; a changed creative direction does not silently waive them. Speed and overshoot
results must be assessed against the current configured law rather than treating the historical 48 px crest as a pass.

1. **Determinism**: any frame rendered on its own is bit-identical to the same frame rendered in sequence.
2. **Calm**: at rest the frame after every gesture ends, and at both ends of every act.
3. **Symmetry** at every sub-sample: unison parts equal; pairs equal within each group and lagged exactly; wave slots
   lagged exactly.
4. **Speed**: every point at most 30 px a frame (48 only at a long flight's crest), acceleration at most 8 px a frame
   squared.
5. **Frequency**: reversals at least 8 frames apart; the one allowed overshoot only where it's allowed.
6. **The split point**: the gap between neighbours changes sign at most once out and once back per gesture, across all
   sub-samples.
7. **Clipping**: whenever it isn't calm, every clipping ancestor contains the clear circle and any away part's path.
8. **Sound**: every character event on a whole frame, one event per note, no offsets added by the sound engine.
9. **Eye**: the gesture sheet at the smallest and largest sizes, at full and quarter speed, with sound. Nothing
   shimmers, pops or strobes, and every note lands on something you can see.

### The kit

`MarkCharacter` (the disc with the motif in it) and `MotifMark` draw the rig; `gesture(meaning, {t | frame})` makes
track entries from the vocabulary; `motifBeats()` lists the character's sound events (kind `character`, one per note);
`motifLint()` lists anything the combination rules forbid (an empty list is a clean track); `registerMotifTrace()`
records the rig for `slate qa motion`, which checks symmetry and the speed limits; `isCalm()` checks rest. At hand-in
`slate check` runs the acceptance tests it can measure on every registered mark (the character gate: the rig lint, calm
at both ends and after every gesture, still between gestures, the split point, the clear circle in every clip), and the
kit's gesture sheet (`Kit-Gestures`, and `Kit-Gestures-Quarter` at quarter speed) is the sheet a person reviews by eye.
The research behind each rule is in [sources](#reference-sources-for-the-motion-rules).

---

## Reference: Character motion: the one-page checklist

Use this checklist for the kit's radial mark-character method. It combines that method's choreography and renderer
contract with current technical checks; it does not prescribe every future character's personality. The original
flutter, feedback and repair remain context in [character and motif motion](#reference-a-brand-mark-as-a-character-the-method). Follow the
latest authorized direction without treating jitter repairs as an instruction to remove playful energy.

### Clock and phase

- [ ] The pose is a pure function of the film frame, sub-frame samples included. No timers, no randomness, no noise.
- [ ] Every key and every per-part offset is a whole number of frames. No sub-frame staggers (35 or 55 ms offsets put
      parts at different shutter phases and read as jitter).
- [ ] Only three phase modes: unison, pairs (a fixed whole-frame lag), a wave (a fixed whole-frame step per slot).
- [ ] Parts stay on their spokes and never spin on their own.

### Curves and speed

- [ ] Every move starts and ends at rest, or hands its exact velocity on. No entrance, exit, state or linear ease on
      the parts (the fast-out entrance ease leaves rest at over six times its average speed and smears under blur).
- [ ] Every point meets the applicable rig speed policy: the defaults are 30 px a frame and 8 px a frame squared at a
      1080-line frame. Supported brand speed overrides replace those defaults.
- [ ] Current motion QA's loop floor is at least 16 frames and no faster than 1.9 Hz; brand loop settings can tighten
      it. The earlier gesture recipe used only a breath loop and one overshoot, not a universal creative ban on loops.
- [ ] Nothing is driven by the voice's loudness (it modulates at 2 to 8 Hz, the jitter band).

### Drawing

- [ ] Drawn as one flat plane in two fixed sheets, in the brand's paint order; never 3D parts in a shared 3D context
      (they z-fight under the 16-sample shutter).
- [ ] Opacity, shadow and paper edge per sheet or whole mark, never per part.
- [ ] Nothing clips it: an overlay layer, a clear circle in every clip, the envelope checked per gesture.
- [ ] A spread never rests near the split point.

### Size

- [ ] Below the small-size threshold (about 80 px as a rule of thumb) the whole mark moves as one.
- [ ] Per-part motion under 2 px is dropped.
- [ ] The regime is chosen once per gesture, from the size at its contact frame.

### Meaning and timing

- [ ] Each gesture has one meaning and keys to its word: contact C = S + 2, early never late.
- [ ] One momentary gesture at a time, at least 4 still frames between.
- [ ] The current kit hand-in checks require stillness between its gestures and calm (the exact brand mark) at both act
      ends. A different requested grammar cannot be declared passed while those applicable checks still fail.
- [ ] The mark returns to the exact brand mark at rest and at every act boundary.
- [ ] Every sound on its own contact frame, one event per note.

### Proof

- [ ] `slate check <act>` passes; `slate qa motion` passes on the act's trace.
- [ ] The gesture sheet reviewed at the smallest and largest sizes, full and quarter speed, with sound.

### Designing a new character

Start from research, not taste alone: a sourced survey of how voice-assistant and loader marks move (assistant rings and
glows, dot marks, loaders, orbs, cursors) is the reference material for designing a mark's gestures. The findings that
matter are in [sources](#reference-sources-for-the-motion-rules): take the principle, never the look.

---

## Reference: Carry one idea through changing forms

A carried object becomes useful when its changes explain the idea. Start with one recognizable object, let it gain
meaning, and keep enough of its shape, label or position for the viewer to follow it. A smooth transition alone is
not a reason to make the transition.

These construction recipes combine Slate's existing kit and motion rules. The dataset, product artwork, paths and
story remain the film's. They are guidance, not prebuilt scenes or newly verified components.

### A crowd becomes an explanation

Use this when the story moves from individual observations to a visible pattern.

1. Give every observation a stable identity. Keep a record of its initial pose, final pose and group; do not rebuild
   the population with new identifiers when the layout changes.
2. Match each destination to a nearby source in the relevant group. Resolve ties deterministically. Keep that
   assignment fixed across frames, so neighbors do not trade places in the middle of a move.
3. Make the cause visible: a reading line, selection or other meaningful action reaches each object before it sorts.
   Derive the local start from that contact and the film clock, rather than staggering the whole crowd arbitrarily.
4. Keep local travel small. Move the world with `cam2DAt` or the named camera track when necessary; compute a screen
   pin in the same coordinate system as the camera so a displayed detail stays fixed while its surroundings move.
5. When the pieces form a continuous band, render the band's exact final union. Transfer drawing ownership at the
   common endpoint; do not fade another band over pieces that are still visible.
6. Hold the pattern before introducing its explanation. Then reuse the resulting band, line or point inside the
   next chart instead of resetting the visual argument.

`Card`, `chainObj`, `monoSpline`, the cameras and chart primitives provide the parts. The source-to-destination
assignment and contact timing are authored film data. Check the smallest delivered size: tight regular grids can
shimmer even when their full-size render looks steady. See
[shared elements](#reference-morphs-and-shared-elements),
[camera](#reference-camera) and
[anti-glitch rules](#reference-anti-glitch-rules).

### Weighted objects become navigation

Use this when several contributions must remain legible while one opens into detail.

Normalize the dataset once and derive cumulative intervals from it. For example, weights 2, 3 and 5 occupy
`[0, .2]`, `[.2, .5]` and `[.5, 1]`. That one partition record defines each outgoing object's destination width,
its segment of the shared line and its later place in the navigation bar. Keep identifiers and label ownership
with the partition.

Flatten the objects into those intervals on one coordinated motion track. Draw the continuous destination at the
common landing state, then use the same intervals to expand into navigation. A selected interval can open its
panel while the other intervals remain visible as context. Keep the selected anchor still and reveal the panel's
content in its final layout, clipped to the changing container.

Position, size and contents share the same timing; geometric travel uses the named ease once. Each value counts
once, from its previous displayed value when it changes. Arrange the shared labels and figures on routes that do
not cross each other. New detail arrives after the carried parts have almost landed. See
[morphs and counting](#reference-morphs-and-shared-elements). Apply the act contracts from slate-build.

### A curved flight keeps one pace

Use this for a continuous return from a data endpoint to a meaningful mark or destination. A curve's raw parameter
is not distance: easing that parameter can create an unwanted acceleration or pause as curvature changes.

Build a cumulative distance table from samples of the authored path. Apply the brand's motion ease to the fraction
of total distance travelled. Find the surrounding distance samples and interpolate the corresponding path
parameter; then evaluate the original curve at that parameter. Skip zero-length sample intervals, handle a
zero-length path explicitly, and return the exact authored endpoints at progress zero and one. Sampling density
must be sufficient at the final output scale; compare finer tables before trusting it for a large hero move.

Keep the path, distance table and timing deterministic and evaluate them at sub-frame times. Land on the meaning's
word using `startFor` or `landOn`; orient to the path's tangent only when the object permits rotation. A fixed
brand mark keeps its orientation. End with the exact destination composition and a read hold.

Slate's `monoSpline` controls values through timed keys; it does not supply a general point-at-distance path API.
This recipe remains film-owned math until a reusable helper has its own tests and visual proof. See
[the motion law](#reference-the-motion-law) and
[shared elements](#reference-morphs-and-shared-elements).

### Let the payoff retain its history

The closing object should contain evidence of the journey: a changed value, earned mark, filled slot or meaningful
page. A physical book can accumulate those changes with `HingedBook` and `PageLeaf`, while its page faces remain
caller-owned. Return to a shape or composition introduced early so the ending resolves something the viewer already
recognizes. Preserve generous reading time around contact, comparison and audience changes. See
[physical books](#reference-physical-books-a-carrier-with-memory). Use slate-story's structure rules to earn the payoff.

Before hand-in, inspect the first moving frame, ownership transfers, collisions, the smallest delivery and the
settled endpoint. A construction guide is not a film gate: the finished sequence still needs its own motion trace,
frame review, sound alignment and owner review.

---

## Reference: Durations and staggers

### The duration scale

Seconds are the source of truth; frames come from the film's own rate. A brand's scale names its tokens; the kit's
neutral scale, and what each token is for:

| Token | Seconds (neutral) | Use |
|---|---|---|
| tick | 0.20 | chip flips, checks, a dot lighting, a glyph morph committing |
| quick | 0.33 | small UI elements, icon morphs, make-room re-layouts |
| base | 0.50 | standard entrances: a line of type, a card |
| broad | 0.80 | panels, mask and band wipes, short count-ups |
| camera | 1.20 | camera push, pull and truck; shared-element carries |
| signature | 1.80 | logo construction beats, portal zooms, the big pull-back |

A brand's own values come from its product's duration tokens and its measured references (slate-brand).

**Starting recipe**
- Earlier product films used exits at 0.75 times their entrance and a 0.2 s floor outside state flips. The brand's
  duration scale and `exit_factor` choose the actual values for this film.
- Continuous drift and time-based data can run beyond a duration token. Other traced moves must match the chosen
  scale; choose a suitable token instead of disguising the move's duration.
- One signature-length move per act can make it feel rare. Current QA enforces a count only when the token declares
  `max_per_act`; a different brief can choose a different structure.
- Earlier large carries ran long to reduce screen speed. A requested fast carry can stay fast when its declared curve,
  applicable speed policy, readability and rendered blur support it.

### Frame heuristics

At 30 fps (scale for other rates): 2 to 4 frames reads as a snap, 4 to 6 as anticipation, 6 to 10 as a settle, 8 to
12 as a quick transition, 18 to 30 as a slower entrance. A head turn in 2 in-betweens reads as a nervous twitch; a
stroke of about 10 frames reads as deliberate.

### Staggers

**Units** (the neutral law; brands set their own): per character about 0.05 to 0.067 s, per word 0.1 s, per line, list
row or card about 0.133 s, per major block 0.2 s. At a given frame rate these are whole frames.

**Starting caps**
- The neutral law caps a group's spread at 0.6 s and half of its entrance duration, and groups more than 8 items.
  Brands can choose their own caps and item count; the gate checks the declared law.

**Current gate:** stagger groups are limited to entrance, exit and state roles. The earlier recipe moved rest-to-rest
objects as one piece. A requested treatment must still fit the supported trace roles rather than bypass this check.

**Exits** stagger in reverse at two thirds of the unit, or leave together on the exit ease when a camera move is
carrying the scene away.

### Order

- **Reading order** for type and lists.
- **Along the data's direction** for charts: low to high, baseline to latest reading, the product's own order.
- **From the focal element outward** for grids.
- **The product's own order** for rows and steps: cascade lists and rows out at about 0.2 s intervals.

### Sync

- The first element of a group lands within 2 frames of the voice's word it illustrates.
- Groups without a voice line land on the music's beat grid.

### Type

- **Hero lines** used a 6-word, two-per-act script preset, with per-character entrances; lines arrived per word and
  lists per line. Script reading settings can change the hero limits, and the brief chooses the entrance treatment.
- Current motion QA requires hero text to move at least 16 px at a 1080-line frame or unmask. Opacity-only remains
  supported for secondary labels; a creative preference does not turn a failing hero entrance into a pass.
- The kit's `PerChar`, `PerWord` and `Arrive` already cap their spread; don't re-implement them.
- Lay out text with room for words that arrive later, so no make-room move is needed.

---

## Reference: Eases, springs and landing on the word

### Exact endpoints

An ease solved by bisection never returns exactly 0 or 1: it returns something like 1e-15 before a move starts. On the
first films that made every "has it started?" check open early: a bar drawn twice, copies of a later shot on screen from
the start, characters drawn at opacity 7e-15. The kit's eases return exactly 0 before and exactly 1 after; never wrap
them in your own, and never gate on `u > 0` with anything else.

**Never ease a value twice.** A mask fed through two eases filled its hollow in one frame.

### Landing a move on a word

A move "lands" when it reaches 90% of its travel (T90). Sync means the landing is within 2 frames of the voice's word:
- `landOn(word(...), 'base', 'enter')` gives a move's frame in and frame out so it lands on the word;
- `startFor(land, dur, ease)` gives the start time for a landing time;
- gate each element's entrance on the first word it shows, not a later one, or it appears already part-way through.

Word lookups (`word()`) never throw: a miss is estimated and recorded, and the hand-in check refuses the act until the
miss list is empty.

### Rest-to-rest versus entrance

- An entrance ease leaves rest at several times its average speed: a strong one covered a third of a 16-frame move in
  its first frame, so under motion blur the streak goes from nothing to long in one frame.
- An exit ease that ends fast does the same at the other end.
- Rest-to-rest curves often fix this discontinuity for large carries and character gestures. A fast move or a
  velocity-matched handoff can be deliberate; choose its curve for the current brief, declare it accurately and inspect
  its rendered start and stop. Do not remove requested speed merely because a previous film needed a softer carry.

### Springs and deliberate follow-through

- Good motion systems use springs that settle: Material 3 fires even its bounciest spring once per transition, and its
  effects springs never overshoot; Apple defaults to a bounce of 0, calls about 0.3 noticeable and above about 0.4
  exaggerated for UI, and starts every spring at full damping.
- The earlier product-film recipe used a gentle damped settle for container morphs. Bounce and overshoot can serve a
  different character or graphic treatment. The brand's `overshoot` policy must allow the measured peak; its `where`
  text describes intent but does not implement an object-specific allowance.
- Ease curves stop abruptly where springs keep their velocity; when two moves hand over, pass the exact velocity or
  start and end both at rest.

### Splines and chains

- Catmull-Rom through unevenly spaced keys overshoots and backtracks (a camera once drifted 274 px past its path). The
  kit's monotone spline (Fritsch-Carlson) never does.
- Chain moves so each segment starts where the last ended, at rest or at matching velocity; two moves that overlap on
  the same path sum into an overshoot. Drive them from one clock and measure the path.

### Measuring a reference's curve

Study reference films at full frame rate, fit the curve of a clean move frame by frame (`slate.motion.fit`, run by
onboarding's analysis), and keep the fit with its RMS error and the closest standard curve. A fit with high error or a
contaminated measure (blur, clipping at the frame edge) is read qualitatively, not trusted.

### The kit's names

| Function | Use |
|---|---|
| `ease(name, u)` | the brand's named ease at progress u, exact at 0 and 1 |
| `tw(t, t0, dur, name)` | a tween of film time on a named ease |
| `dur(token)`, `durFrames` | the brand's duration scale |
| `staggerAt`, `staggered` | capped staggers |
| `landOn`, `startFor`, `t90Of` | landing moves on words |
| `defineMotion({...})` | registers a move for the act's motion trace (what `slate qa motion` checks) |
| `monoSpline`, `chain` | monotone paths and chained moves |

### Telling the motion gate what moves

`slate qa motion` holds each traced move to the speed limits of what it is, so say so when the name doesn't:

- `class`: `rig` (a mark's or character's part: by default 30 px a frame at 1080p), `ui` (an element: 60), `carry` (a page, card
  or camera carried across the frame: 170) or `whip` (a deliberate whip past the carry limits, which a person signs
  off). A rig part is a rig without saying so, and a move whose id or property starts with the camera's name is a
  carry.
- Brand `speed_limits` can replace these class defaults. Current rig symmetry and minimum loop-period checks remain;
  speed configuration does not disable them.
- `exempt`: `reading_sweep` (a highlight that moves at reading pace) or `steady` (a line whose steadiness is the
  meaning), always with its `reason`.
- `exception`: a reason for a deliberate break; its findings become review items a person accepts, never a pass.
- `size` (and `unit`): the element's size in pixels, so a scale or a rotation is speed-checked at its edges.

Linear position, scale and rotation need a recognized time-based use, a supported trace exemption, a whole-shot drift,
or a property listed in the brand's `linear_props`. Naming a linear curve alone does not supply that allowance.

Besides the brand's named eases, the kit knows `even`: rest to rest through a third of the travel at each third of the
time, its peak speed 4/3 of the average. Use it for long carries and camera drifts; a carry may use it without the
brand naming it, and the motion gate knows it by the same name.

---

## Reference: The glitch catalogue: a pre-render checklist

Thirty classes of glitch the first films shipped to a review or caught on the way, each with the rule that prevents it.
Walk the list before every render that matters; the reasons are in [anti-glitch](#reference-anti-glitch-rules).

| # | Glitch | Prevent it by |
|---|---|---|
| 1 | "Has it started?" checks open early, because an ease returned 1e-15 instead of 0 | the kit's exact-endpoint eases; never your own wrapper |
| 2 | One word lookup that throws at module load breaks every composition in a bundle | lookups that never throw; an empty miss list at hand-in |
| 3 | One half-written act breaks the shared bundle | the type-check and module-load parts of the hand-in check before any render |
| 4 | Opacity or a filter on a 3D group flattens it; a translucent card shows its thickness through its face | opacity and blur on leaves; fading cards render as one flat sheet |
| 5 | The browser's 3D sorting races with many parallel planes: a card face drops for two frames | few parallel planes; one explicit stacking order, each layer its own context; moderate render concurrency |
| 6 | Parts placed in 3D inside a tilted group z-fight under the shutter | characters drawn as one flat plane in passes |
| 7 | Surfaces crossing through other planes get sliced | nothing crosses; exits finish before entrances take the space |
| 8 | Pop-ins: a first frame mid-motion inside the frame, a mask eased twice, a shadow or colour switching at a threshold, a label reflowing in one frame | enter from off frame or from 85% scale or zero opacity; blend colour over the tick duration on a snap; continuous morphs |
| 9 | Moves that start at full speed smear one frame and go sharp the next | big moves on the rest-to-rest ease |
| 10 | Fast carries streak under the shutter (a quick carry peaked at 310 px a frame) | a speed audit per move; big moves at the camera or signature duration |
| 11 | Oscillation reads as noise | one clock, explicit phases, swells instead of wobbles, no loops |
| 12 | A spline through uneven keys overshoots and backtracks | the kit's monotone spline |
| 13 | CSS `clip-path: path()` fails silently in headless Chrome; SVG data-URI masks decode after the frame is taken | `polygon()` clips and CSS gradient masks |
| 14 | A clip path on a transformed element rides its transform | clip on untransformed full-frame wrappers |
| 15 | A zero-length dashed line still renders a dot | guard zero-length strokes |
| 16 | Video decoders crash long parallel renders | footage as JPEG sequences played from film time |
| 17 | The headless browser can't see locally installed web-kit fonts | fonts loaded explicitly; the font gate fails the render on substitution |
| 18 | Huge `translateZ` zooms rasterize badly | a 2D camera over poses, zooming in log space |
| 19 | CSS transforms change the raster (shadows by a few levels): "same picture" isn't "same pixels" | rest states drawn untransformed; contract frames pixel-diffed |
| 20 | The GPU renderer isn't bit-exact run to run (about 1 level) | "changed" only when a frame differs from both of two baseline renders |
| 21 | Temporary bundles fill the disk | the engine deletes each bundle after use |
| 22 | Impact marks still fading at a shot's end blink out on the cut | everything settles out over the last 0.6 s before a contract; the boundary check |
| 23 | Per-character type with no spread cap | the kit's capped `PerChar`; never your own |
| 24 | Parallel builders overwrite each other's scratch files | a scratch folder per builder |
| 25 | New data rendered with old code | code and data always move together; one bundle per source hash |
| 26 | A tracker hops between near-equal features, or drifts outside its reliable window | follow features, hold outside the window, a temporal median |
| 27 | Generated pixels on screen read as AI | a generation only as a matte or shape over real frames (slate-generate) |
| 28 | A second count of a value already on screen, two overlapping texts crossfading, a fade up from depth | count once; state changes snap; carries rise from below |
| 29 | Per-part character motion at small sizes reads as noise | the whole mark moves as one below its size threshold |
| 30 | Positioned type in a zero-width container wraps one word per line | `white-space: nowrap` on positioned type |

### Also check

- Text that steps a pixel at a time while shapes glide (slow drifts, the tails of eases): move with transforms, give
  moving layers the kit's raster hints, and keep one raster through a rest (slate-build, remotion-gotchas.md).
- Fine regular patterns that shimmer at the smallest delivery size.
- A UI state cut under the shutter renders as one mixed frame: expected, not a glitch.

### After the render

`slate qa glitch` scans every act for one- and two-frame glitches and skips flags within 3 frames of a planned beat;
triage what's left (slate-qa, triage.md). When one pop is found, scan the whole act frame by frame for others and fix
them together.

---

## Reference: Building a logo, and the sting

A brand's logo arriving is usually a film's first signature moment and its bookend. The kit builds it from the brand's
own SVG and a build spec, so the construction is the brand's own geometry, not a template.

### A logo build that worked

1. **Construction guides and vertex squares** drawn on the mark's own grid (dashed lines from the shapes' edges).
2. **An outline draw** of the mark.
3. **A left-to-right fill**.
4. **A line writing the name**.
5. **A held breath**: the keystone element (an accent dot, a square) hangs over its empty slot.
6. **The keystone drops into place** with a damped jolt of a few pixels (the one allowed impact overshoot), on the word.
7. **Relief rings with echoes and a contact shadow** answer the impact.
8. **Every mark settles** before the next contract frame, so nothing is still fading on the cut.

### The kit

- `LogoBuild` takes the parsed logo (paths, per-glyph boxes from the path bounds, a designated keystone, construction
  guides from the edges, the keystone's colour from the artwork) and a build spec (guides, vertices, order, keystone,
  timing). `settleBy` makes every mark finish before a given time.
- `LogoSting` is the short form for endings and stings; `stingLength()` says how long it runs.
- `logoEvents()` lists the build's beats for the sound: each construction line, the fill, the keystone's landing.
- The logo's SVG and build spec live in the brand pack (slate-brand, logo-and-motif.md).

### Rules

- **Never rotate a mark that has a fixed orientation**, even in a portal zoom.
- **Zero-length dashed strokes still render a dot**: guard them, or the build shows specks before it starts.
- **Bookends reuse the same kit component** as the opening (the same logo build with the closing's timing), never a
  redraw, so they match exactly.
- **When a shot hands from an act's own drawing to the logo build mid-shot**, the component's start state must match the
  drawing exactly (weight, caps, dot size and position); check the switch frame pixel by pixel.
- **The sonic logo mirrors the build**: each construction line clicks in, the fill is a soft swell, the keystone lands on
  one hollow knock with one small note; the ending reverses it and lands on the same knock (slate-sound).

### Checking it

Render the build's key frames as stills at full size: the first guide, the fill's midpoint, the held breath, the
landing frame, and the last frame before the contract. The landing frame should be the sound's contact frame, and the
last frame should be the contract's rest state exactly.

---

## Reference: Look development and composition

The first film looked right only after its look was built from the brand's own design system: four generic looks were
rejected first (flat shapes that didn't look polished, a 3D filament with no hierarchy, glossy futuristic glass, a
generated look that read as AI). What worked was the brand's own components and tokens, staged in space, approved from
a moving test.

These rejected versions are evidence about that film, not bans on flat shapes, glass, generated imagery or another
brand's look. Follow the latest brief and authorized feedback, retaining the earlier look, its feedback and the
revision. A requested exploration is already authorized; approval of its resulting moving reference remains a
separate evidence decision.

### The north star

The design north star is The Browser Company's craft and warmth, channelled inside the brand's own tokens: borrow the
feeling (hand-made, warm, every move with a reason), never their brand (motion-systems.md).

### How a look is developed

1. **Start from the brand's own language**: its website's components and tokens, its app's screens, its guidelines.
   Rebuild components for film at film scale; borrow the look language, don't import website code.
2. **Moodboards, then grounded moodboards.** At least two directions, then the same directions grounded in the brand's
   kit (its real references wired in). Ungrounded moodboards drift to generic grey glass.
3. **A moving look test** of 10 to 15 seconds, with sound, in the kit's review sheets. Stills don't count: motion is
   half of a look.
4. **The owner picks.** Open questions (an opening colour, a ground) get their own side-by-side look tests; the
   coordinator confirms the call.
5. **Roll it out only after approval.** A look shown for the first time across a whole film is a look that gets
   rebuilt.

The kit's looks library is the starting point: `flat` (the default until a brand chooses), `paper-2.5d` (only for
brands whose chosen film language is papery), `editorial` (type-led, for statements, kinetic type and stings), `blueprint`, and
the After Effects bridge's looks by name when a look calls for AE.

### Composition

This is the earlier product-film composition recipe. Adapt its density, focal objects and camera energy to the current
direction; the concrete failed frames explain where a choice did not work, not what every film must avoid.

- **Compose whole designed objects in generous space**: complete cards, rows and charts, with one clear focal object
  and a clear hierarchy per frame. Four camera variants of an earlier thin-line close-up read as empty because the
  line did not carry that idea; deliberate abstraction or sparseness can serve another brief.
- **Stage beats as objects**: one card splitting into two identical cards, the broken one falling away, rather than
  tracking close-ups of a line.
- **Every element has a job.** Cut on-screen words and decorations that don't (an unexplained lone word, a line with no
  cause, a decorative underline).
- **One focal card at a time** in a paper look: the previous card steps back into depth of field, with blur only on the
  ones that leave focus. Cards behind the focal card step back and soften with blur; they never thin out with opacity.
- **Supporting elements never cover the hero's words**; they settle around the hero, touching only its edge.
- **A spare statement shot that reads too quiet** gets a gentle camera move, not more elements.
- **First passes tend to be too flat-on and sparse.** Plan stronger camera pushes, depth and a signature before the
  first review.

### Colour and light

The following material rules describe that flat or paper preset. A selected lit, dimensional or expressive look can
use glows, radial shading and colour changes. Literal product status still uses truthful tokens; a graphic treatment
cannot invent a product state or capability.

- **The accent colour keeps one meaning** for the whole film (the line that matters is always the accent; competing
  lines are ink, never the accent).
- **Literal status colours are the product's tokens.** Interpretive graphics can choose a meaningful colour scale.
- **The paper preset gets depth from a soft cast shadow** following height; another selected look can use light or glow.
- **Flat brand fields stay flat in that preset.** A previous soft light on a flat disc read as an unwanted glow; a
  deliberately lit treatment can use radial light or edge shading.
- **In a paper look, a flat colour field that fills the frame** (a disc grown to fill it, a colour section) gets the
  look's paper grain and a soft paper edge, so it reads as paper rather than a flat screen fill; never a radial light.
- A signature motif keeps one colour through the film and changes form only at designed moments.

### Settling open questions

When a look question is genuinely open (which ground opens the film, how dense a chart should be), don't argue it in
words: build both in the kit's review sheet, side by side, at full size and in motion, and let the owner choose.

---

## Reference: Morphs and shared elements

A shared element persists across a scene change and keeps its identity while the world changes around it. It's how
the eye follows an object while everything else changes. Use it to show the product's real behavior or to connect
truthful product states through editorial film staging; those are different uses of the same continuity.

### Shared elements

- **Use hand-offs the way the product carries objects between views** when demonstrating an app interaction: a mark
  landing as the nav logo, a value and its chart carried from one screen to the next. Match the product's actual view
  transitions when the film claims to show them.
- **A carried object keeps its label**: a caption travels with the value it describes across the boundary.
- **Carry by the product's own structure**: a checklist row can lift out and open into its step with its header as the
  shared element; new steps can enter while old ones leave, or a home card can anchor the act. Choose connections that
  preserve the product's real hierarchy, labels and data.
- **Carries that demonstrate app navigation follow the product's actual order**, such as scrolling to the next section.
  Do not present an invented in-place transform as an app interaction.
- **Editorial carries can connect truthful states through an in-place transform or a shared camera.** Keep the source
  and destination grounded in the product, carry the owning surface and its labels together, and record the editorial
  restaging in NOTES.md. The film's choreography need not be an interaction the app offers.
- **Draw a carried element over its destination for the whole carry**, and let the destination take it over on the
  landing frame. Switching its layer mid-carry makes it slip behind, then jump in front.
- **Hand an object between components only at rest**, or on a morph's first moving frame, with one shared count
  function and one position for each label. A mid-count hand-over made a numeral jump three values and a label jump
  4 px.
- **Never duplicate an object to animate it** (a copy slides away while the original stays): move the one object.

### Morphs

- **A morph's first frame equals its source exactly**, and every property blends through it: no mid-flight flips of
  glyphs, line breaks, weight, border, font or sharpness. A chip that swapped font on its first frame popped.
- **Never crossfade one version of a card into another**: it double-exposes headers, figures and charts for several
  frames. Morph the shared elements so nothing is drawn twice.
- **Route shared elements around each other** (one goes down, then left, passing under another) so nothing travels
  through anything; the destination's own new parts arrive only once the shared parts have all but landed.
- **When many pieces morph into shapes**, their union becomes the destination shape on arrival, and the solid shape takes
  over on that frame. Never fade in a second set at the destination while the first is still moving.
- **When a small card grows into a large one**, its position leads its growth, so it grows out of where it is.
- **A container that grows open** (a chat out of a button) reveals content that sits still in its own layer, clipped
  to the growing paper. Carried inside the growing card, its type re-rasterises at a new sub-pixel phase every frame
  and shimmers.
- **Animate corner radii before a split or merge**: corners that snapped from 28 px to 8 px on a split's first frame
  popped.
- **When segments merge into one shape** (a donut's groups into a ring), draw it as one continuous path once merged, so
  no seams show.
- **A container and its contents share timing.** A card that shortened on a spring while its contents travelled on
  another ease let its edge run ahead and left a chart's baseline on the bare page.
- **Open detail below an anchor without moving the anchor**, so everything attached to it stays put. Open a panel in
  its final place; don't open it centred and then glide it aside.
- **Don't drop a large object into streaming text**; carry it out beside the text so the text stays intact.

### Path morphs: the signature line

- A brand's signature line (one stroke in the accent colour at a fixed weight) can carry a whole film through its forms:
  a progress rule, a data curve, a then-to-now mark, a landscape ridge, the underline under the last line. It never
  changes colour, so the eye can follow it through every scene.
- Its weight changes in exactly one place, the reveal, and there it copies the product (drawing heavy and settling to a
  hairline).
- When the script asks for several connecting lines, draw one thread through a node on each item and on into the
  target: one signature line.
- An object that becomes a line arrives moving along that line's direction, and the line draws out of it as it shrinks
  into the line's start, so dot and line are one object.
- **Build:** shapes with equal vertex counts (resample every target to the same count), the first vertex left-most, no
  reversed winding. Path keys use the rest-to-rest ease for moving shapes and the state ease for committing state;
  draw-ons use a trim reveal on the entrance ease.

### Word and glyph morphs

Set the word as shapes (one group per glyph) and morph them into the target icon's paths on the state ease at the quick
duration, and back. Pair it with the make-room move when a new word pushes the block.

### Counting

- **Count a value once.** Never re-count from zero after it's been shown: shown, reset and counted again reads as a
  glitch. Re-count only when the value really changes, from its old value.
- Count-ups run on the entrance ease over the broad duration, with tabular figures and the product's real range; each
  figure holds at least three frames.

---

## Reference: The motion law

A brand's motion law records the movement chosen for its films: named eases, their jobs, a duration scale, stagger
caps, overshoot and speed policies, and the source of those choices. Onboarding starts it (slate-brand,
look-and-motion.md); the brand's pack stores the data, and MOTION.md explains where every number came from.

The recipes below came from earlier product films. Use them as starting craft guidance. The current brief and newer
authorized feedback govern the creative direction; preserve the earlier law, exact feedback and revision in the
history. A requested redesign is work within that scope, not another request for the same creative approval.
Current technical gates still apply, including checks that do not yet have a configurable creative policy.

### Where it lives

`brand.json` → `motion`:

| Key | What it holds |
|---|---|
| `eases` | each name maps to a cubic-bezier `[x1, y1, x2, y2]`, or `"sine"`, `"linear"` or `{"kind": "spring0"}`, with its `lineage` (where it came from) |
| `durations` | the duration scale, `{token: seconds}` |
| `staggers` | stagger units, in seconds or `{frames, at_fps}` |
| `stagger_cap` | `{seconds, fraction}`: a group's spread at most this many seconds and this fraction of its entrance |
| `exit_factor` | exits as a fraction of their entrance (0.75 is the starter value) |
| `roles` | which named ease does each job: `entrance`, `move`, `state`, `exit`, `relayout` |
| `overshoot` | the allowed overshoot and peak: `allowed` can be true or a list of ease names; `max` sets the amount above 1; an ease can carry its own `peak` |
| `linear_props` | properties allowed to move linearly, beyond time, continuous drifts and constant spins |
| `extra_curves` | kit curves available to more classes: `sway`, `land`, `spring0`, `even` |
| `speed_limits` | class limits replacing the defaults for `rig`, `ui` and `carry`, as fractions of the short side or pixels with their measured `short_side` |
| `loops` | a brand's minimum loop period; the current gate can tighten its floor, not lower it |
| `rigs` | the named rig's permitted phase modes and their lag or step |

The kit reads it through `motionLawFrom()` (the Python mirror is `slate.motion.law_from`), and both are held to the
same shared test vectors. Besides named brand eases, the gate recognizes specific kit curves where they apply:
rig parts can use sway, land and spring0; carries can use even; `extra_curves` extends their use. An unknown name is
recorded instead of crashing the preview, and the hand-in check refuses unresolved motion problems. A brand with no
law gets the kit's neutral law so placeholders render; that stand-in cannot pass as the brand's own motion law.

Name a deliberate linear transform in `linear_props`, or use a supported trace exemption with its reason. Merely
naming a linear ease does not permit every transform. Overshoot is checked by ease and peak; a descriptive
`where` field does not implement a separate object-level allowance.

### A product-film starting point

- The film's motion grammar comes from the product's own grammar (one clock, the camera as the guide, pieces carried
  between beats), so the film feels like the product, only bigger.
- **Keep the product's state-change ease** when fidelity to the app is the goal, so the action feels familiar.
- **Give a calm entrance a longer settle** when film travel is much larger than UI travel. Earlier film moves
  travelled 5 to 20 times as far; a different brief can call for a sharper arrival.
- **Measure camera acceleration**: a quart in-out lurched over earlier 1 to 3 second moves. Rest-to-rest travel
  solved that case; a purposeful fast move still needs a clean render.
- **A website's scroll easing is a different vocabulary** from a film's law; don't reuse web-scroll eases for film moves
  without measuring.
- Measure reference films frame by frame and fit their curves (slate-brand, reference-analysis.md). Good references use
  hand-tuned curves; neither clean measurement on the first films came anywhere near After Effects' default Easy Ease.

### The jobs and their starting shapes

- **entrance**: type, cards, UI arriving, count-ups and draw-ons. The calm starter uses a fast start and a long settle.
- **move**: camera push, pull and truck, and shared-element carries. The starter begins and ends at rest to avoid an
  abrupt change in blur; matching velocity across a handoff is another deliberate choice.
- **relayout**: a new line pushes a block, a list re-sorts, a card steps aside. Earlier make-room moves used 0.4 s or
  less; choose the brand's duration for the actual travel.
- **state**: state changes: a chip flips, a check lands, a toggle, a glyph morph commits, a bar segment lights.
- **exit**: the starter accelerates away and uses `exit_factor: 0.75`; the brand can choose a different factor.
- **settle spring**: a persistent container can change size with a damped settle. Bounce or other follow-through can
  serve an expressive object; name the curve and configure its overshoot rather than treating the calm recipe as a ban.

When the current brief changes the desired movement, update its named motion choices and record why. Do not let an
older preset override a newer creative direction. Preserve the previous law and the comparison in the history.

### Craft choices

- **Intentionality**: one carrier, one idea per beat, and every move tied to the voice's word or to the idea. The
  approved first film's bar was one object carrying each act, with each phrase of the voice doing one legible thing to
  it.
- **Fewer, better moves**: don't pan out to one thing and back when one draw-back can show both.
- **Add motion purposefully.** Stillness, flutter, sustained movement and sharp travel can each serve a film. Inspect
  the rendered result for unintended flicker, aliasing and loss of meaning.
- **Keep physical logic legible.** Overshoot and follow-through need a controlled amplitude and endpoint; an intended
  idle gesture should not look like an accidental wobble.
- **Linear movement** works naturally for time and steady travel. Mechanical starts and stops can also be intentional;
  declare the supported property allowance and inspect their speed and blur.
- **Crossfades** can carry atmosphere or a deliberate transition. Earlier product films kept them to atmosphere,
  audio and generated-shot seam blends of at most 4 frames to avoid doubled type.
- **Hard cuts** can create contrast, land a musical hit or show an instant state change. Carries and motion-masked
  cuts are useful when continuity is the chosen grammar.
- **Graphic reveals and effects** can use scale, light, particles or streamed type when they serve the brief and the
  brand. The earlier restrained preset avoided them; see [motion choices](#reference-motion-choices-and-the-defects-to-watch) for its failure evidence.

### Motion blur

- Rendered, never faked: the renderer averages 16 sub-frame samples across a 180-degree shutter (4 in draft). Don't add
  blur in scene code.
- Generated footage gets no extra motion blur; it's baked in. Blur only the graphics over it.
- Depth of field sits on the 3D camera, with focus pulls keyed to the rest-to-rest ease.

### After Effects values

AE stores an ease as speed and influence. For a segment of duration T moving a distance Δ, the average speed is v = Δ/T:
- the out handle (x1, y1): influence = x1 × 100%, speed = (y1 / x1) × v;
- the in handle (x2, y2): influence = (1 − x2) × 100%, speed = ((1 − y2) / (1 − x2)) × v;
- AE's minimum influence is 0.1%, so a vertical tangent can't be drawn exactly.

Multi-dimensional properties take one ease per dimension, and the build reads every ease back after setting it.
AE's default Easy Ease has 33.3% influence and 0 speed on both sides. Earlier references used different curves, so
applying this preset everywhere lost their character. It can still be a deliberate named choice; the gate checks
the actual samples against the named curve.

### Current technical checks

1. Every traced move uses a permitted named or kit ease, and its samples follow that curve. Duration and stagger
   checks use the brand's selected values; linear transforms still need the applicable allowance.
2. The current motion gate requires scaled entrances to start from at least 85% scale, hero text to move at least
   16 px at a 1080 px short side or unmask, and text arrivals to wait until other carries are below 2 px per frame
   at that size. These thresholds do not currently have brand overrides.
3. Speed and acceleration are checked by class against brand limits or the defaults: rig 30/8, UI 60/16 and carry
   170/45 at a 1080 px short side. A whip past carry limits becomes a REVIEW item.
4. Loops have a minimum period of max(16 frames, fps/1.9), and rig parts are checked for whole-frame-delayed symmetry.
   A brand may require slower loops or narrower rig modes; it cannot lower the current loop floor.
5. Traces must be current and well formed. Render pixels cross-check unexplained fast motion; stability,
   accessibility and read-time gates retain their own evidence requirements.
6. Review representative frames and the full-speed movement with the chosen transition grammar and delivery blur.

A trace's reasoned `exception` turns its violation into REVIEW, not an automatic pass. Acceptance is bound to the
trace's bytes and must follow the existing person-approval rules. Preserve the plan's current entrance, loop and
symmetry requirements; a creative direction is not evidence that a technical check passed.

---

## Reference: Motion systems: the north star and the alternatives

A brand's motion law comes from its own product and its measured references (motion-law.md). These systems are where
to look when a brand has no motion language of its own, when a brand is built on one of them, and for the feeling the
films aim for.

### The north star: The Browser Company's craft

The design north star is The Browser Company's craft and warmth: interfaces with personality, physical and springy
motion that still settles, and animation that feels made by hand, where every move has one reason and lands with its
sound. Take the **feeling**, expressed inside the brand's own tokens. Never take their brand: no copied marks, colours,
type or signature animations.

### Material 3

For brands built on Material, or wanting its feel.

| Duration tokens | ms |
|---|---|
| short 1 to 4 | 50, 100, 150, 200 |
| medium 1 to 4 | 250, 300, 350, 400 |
| long 1 to 4 | 450, 500, 550, 600 |
| extra-long 1 to 4 | 700, 800, 900, 1000 |

| Easing | cubic-bezier |
|---|---|
| standard | (0.2, 0, 0, 1) |
| standard decelerate | (0, 0, 0, 1) |
| standard accelerate | (0.3, 0, 1, 1) |
| emphasized decelerate | (0.05, 0.7, 0.1, 1) |
| emphasized accelerate | (0.3, 0, 0.8, 0.15) |

The emphasized curve is really a path, not one bezier. Material 3 Expressive uses springs (stiffness and damping):
spatial springs damp at 0.9 (default about 700, fast about 1400, slow about 300 stiffness), and effects springs at 1.0,
so effects never overshoot. Its loading indicator adds exactly a quarter turn per morph on one spring, riding a slow
spin, so any cycle can end on the rest shape.

Film travel is longer than UI travel: scale Material's durations up for film-sized moves and soften the settle, and
measure the result against a reference.

### IBM Carbon

Carbon splits motion into **productive** (efficient UI moves) and **expressive** (prominent moments). In a film, that
maps cleanly: **product UI shown inside the film moves productively; the film's own big moments move expressively.**

| Duration | ms | Use |
|---|---|---|
| fast-01 | 70 | micro-interactions |
| fast-02 | 110 | fades |
| moderate-01 | 150 | the default |
| moderate-02 | 240 | expansion, toasts |
| slow-01 | 400 | large expansion |
| slow-02 | 700 | hero moments, dimming |

| Easing | Productive | Expressive |
|---|---|---|
| standard | (0.2, 0, 0.38, 0.9) | (0.4, 0.14, 0.3, 1) |
| entrance | (0, 0, 0.38, 0.9) | (0, 0, 0.3, 1) |
| exit | (0.2, 0, 1, 0.9) | (0.4, 0.14, 1, 1) |

### Apple's Human Interface Guidelines

- Add motion purposefully, supporting the experience without overshadowing it; gratuitous animation can leave people
  feeling disconnected or physically uncomfortable.
- Make motion optional, don't rely on it alone to communicate, and let people cancel it.
- Aim for brevity and precision in feedback motion.
- In visionOS, avoid sustained oscillation (especially around 0.2 Hz) and motion at the edges of the field of view.
- Springs: bounce 0 by default, about 0.3 is noticeable, above about 0.4 feels exaggerated for UI.

### Principles to cite

Disney's twelve principles (from *The Illusion of Life*) and the twelve UX in Motion principles (easing, offset and
delay, parenting, transformation, value change, masking, overlay, cloning, obscuration, parallax, dimensionality, dolly
and zoom). Only easing carries over directly from character animation to interface motion. How each applies:
[principles](#reference-animation-principles-applied-to-film-and-interface-motion).

### Frame heuristics

At 30 fps (scale for the film's own rate): 2 to 4 frames reads as a snap, 4 to 6 as anticipation, 6 to 10 as a settle,
8 to 12 as a quick transition, and 18 to 30 as a slower entrance. Use them to sanity-check a brand's duration scale, not
to replace it.

### Choosing

| The brand | Start from |
|---|---|
| Has product motion tokens (CSS easing variables, SwiftUI springs) | its own tokens, scaled for film (slate-brand) |
| Is built on Material | Material 3, scaled for film |
| Is an enterprise product with no motion language | Carbon: productive for product UI, expressive for moments |
| Is an Apple-platform app | its SwiftUI springs (response and damping) and the HIG's restraint |
| Has nothing at all | the kit's neutral law as a stand-in, then onboarding writes a real one |

Whatever the source, the brand's law still names its eases by job, caps its staggers and bans the same things
(motion-law.md, banned-moves.md).

---

## Reference: Physical books: a carrier with memory

A book gives a sequence somewhere to live. Its cover establishes the object; each turn changes what the viewer can
see while keeping what they have already seen physically behind it. Use that continuity when the idea benefits from
accumulation, comparison or a choice the viewer can carry away.

### Stage the object, then the idea

- **Let a familiar mark become part of the cover.** A seal, token or other established object can resolve into the
  cover's emblem. Match its silhouette, position, scale and material on the hand-over frame. One visible mark travels
  through the hand-over; the cover takes ownership when it lands. The film owns that morph and its meaning.
- **Keep one book through the sequence.** An impression can establish an action, a spread can make a comparison, and a
  later spread can connect the result to its audience. Keep the same cover, hinge, paper dimensions, page order and
  marks. The object gathers evidence as the idea develops.
- **Give each idea a useful view.** An oblique cover view establishes an object; a closer view makes a contact felt; a
  flatter spread makes two sides comparable; a wider view can reveal who the result reaches. Choose the view for what
  it explains. A page change alone does not earn an arbitrary orbit or another push and pull.
- **Separate travel from reading.** Land the camera and the leaf, then let the statement read. A stamp's contact and
  an unfolding comparison can be motion beats; their settled result needs its own hold. Apply
  [read time](#reference-read-time) from the moment both the content and its view are legible.
- **Leave the result on the object.** Ink, a chosen box or a comparison stays registered to its paper through every
  later move. It carries the same claim and label when it returns.

This is a staging pattern. Choose the carrier, emblem, page content and destination for the brief. The shared book
primitive supplies paper mechanics; the film supplies the authored sequence and brand artwork. slate-story's
structure.md explains how the object becomes a payoff.

### Make the paper behave like paper

- The hinge stays on the spine. A leaf is a chain of connected strips; its free edge leads as it bends, and it lies
  exactly flat at either rest.
- The recto and verso belong to one physical leaf. The back face is mirrored locally before the turned leaf mirrors
  it again. Reverse-page artwork must arrive at the same page coordinates as the flat resting artwork, including
  fractional page widths and the small overlap that closes strip seams.
- Lighting follows the strip angles. The board has thickness, its lining clears the closed page stack, and settled
  leaves remain above the surface beneath them.
- A leaf's cast shadow follows its projected footprint. It fades to zero at upright, then grows on the receiving
  page. Keep the fade continuous near the rests and the spine; a visibility threshold can introduce a pop.
- Settled paper draws its content once, as one sharp flat face. Hold that rest rather than leaving an almost-flat
  strip assembly swimming under small type.

The kit's `HingedBook` and `PageLeaf` implement these mechanics. Their geometry lives in the React-free core;
slate-build's hinged-books.md gives the API and coordinate spaces.

### Keep the material and type stable

- Use the brand's page, cover, edge and ink roles. A film-specific grain, deboss, emblem or stamp is caller-owned face
  content, kept in that face's local coordinates.
- Keep opacity, blur and filters off the book's `preserve-3d` ancestors. They flatten the depth stack. Put a treatment
  on the face that needs it, or carry the book out of frame when it leaves.
- In tilt raster mode, put `TiltSpan` directly around type. Keep ruled lines, stamps and page shapes outside the type
  tilt. Shapes and their content share one page position in either raster mode.
- Drive angles from film seconds and the brand's named rest-to-rest ease. The book has no clock, invented timing or
  per-page idle loop. Register the film's turns, camera moves and contact events with the existing motion and event
  helpers.

### Verify the continuity

Render the uninterrupted cover opening and every leaf turn, including a short settled hold on either side. Check:

1. The carried emblem is drawn once and agrees with the cover on its hand-over frame.
2. The spine holds, strips meet, and the free edge bends without a seam or depth inversion.
3. Reverse artwork, fine rules and labels reach their flat positions without sliding at the rest switch.
4. Shadows fade through upright and the rests; no dark patch changes sides at full strength.
5. A comparison reads as a held spread, and each later view still contains the same book and accumulated marks.
6. The camera settles before small text asks to be read; the final statement gets its full read hold.

Check both raster modes when the film supports both, and fractional exposure times at the film's actual rate. The
kit's neutral `Kit-Book` and `Kit-Book-Hint` compositions exercise the mechanism. Their short turn proof supports
geometry review; the film's complete sequence still needs a recording, frame analysis and its own craft review.

---

## Reference: Animation principles, applied to film and interface motion

### The twelve principles

Thomas and Johnston's twelve, from *The Illusion of Life*: squash and stretch, anticipation, staging, straight-ahead and
pose-to-pose, follow-through and overlapping action, slow in and slow out, arcs, secondary action, timing,
exaggeration, solid drawing, appeal. How they apply in a Slate film:

| Principle | Applied |
|---|---|
| **Timing** | Timing gives movement meaning. A turn with two in-betweens reads as a nervous twitch; a stroke of about 10 frames reads as deliberate. |
| **Anticipation** | Short, in one direction, and never longer than the action it prepares: a tuck before a turn, an inhale before a greeting, a lift before a flight. |
| **Slow in, slow out** | Every segment leaves and arrives at rest (or hands its exact velocity on). |
| **Arcs** | Flights travel on arcs, entrances can spiral in, turns carry parts on circles. |
| **Follow-through and overlapping action** | From whole-frame trails (a spread trailing its growth by 2 frames), never from a wobble on every beat. |
| **Secondary action** | Supports the main move and never competes with it. |
| **Staging** | One clear focal object per frame; the camera and composition point at it. |
| **Squash and stretch** | Not on paper-like marks: paper doesn't squash, and parts keep the brand's shape. |
| **Exaggeration** | Rarely. Delight means more from something that never exaggerates. |
| **Appeal** | The feeling of craft: hand-made, every move with a reason. |

### UX in Motion's twelve

Issara Willenskomer's twelve principles for interface motion: easing, offset and delay, parenting, transformation,
value change, masking, overlay, cloning, obscuration, parallax, dimensionality, and dolly and zoom. Motion supports
usability through expectation, continuity, narrative and relationship.

The caution that matters: **only easing carries over directly** from character animation to interface motion. The rest
of the twelve animation principles need translating, not copying.

| UX principle | In a Slate film |
|---|---|
| Offset and delay | whole-frame staggers, capped, in reading or data order |
| Parenting | a container parents its contents; they share its timing |
| Transformation | a shared element changes form without losing identity |
| Value change | a count-up counts once, from its real value |
| Masking | reveals through a shape, never particles |
| Obscuration | depth of field steps back what isn't the focus |
| Parallax | layers at different depths drift at different rates, from one clock |
| Dimensionality | tilt-to-flat and paper depth, one 3D object at a time |
| Dolly and zoom | one camera move per act; bring a card forward rather than pushing in |

### Checking a move against the principles

For any move that matters, step through: its start, its anticipation, its fastest frame, any overshoot, its settle and
its last frame, with motion blur at delivery settings. If any of those frames looks wrong alone, the move is wrong.

### Restraint

Knowing when not to move matters as much as moving. Even audio-first products script their states rather than moving
constantly; a film that holds still before its big moment makes the moment land.

---

## Reference: Read time

Text on screen is only useful if it can be read. The rule is counted from the frame the text has **fully settled** (the
end of its entrance), not from its first frame.

### The rule

- **Hold at least max(1.5 s, 0.4 s + 0.3 s per word).** That's about 200 words a minute, plus time to find the text.
- **Numbers and statistics:** at least 2 s after the count lands.
- **Labels of three words or fewer:** declare `reading.labels: true` with a reason. Each authored label uses the
  default hold `max(1.0 s, 0.4 s + 0.3 s per word)`: a three-word label still needs 1.3 s. Longer labels keep the
  usual floor. The existing format or script `read_time.floor`, `base` and `per_word` policy takes precedence;
  the inherited generic 1.5 s floor alone is not an explicit label override.
- **Lines the voice also says:** declare `reading.voice_matched` with a reason. The first qualifying complete
  readable run must meet the 1.5 s floor and cover the matching phrase's measured final word on the film clock.
  A statement that is also a declared label uses `max(1.5 s, the effective read_time.floor)`; the label's shorter
  default cannot shorten a spoken line. Progressive builds need not show the complete line throughout the phrase.
- **Density:** at most 12 on-screen words per shot; body text at least 28 px at a 1080-line frame; on-screen text about
  40% of what the voice says in the shot, or less. Text smaller than body size is only for labels of three words or
  fewer (meta times, dates, column heads, the sample-data label).
- **Judge type size by its measured cap height at full resolution**, not by the font size in code: 42 px names
  measured 26 px capitals.

A cross-check for supers: a slow reader at about 200 words a minute should be able to read it twice (hold at least
max(1.2 s, words × 0.3 s × 2)). When the two disagree, take the longer hold. Captions have their own rule: at most 17
characters a second, 2 lines of 42 (slate-voice).

### Where it's checked

1. **The script** (`slate script build`): the planned hold, from the shot's length minus its entrance and exit, against
   the rule, per shot (slate-story). Declared labels use the same resolved reading policy; a planned number hold
   does not prove where its rendered count lands.
2. **The rendered film** (`slate qa readtime`): OCR reads the picture every 0.25 s and times each on-screen statement
   from the frame it's fully built (in order, with its last word) to the frame it's gone. This catches what the script
   can't: a camera that leaves early, a statement that builds slowly, text that's too small to read. Declared
   read-along lines also need measured word timing and voice placement; missing evidence is UNCHECKED.

Logo lockups and stylized marks are left to the contact-sheet review: OCR misreads them.

### Declared counts

For a readable animated number, bind its exact final `on_screen` part to the event ids that count it:

```json
{"id": "S04", "on_screen": "72% complete", "reading": {"count_events": [{"text": "72% complete", "events": ["progress-count"]}]}}
```

Each binding has exactly `text` and `events`: one literal final display and a nonempty list of unique event ids.
Preserve its sign, decimal point, currency and percent marks. The metadata grants no reading exemption and needs no
reason by itself; `labels`, `voice_matched` and `not_for_reading` still need their own reason.

The landing comes from the owning act's canonical `timing/visual_events/actN.json`, with each unique `kind: count`
event belonging to that placed shot. Its finite `t`, `start` and positive `dur` are film seconds, not shot-local
estimates; `t` must agree with `start + dur` and stay within its owning act, each within half a film frame.
Its owning shot retains the existing clock tolerance. All named events must resolve before the latest landing is used. Another shot's count, an intermediate value or a similar OCR number cannot supply the proof.

The final display must hold continuously for 2 s from the later of that landing and its first complete, legible
onset. The check uses the first readable run that reaches the landing, within the owning shot, with one OCR sample
of exit uncertainty. A late settle cannot borrow earlier count time, and a later reappearance cannot erase a short
first exposure. The existing opacity and motion limits still apply.

Missing or malformed canonical event, clock or exact picture evidence is UNCHECKED. A malformed binding or one that
names no unique literal display fails; an independently measured short hold still fails even when other evidence is
unknown. A number alone does not declare an animation: ordinary static numbers keep their existing check, and timers
or nonnumeric motion gain no count-reading obligation merely from an event's kind. A valid whole-shot
`not_for_reading: true` declaration excludes the surface from count landing and coverage requirements; malformed or
stray metadata remains a problem. A listed exemption applies only to its exact bound display.

### Fixing a short hold

- **Extend the settled hold inside the shot**: start the next camera move later, or land the text earlier within its
  shot. Don't move word timings or shot boundaries; they're the voice's clock.
- When you retime one move to fix read time, choose its new start and ease so every downstream key position stays
  identical (the camera still reaches the next fold exactly where it did), and nothing after it moves.
- If the hold can't grow, cut words: the density rule is usually what's really broken.
- Run a read-time audit on the first full preview, before the look is locked: moving a line earlier is cheap then and
  expensive after the renders.

### Text that moves

- Don't land a line of type while the layout around it is still moving; the clock starts when everything has settled.
- Small type rushing past a moving camera can't be read and strobes; land detailed content only once the camera has all
  but stopped.
- A statement that rides a camera move across a cut must stay legible across the cut (check the strip of frames either
  side).

---

## Reference: Safe areas, legibility and accessibility

A frame that looks right on the editing screen can lose its text under a platform's buttons, flash too fast for some
viewers, or be unreadable on a phone. These rules keep every frame safe wherever it's shown.

### Title-safe and action-safe

- **Action-safe** is the central 93% of the frame; **title-safe** the central 90% (SMPTE ST 2046-1 and EBU R 95). At a
  1920 × 1080 frame, title-safe is 1728 × 972, 96 px in from each side and 54 px from the top and bottom; scale with the
  film's own size from film.json.
- Keep text and anything that must be read inside title-safe; keep essential action inside action-safe.

### Platform safe zones

Vertical platforms put buttons, captions and profile details over the frame. Each format file carries its platforms'
safe zones (fractions of the frame from each edge), and film.json inherits them.
- Keep text and faces inside the safe zones for every platform the film is going to.
- Burned-in captions sit inside them too, above the lower overlays.
- `slate qa access` checks 9:16 films' text against the platforms' zones by OCR (UNCHECKED without OCR), and the contact
  sheet shows the zones for review.
- A derived film (a new aspect) re-stages its layout for its own safe zones; it never just crops (slate-finish).

### Legibility

- Body text at least 28 px at a 1080-line frame (the kit's type scale does this, as fractions of the short side).
- Text contrast from the brand's colour pairs: at least 4.5:1 for body text and 3:1 for large text. The kit derives
  missing roles with contrast guaranteed, and `slate qa access` checks the brand's pairs.
- Type over footage stays legible with a soft brand-colour grade behind it, never a box.
- Tabular figures on every number that changes, so digits don't jump sideways.
- Close-ups never crop text mid-line.

### Flashes and motion sensitivity

- At most three flashes a second (WCAG 2.3.1, general and red flashes). `slate qa access` checks it.
- A film embedded on a web page and playing longer than 5 seconds needs a way to pause or stop it (WCAG 2.2.2): that's
  the page's job, but say so when delivering a hero loop.
- Avoid sustained oscillation and fast motion at the edges of the frame.

### Captions

At most 2 lines of 42 characters, 17 characters a second, at least 1 s on screen, never overlapping, word for word the
script (slate-voice builds them; `slate qa captions` checks them).

### Checking

Review the contact sheet with the platform zones overlaid, at the smallest size the film will be shown. What's readable
on a laptop at full size can vanish on a phone.

---

## Reference: Staging signature moments

The earlier product-film recipe gave each act one signature moment (slate-story chooses the structure). A useful
landing pattern is stillness before it, one clear contact, an echo after and sound on the same frame. The current brief
can choose another rhythm, sustained energy or several peaks. Glows, flares, particles and bounce are available
creative materials when the selected direction calls for them; their intended use still needs legible, measured motion.

### Anatomy of a landing

A hero moment needs more than a correct animation:
1. **A held breath**: everything still, often an empty slot waiting, the music stopped dead.
2. **The drop**: the key mark lands, on the word, on the brand's own ease.
3. **An impact that echoes**: a ripple through the ground, a ring, hairline echoes, the construction grid flaring once.
4. **A text entrance worthy of it**, landing after the impact, not on top of it.
5. **The camera exhales**: a small release after the hit.

The ending can replay the same component as a bookend (logo-build.md).

### A landing in a paper look

For a papery brand's biggest moment: a held breath with everything still; a press down; on the landing, focus snaps
sharp and the shadow merges; an embossed ripple (a lit crest and a soft trough, no light, no glow) runs through the page
and lifts the line it crosses; a hairline echo ring expands and fades; the page gives by well under 1% and recovers with
no bounce; and the camera exhales. A pressed object can leave a trace where it was pressed (a shallow dish in the page),
so the page remembers the moment.

### Other patterns

- **A signature move can use the signature duration** and follow-through: the leading part first, the rest a beat
  behind, the camera moving with it. A token's explicit `max_per_act` is a gate; an assumed one-per-act quota is not.
- **An impact can be a small, damped camera hit**, with the lines shuddering at the stress point, once per act.
- **Land the impact at the end of a sentence**, so its sound and ripple play in the voice's pause.
- **A world can dissolve into the ground and leave its imprint**: the far distance mists away while the words hold, then
  the ground, leaving a shallow deboss with the signature line on its rim; then the imprint relaxes flat.
- **When a character cites data**, the data travels from its source into the sentence exactly as the voice reaches its
  words, after selection marks wipe around the facts it will cite.
- **To show that something won't be stated**, make it a ghost that never lands: faint and blurred in a dashed slot,
  digits rolling without settling, a thread reaching for a source, finding none and pulling back. The sound gives it no
  landing.
- **For a weighty line**, hold everything still (camera and character) except a slow focus pull that leaves one element
  standing alone.

### Timing it

- Give the moment room: still frames before (the held breath) and a settle after, before anything else moves.
- Everything decorative from the impact settles out before the act's contract frame (at least the last 0.6 s), or it
  blinks out on the cut.
- Each designed sound landing (slate-sound) and its picture contact share the same frame.

### Reviewing it

Review the moment on its own, at full speed and quarter speed, with sound, against the visionary bar: would the owner
say they've never seen that? A correct but ordinary moment is sent back, however clean it is.

---

## Reference: Sources for the motion rules

The motion rules cite their research by label. Read the sources yourself when a rule needs defending or updating;
paraphrase them, and quote only briefly and exactly.

### Principles and systems

- **[Disney 12]** Frank Thomas and Ollie Johnston, *The Illusion of Life* (1981): the twelve basic principles of
  animation. Overview: https://en.wikipedia.org/wiki/Twelve_basic_principles_of_animation
- **[UX in Motion]** Issara Willenskomer, the twelve principles of UX in motion; and his note that only easing carries
  over directly from character animation to interface motion:
  https://blog.adobe.com/en/publish/2016/11/08/redesigning-the-12-principles-of-animation-for-motion-design
- **[M3 tokens]** Material 3 motion tokens (durations, easing, springs), in the material-web source:
  https://github.com/material-components/material-web
- **[M3 loader]** Material 3's loading indicator (quantized turns on one spring), in the androidx source:
  https://github.com/androidx/androidx
- **[Carbon]** IBM Carbon's motion tokens (productive and expressive):
  https://github.com/carbon-design-system/carbon/blob/main/packages/motion/src/dtcg/motion.json
- **[HIG]** Apple's Human Interface Guidelines, Motion:
  https://developer.apple.com/design/human-interface-guidelines/motion
- **[WWDC23]** Apple, "Animate with springs": https://developer.apple.com/videos/play/wwdc2023/10158/
- **[WWDC18]** Apple, "Designing Fluid Interfaces": https://developer.apple.com/videos/play/wwdc2018/803/

### Multi-part marks and loaders

- **[SpinKit]** Tobias Ahlin's SpinKit: the circle spinner's delays in exact steps of cycle over parts.
  https://github.com/tobiasahlin/SpinKit
- **[Replicator]** Core Animation's replicator layer: an instance delay of duration over count.
- **[Follow-the-leader]** After Effects expressions reading each layer's value at time minus index times delay (the
  classic rig, as documented by Dan Ebberts).
- **[Metachronal]** Metachronal rhythm: a fixed lag between neighbours, as in cilia and legs.
- **[Common fate]** Gestalt common fate: parts moving with the same timing read as one object.

### Perception and timing

- **[Flicker]** Temporal contrast sensitivity peaks near 8 Hz, which is why a 4 Hz wobble (blur pulsing at 8 Hz) reads
  as flicker.
- **[Speech envelope]** Speech loudness modulates mostly between 2 and 8 Hz (Ding and colleagues, 2017), which is why a
  character is never driven by the voice's loudness.
- **[Gesture timing]** Ye, McQueen and Bosker (2025), summarizing Leonard and Cummins and Roustan and Dohen: a gesture's
  top speed coincides with the stressed vowel, and its apex falls inside the stressed syllable.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC12331874/
- **[McNeill's rule]** Nirme, Gulz, Haake and Gullberg (2024): a gesture precedes or ends at, but doesn't follow, the
  stressed syllable; gestures moved 500 ms early didn't hurt recall, 500 ms late did.
  https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2024.1345906/full
- **[AV sync]** ITU-R BT.1359 (viewers detect sound from about 45 ms early to 125 ms late) and EBU R37 (+40 / −60 ms).

### Read time, safe areas and accessibility

- **[Read it twice]** The practitioner rule that supers stay up long enough for a slow reader to read them twice.
- **[Subtitles]** Broadcaster and streaming timed-text guides: about 160 to 180 words a minute, and at most 17 to 20
  characters a second.
- **[Safe areas]** SMPTE ST 2046-1 and EBU R 95: action-safe 93%, title-safe 90%. https://tech.ebu.ch/publications/r095
- **[WCAG]** WCAG 2.2: 2.3.1 (three flashes) and 2.2.2 (pause, stop, hide).
  https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide.html

### How good marks move (studied for character design)

Voice-assistant and loader marks were studied for how they move, not copied: a ring that moves outward to respond and
inward to listen; dots rooted in consistent paths and timing; a breathing flower driven by one container animation; an
assistant cursor that pairs every move with a matched sound; tempo carrying meaning (a fast pulse for an error, a slow
one for do-not-disturb); scripted states rather than live loudness; stillness as a design decision. Take the principle,
never the look.

---

## Reference: Techniques

Moves that worked on the films, generalized. Each is a way to show one idea clearly; none is a template to apply
everywhere.

### Clarity moves

- **Tilt-to-flat resolve.** UI enters tilted (about 30 degrees on X, depth of field on) and lands flat and sharp as the
  idea lands. Use it as the beat of clarity.
- **Component zoom, data, pull-back.** Push into one card, let its chip snap and its numbers count, then pull back to
  the whole page or product. A pull-back from one detail to the whole product reveals context.
- **Lift a key value off its surface** as its own object: hand it to a screen-space copy on the same pixels, bring it
  forward with a soft shadow, and quiet the surface behind under a light wash so its statement reads cleanly.
- **Frame brackets** (when the brand has them as an icon) crop into a detail like a viewfinder, then open back out.

### Staging the voice

- **Stage only what the voice names**: three spoken items get three taps, not twelve.
- **Stage the script's spatial words literally** when you can ("underneath" means pages slide out from under).
- **Show an analysis step as the signature line reading the data**, so the pattern has a visible cause. Decoration
  without a cause goes.

### Reveals

- **Reveal a field of elements with a mask morph, not particles**: every element sits on its grid, appears from at
  least 85% scale as the mask clears it, and only elements wholly inside the final shape exist, so nothing is left
  half-faded at rest.
- **The mask morph** itself is a matte that expands on the entrance ease to reveal the next state, with the renderer's
  motion blur on its fastest frames. In After Effects that's a track matte with a wider shutter over those frames (the
  films used 270 degrees over the fastest six).
- **Words can exist before they're seen**: a blind deboss in the ground (shade on the upper edges, a lit lower edge, no
  ink) that inks in letter by letter as the voice says the word.
- **Show the world as many quiet peers**, nearest ring first, with ours the only one in the accent colour; the peers
  carry no names or numbers.

### Stress and contrast

- **Show stress on footage as an atmosphere change** (a shadow front masked to the land, the sky kept clean), never as a
  cover over the image.
- **A stress moment can be a passing band** that re-renders everything inside it in the inverse palette, then leaves,
  returning the scene to normal.
- **Stage an analogy as two parallel objects built alike** (header, number, curve, caption) side by side, joined by the
  signature line across both.

### Paper techniques

In a paper look, materials behave like the real thing:

- **Ink behaves like ink**: broken by the paper's tooth, with uneven pad pressure and a soak after contact.
- **A stamp** comes down out of focus, presses on the snap ease and lands its ink in the grain.
- **A page turn** hinges each leaf at the spine and bends it as strips with graded shading. The leaf casts a shadow on
  the pages beneath that thins as it nears upright and grows again on the other page, instead of jumping across the
  spine.

When the book carries a whole sequence, keep that one object through its cover hand-over, contact, comparison and
audience views. Give each idea a useful framing and a settled read hold. The kit provides `HingedBook`; the staging
and continuity checks are in [physical books](#reference-physical-books-a-carrier-with-memory).

### Per-character type

For hero lines only (6 words or fewer, at most two per act): each character rises a little (about 24 px at a 1080-line
frame), fades in and un-blurs on the entrance ease, staggered by the character unit. Lines go per word, lists per line.
The kit's `PerChar`, `PerWord` and `Arrive` do this with the stagger cap built in.

### Count-ups

Always on the entrance ease over the broad duration, with tabular figures, and only real values in the product's real
range. Never linear. Each figure holds at least three frames so the eye can read the change.

### Product UI in motion

Load product surfaces the way the product loads them: the curve draws, the numeral counts, the marker settles, the
statement lands. Highlight items on their spoken word with the product's own hover or selection state. The rules for
product UI are in slate-build (app-ui.md).

---

## Reference: Transitions

Earlier product films chose a carried-pieces grammar: **carries** (an element continues across), **portals**, **masks**
and **whips** (motion-masked cuts). It is a useful preset, not the universal grammar. The current brief and authorized
feedback can choose hard cuts, crossfades or another transition language. Keep required shared-object handoffs and act
contracts exact; inspect double-exposed type and discontinuous objects as defects rather than banning the technique.

### Carries

- The default: something the viewer is already watching continues into the next shot
  ([morphs and shared elements](#reference-morphs-and-shared-elements)).
- Hand-offs inside one builder's span are carries per the script's transition column, with no pop or cut.
- Move the least possible: a new section rises as an edge over a still page instead of scrolling the whole page, so
  only the edge travels.
- A new section can enter like the next sheet of paper sliding over the last, with its shadow on the page above its
  edge.

### Whips

- Blur whips (defocus or motion-blurred whips that carry the cut) are the only kind of cut the carried-pieces grammar
  allows by default; the cut happens inside the blur, where the eye can't see it.
- Hold the frame still for about half a second before a whip, so the whip reads as deliberate.
- A whip out mirrors the next act's whip in: the same direction and a matching rotation, over the last few frames
  (6 frames on the first films, with a real rotation), blurred by the real sub-sampled render, never an effect blur.
- Unexpected doubled edges or unreadable content under a whip need repair. Inspect the final blur and decide whether
  the intended fast gesture reads; repair its sampling, path or timing without automatically replacing it with a glide.

### Portals and masks

- **A brand mark as a portal** between acts: it scales from lockup size through the frame on the rest-to-rest ease at
  the signature duration, and its window shape becomes the next act. The earlier recipe used it at most three times,
  at act breaks; choose its recurrence for the current structure.
- A portal zoom targets a clean area of the object, so it lands on bare ground.
- **Never rotate a mark with a fixed orientation**, even in a portal zoom.
- **For a paper look, reveal footage by parting the page** along a line: two sheets slide apart, each with an edge and a
  soft shadow underneath. A different requested look may reveal the footage with a crossfade or another device.
- A window growing out of a thin element reads as a white box on the ground; open a section by pulling a sheet away with
  a moving, shadowed edge instead.
- Brand icons such as frame brackets can crop into a detail like a viewfinder, then open back out.

### Rack focus

A depth-of-field rack between focal elements is a lens effect: allowed, and never counted as a crossfade.

### Other useful transitions

| Exception | When |
|---|---|
| Motion-masked cut | inside a whip or a defocus: it counts as a transition |
| Musical hit cuts | a few, on downbeats, only if the brand's law allows them |
| UI state cut | a tab switch in the product with the camera locked, because the product changes state instantly; under sub-frame motion blur it renders as one mixed frame, which is expected, not a glitch |
| Crossfade | atmosphere, a deliberate overlap between shots, or audio; an earlier generated-shot seam needed at most 4 frames, which is a repair example rather than a universal limit |

### Act boundaries

Acts meet on contract frames: a named rest state both sides render exactly, held still for at least 6 frames each side,
with everything decorative settled out over the last 0.6 s before it (slate-build, contracts.md). A transition inside
an act is designed; a transition between acts is a contract.
