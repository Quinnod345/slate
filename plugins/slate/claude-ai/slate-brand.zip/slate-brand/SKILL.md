---
name: "slate-brand"
description: "Onboard a brand into Slate once, before its first film, and keep its brand pack. Covers the four approved references (truth with a named claim authority, look and motion from a moving test, voice, sound), building a pack from the brand's website, a guidelines PDF or its app, measuring a motion law from reference films and the product's own motion tokens, fonts and type by reference with their licences, logos and a motif mark, and the pack's data (palette, type, motion, voice, sound, truth, grounding). Use when a film names a brand that has no approved Slate pack, when a brand's pack needs building, fixing or re-approving, or when someone asks why a brand needs onboarding."
---

> Knowledge-only edition of Slate's `slate-brand` skill, for Claude chats (do not edit by hand: slate skills build). A chat can't run the Slate command line: use this to plan, write and review, and hand any `slate` command to the person to run, or to Slate's desktop extension if it's installed.

# slate-brand

Every brand gets its own look, its own motion, its own voice and its own sound, and Slate learns them once, before the
brand's first script. That's why onboarding exists: the first film looked right only after its look was rebuilt from
the brand's own design system (after four generic looks were rejected), with a motion law measured from reference films
and the product's own motion tokens. Every brand gets the same treatment.

A brand is data: `brand.json` plus its assets, in a brand pack. The core ships a neutral `demo` pack and a `_template`;
real brands live in a separate brand store on the owner's machine, and company packs never enter Slate's repository.

## When to onboard

The front door (the slate skill) sends a film here when `slate brand validate <brand>` finds no pack, or a pack whose
four references aren't all approved. No script is written for a brand until its truth reference exists, and autonomous
films refuse any brand without all four references approved. The neutral `demo` pack is the exception: it exists for
trials, tests and demos.

## The four references

| Reference | What it is | Approved when |
|---|---|---|
| **Truth** | the brand's sources of truth, a named claim authority (who rules on claims for this brand), an approved-claims list, what it never claims, its banned words and its sample data | the claim authority approves the claims list |
| **Look and motion** | kit components rebuilt from the brand's design language, a brand MOTION.md and motion law, a kit review sheet, and a **moving** 10 to 15 second look-and-motion test with sound | the owner approves the moving test (stills don't count), after at least two moodboard directions grounded in the brand's kit |
| **Voice** | an approved take of the brand's voice, with its model, settings and seed | the owner approves it by ear |
| **Sound** | a 10 to 20 second sound reference proof, with its levels measured against the voice | the owner approves it by ear |

Each approval is recorded in `brand.json`: who approved it, when, and the SHA-256 of the reference. Later films are
checked against these references. For a brand the owner doesn't own, the claim authority (and often the approver for
brand use) is a named person at that company.

## The steps

```
slate brand init <brand>          # a new pack from the template
slate brand onboard <brand>       # the onboarding checklist: what exists, what's missing, what's next
slate analyze <reference-film>    # transcript, scenes, OCR and measured eases from each reference film
slate brand validate <brand>      # the pack against its schema, and which references are approved
slate brand approve --help        # records one reference's approval: who, when, and its SHA-256
```

1. **Research**: sources, claims and the brand system, every claim cited (see [onboarding](#reference-onboarding-a-brand)).
2. **Truth**: the truth reference (see [truth pack](#reference-the-truth-reference)).
3. **Look and motion**: the brand's own components, reference films measured, the product's motion values, moodboards
   grounded in the brand's kit, then the moving test (see [look and motion](#reference-look-and-motion-the-brands-own) and
   [reference analysis](#reference-analysing-reference-films)).
4. **Voice**: cast or design, directed and approved by ear (slate-voice; see [voice reference](#reference-the-voice-reference)).
5. **Sound**: the brand's own palette from its world, and a short proof with levels against the voice (slate-sound; see
   [sound reference](#reference-the-sound-reference)).
6. **Fonts, type, logos, motif** (see [fonts](#reference-fonts), [type](#reference-type-in-the-brands-films),
   [logo and motif](#reference-logos-and-motifs)).
7. **Approve each reference** with the owner (or the brand's approver), and validate the pack.

## Building a pack from what the brand has

- **A website**: its CSS tokens, components, type and imagery, read with fetch tools (pages that need a browser go
  through Aside).
- **A guidelines PDF**: colours, type, logo rules, voice, dos and don'ts.
- **An app**: its screens, its code (read in place, never copied), and its own motion values (CSS easing tokens, or
  SwiftUI spring response and damping).
- **Nothing at all**: a brand-kit tool can propose a palette, marks, type and a brandbook for the owner to approve first.

See [pack sources](#reference-building-a-pack-from-what-the-brand-has). The pack's keys, and what each module reads from them:
[pack](#reference-the-brand-pack).

## Rules

- Company source code is read in place, never copied into Slate, a prompt or a pack.
- Brand material goes to a generator only when the brand's owner allows it (`grounding.uploads_allowed`).
- Fonts by reference only (installed name, kit URL or Google Fonts), with the licence noted; never font files in a
  repository.
- Company brand packs stay on the owner's personal machine, in the brand store, never pushed.
- A brand's approved references change only on purpose, with a new approval; notes on them are perfecting notes.

## References

- [onboarding](#reference-onboarding-a-brand): the whole onboarding, the research document, bootstrapping a pack.
- [truth-pack](#reference-the-truth-reference): the truth reference, the claim authority, approved claims.
- [look-and-motion](#reference-look-and-motion-the-brands-own): look development and the brand's motion law.
- [reference-analysis](#reference-analysing-reference-films): analysing reference films and measuring their motion.
- [voice-reference](#reference-the-voice-reference): the brand's voice and its profile.
- [sound-reference](#reference-the-sound-reference): the brand's palette and its sound proof.
- [fonts](#reference-fonts): sourcing and licensing fonts, the font gate.
- [type](#reference-type-in-the-brands-films): the brand's type roles and hierarchy in film.
- [logo-and-motif](#reference-logos-and-motifs): logos, build specs and motif marks.
- [pack-sources](#reference-building-a-pack-from-what-the-brand-has): building from a website, a guidelines PDF or an app.
- [pack](#reference-the-brand-pack): brand.json key by key, and where packs live.

---

## Reference: Fonts

Brand fonts are licensed per brand. Slate never ships or commits a font file; the pack references each face, and the
renderer loads it explicitly, failing loudly when it can't.

### Declaring them

`brand.json` → `type.families`: each role's family, weights and styles, its **source**, and its **licence**:
- `installed`: a face installed on the machine (by its name);
- `google`: a Google Fonts family (loaded through Remotion's font loader);
- a font-kit URL: the brand's web font kit;
- a file URL, only for faces the brand licenses for this use.

For After Effects, each role also names its PostScript name, because AE sets fonts by that name.

### The traps

- **Headless Chrome can't see fonts installed locally from a web font kit.** Load every face explicitly; don't rely on
  what the machine has.
- **A brand's web font kit may serve only its allowed domains**, and loads online during renders; in After Effects the
  same fonts must be activated or installed separately.
- **Never fetch a brand's licensed fonts from its web kit into a third-party sandbox** (a cloud renderer, a generator):
  the licence covers specific uses.
- A missing weight silently falls back to another face in most tools. Slate's font gate fails the render instead.

### The font gate

The kit builds a font plan from the pack and checks each face in the renderer before any frame is drawn; a missing or
substituted face fails the render (and the hand-in check's fonts gate) with the face named. `slate doctor` checks the
fonts After Effects needs.

### When a brand's fonts can't be used

Say so, and pick a licensed stand-in with the owner (an open font close to the brand's), recorded in the pack as a
stand-in with its reason. Never quietly substitute.

---

## Reference: Logos and motifs

### Logos

- **SVG only**, from the brand's own artwork (a vector from the brand, or a careful trace of its official raster, checked
  for overlap with the original).
- `brand.json` → `logos`: each logo by name, with its SVG path and a **build spec** for the kit's logo build: the
  construction guides, the vertices, the order, the **keystone** (the element that lands last, such as an accent dot or
  square), and the timing.
- The kit parses the SVG (absolute paths, exact bounds, per-glyph boxes from the path bounds) and builds from it; the
  keystone's colour comes from the artwork.
- **Never rotate a mark that has a fixed orientation**, even in a portal zoom.
- A logo you don't hold as a licensed asset (a partner's, a publisher's) is set as the name in type, never drawn.

### Motif marks

Some brands have a motif: a mark made of parts (a rosette, a set of dots, a ring) that can move as a character. The pack
describes it as data for the kit's motif rig:
- `motif`: the parts (shape, count, size), where they sit (a ring's radius), their rest rotations, the groups (the
  brand's paint order becomes two fixed sheets), the mark's ratio inside its disc, the colour, the size thresholds for
  per-part motion;
- `motif.gestures`: the brand's gesture vocabulary, each meaning mapped to the rig's gesture kinds (the kit has
  defaults).

A motif keeps one colour through a film and changes form only at designed moments. Its motion follows the mark-as-
character method (slate-motion, character-and-motif-motion.md): computed from this artwork and the film's words.

### Checking

Render the logo build and any motif gestures in the kit's review sheet at the smallest and largest sizes they'll appear,
and compare the rest frames with the brand's own artwork pixel by pixel.

---

## Reference: Look and motion: the brand's own

### Why it's done this way

The first film looked right only after its look was built from the brand's own design system. Generic looks were
rejected four times: flat shapes that didn't look polished, a 3D filament with no hierarchy, glossy futuristic glass,
and generated imagery that read as AI. What worked was the brand's own components and tokens, staged in space, with a
motion law measured from reference films and the product's own motion tokens, approved from a short moving test.

### Inputs

- **The brand's own components**: website code, app screens or SwiftUI views, guidelines.
- **Two or three reference films**, analysed with `slate analyze` and their clean moves fitted to curves
  (reference-analysis.md).
- **The product's own motion values**: its CSS easing tokens, or its SwiftUI spring response and damping.

### Outputs

- **Kit components rebuilt from the brand's design language**, at film scale: borrow the look language, don't import
  the website's code.
- **A brand MOTION.md and its motion law** in the pack (`motion`): named eases with bezier values and where each came
  from, the duration scale, staggers and caps, the exit factor, the roles, the overshoot policy, the brand motif's
  signature motion, the read-time rule, a banned list with reasoned exceptions, and a per-shot motion check.
- **A kit review sheet** in the brand's tokens.

### The motion law, anchored in the product

- **Anchor the film's motion grammar in the product's own grammar** (one clock, the camera as a guide, pieces carried
  between beats), so the film feels like the product, only bigger.
- **Keep the state-change ease identical to the product's**, so a state change feels the same in the app and the film.
- **Film entrances decelerate harder than the product's UI entrance curve**: film travel is 5 to 20 times UI travel and
  needs a longer settle to read as calm.
- **Soften an in-out for camera moves**: a quart in-out lurches over 1 to 3 second moves; good reference camera moves
  start and end at rest.
- **A website's scroll easing is a different vocabulary**; don't reuse web-scroll eases for film moves without
  measuring.
- **Derive a motif's lags from the product's own loader timing** (a loader running one group 8% of a cycle behind became
  a 4-frame lag on a 48-frame breath).
- **A signature motif keeps one colour** through a film and changes form only at designed moments.

The structure of a motion law, and the kit's neutral stand-in: slate-motion, motion-law.md.

### The gate: moodboards, then a moving test

1. **Moodboards first**, then the same moodboards grounded in the brand's kit (its real references wired in). At least
   two directions. Ungrounded moodboards drift to generic.
2. **A moving 10 to 15 second look-and-motion test, with sound**, built in the kit (or in After Effects, if that's the
   brand's engine). Stills don't count.
3. **The owner picks** from the moving test. Open questions (an opening colour, a ground) get their own side-by-side look
   tests.
4. **Record the approval** of the test file with its SHA-256; it becomes the brand's look-and-motion reference.

### Choosing the engine

The look is built in whichever engine suits the brand: the Remotion kit (the default), the open web renderer, or After
Effects with the AE bridge's looks. The engine can be chosen per brand, and later per act.

---

## Reference: Onboarding a brand

Onboarding happens once per brand, before its first script, and produces four approved references. It usually takes a
few sittings of the owner's (or the brand's approver's) time; the rest is research and building.

### 1. Research

Write one research document for the brand, cited throughout:
- **a source table**: every source with a short code, where it lives and its date (the website's pages, the live
  product, the product's code at a pinned commit, the guidelines, prior films, the brand's own people). Sources read in
  place are marked "not copied";
- **every claim with its source code** (and a URL, a file path, or a commit and line behind the code);
- **the brand's story**: what it does, who it's for, its method or standard, its value propositions, its proof points;
- **the brand system**: logos, fonts, colour tokens by source, UI patterns, icons, voice and naming, motion tokens;
- **originals worth having**: vector logos, project files, earlier recordings, preferred over anything traced from a
  video;
- **conflicts and open questions**: where sources disagree (the guidelines against the shipped product, say) and what
  needs a ruling.

Read the web with fetch and search tools; a page that needs a browser goes through Aside. Company code is read in place.

### 2. Truth

The claim authority, the sources of truth, the approved claims, what the brand never claims, its banned words and its
sample data (truth-pack.md).

### 3. Look and motion

The brand's own components rebuilt for film, reference films analysed, the product's own motion values measured,
moodboards grounded in the brand's kit, and a moving test (look-and-motion.md, reference-analysis.md).

### 4. Voice

Cast or design the brand's voice, direct it, and get one take approved by ear, with its model, settings and seed
(voice-reference.md; slate-voice does the work).

### 5. Sound

The brand's own palette (from its world, starting from the owner's starting palette) and a 10 to 20 second proof with
levels measured against the voice (sound-reference.md; slate-sound does the work).

### 6. The rest of the pack

Fonts and type roles (fonts.md, type.md), logos with build specs and any motif (logo-and-motif.md), grounding kits and
whether uploads are allowed, and the pack's data (pack.md).

### 7. Approvals

Each reference is approved by the right person and recorded with its SHA-256 (`slate brand approve --help`). Then
`slate brand validate <brand>` shows all four approved, and the brand is ready for films, including autonomous ones.

### Bootstrapping a brand with no design system

A brand with no design system can bootstrap its pack with a brand-kit tool (a palette, SVG marks, type, a brandbook).
The owner approves the proposal before anything is built from it; after that it's the brand's system like any other.

### A light onboarding

When a first film is due soon, onboarding can be light: a truth reference with the few claims the film needs, a look
test built from what the brand has, a voice take and a short sound proof, each still approved. The film can't use
anything the light onboarding didn't approve, and onboarding is finished before the brand's next film.

### Budget

Onboarding has its own default budget (about 5,000 ElevenLabs credits for voice design, and $15 to $20 of generation for
look tests); the sound reference is made locally.

---

## Reference: Building a pack from what the brand has

Most brands arrive with one of three things: a website, a guidelines document, or an app. Each gives different parts of
the pack; most brands give some of each.

### From a website

- **Read it with fetch and search tools**; save the pages you rely on with their retrieval dates. A page that only
  renders in a browser goes through Aside, never another browser.
- **Tokens**: the site's CSS custom properties and stylesheets give colour tokens, radii, shadows, spacing and type
  (families, weights, sizes). Record each token with its source file.
- **Components**: cards, buttons, chips, charts, section styles. These become the kit's components, rebuilt at film scale
  (never imported code).
- **Motion**: the site's easing tokens and transitions (a scroll easing set is a different vocabulary from a film's law:
  measure before reusing).
- **Imagery and voice**: photography style, illustration, copy tone.
- **Claims**: what the site says, with dates, for the truth reference.

### From a guidelines PDF

- Read it in place; cite pages.
- **Colours** (with their official values), **type** (families, weights, hierarchy), **logo** rules (clear space,
  minimum size, colourways, what never to do), **voice** (tone, words to avoid), imagery.
- Guidelines and the shipped product sometimes disagree (type weights, a colour's value): the film follows the product,
  and the conflict goes in the research document for a ruling.

### From an app

- **Screens**: every screen the films may show, captured on a demo account (`slate capture ios` or `slate capture web`)
  or studied from the code.
- **Code, read in place** at a pinned commit, cited `path:line`: the exact copy, the states, the real distributions and
  ranges behind any data it shows. Never copied anywhere.
- **Motion values**: CSS easing tokens, or SwiftUI spring response and damping; the product's own loaders and
  transitions (a motif's timing often comes from its loader).
- **Its character or agent**, if it has one: a capability brief of what it really does (slate-story, truth.md).

### From nothing

A brand with no design system can bootstrap one: a brand-kit tool proposes a palette, marks, type and a brandbook; the
owner approves it; then it's the brand's system. Generation for brand assets follows slate-generate's rules (grounded,
judged, never ugly).

### Grounding kits

If the brand's material is allowed to go to generators (`grounding.uploads_allowed`), set up its grounding kits (an
ElevenLabs brand kit, a Higgsfield brand kit) with its logos, palettes, type rules, dos and don'ts, and reference frames,
and record their ids in the pack (`grounding`). Every generation for the brand wires them in (slate-generate,
grounding.md).

---

## Reference: The brand pack

A brand pack is a folder: `brand.json` plus assets (logo SVGs, the approved reference files, a MOTION.md). It's data:
Slate's code knows no brand, and everything brand-specific lives here.

### Where packs live

- Slate's repository ships only `brands/_template` and the neutral `brands/demo`.
- Real brands live in a separate brand store on the owner's machine (never pushed). Company packs stay on the owner's
  personal machine only, because they're company material; a pack the owner owns outright can live in a private
  repository.
- `slate brand init <name>` makes a new pack from the template; `slate brand validate <name>` checks it.

### brand.json, key by key

| Key | What it holds | Read by |
|---|---|---|
| `name` | the pack's name | everything |
| `palette` | tokens (nested or flat); `roles` naming page, surface, ink, accent, inverse by token; `tones` for ok, warn, risk | the kit, the contrast check, generation grounding |
| `type` | `families` with role, family, weights, `source`, `licence` and a PostScript name per role; an optional `scale` | the kit's font plan and gate, After Effects |
| `logos` | each logo's SVG path and its `build` spec (guides, vertices, order, keystone, timing) | the kit's logo build, After Effects |
| `motif` | the motif mark's parts, groups, sizes, curves, ratio, and `gestures` | the kit's motif rig |
| `look` | the look's id (from the looks library, or an AE look) and overrides | the kit, After Effects |
| `motion` | `eases` (with lineage), `durations`, `staggers`, `stagger_cap`, `exit_factor`, `roles`, `overshoot` | the kit, the motion gate, the script's read-time gate, After Effects |
| `voice` | the voice profile: provider, source, voice id, model, settings, seed, lexicon, tag policy, clone fields, pace, clean | the voice stages |
| `sound` | `palette`, `materials`, `banned_timbres`, `key`, `tempo`, `instrumentation`, `motif`, `reference_levels` | the score, the mix, the sound gates |
| `truth` | `claim_authority`, `sources`, `approved_claims` (id, text, numbers), `banned_words`, `never_claim`, `sample_data` | the script gates, the claims and banned-word gates |
| `grounding` | brand-kit ids for ElevenLabs and Higgsfield; `uploads_allowed` (default false) | generation |
| `references` | `truth`, `look_motion`, `voice`, `sound`: each `{file, sha256, approved_by, approved_at}` or null | the modes (autonomous needs all four), the gates, `slate status` |

Every reader is forgiving and says what it had to assume (the kit's problems list, `slate brand validate`), so a young
pack still renders a placeholder; nothing brand-specific is ever guessed silently.

### Approvals

`references` records each approval: who approved it, when, and the SHA-256 of the reference file. A changed file is no
longer approved. Autonomous films refuse a brand until all four are approved; supervised films carry a look test in
their pre-production sitting while the look isn't approved.

### What never goes in a pack in Slate's repository

A real brand's colours, names, copy, voice ids, logos, fonts, sample data or banned words. Those are exactly what the
brand store is for.

---

## Reference: Analysing reference films

Reference films teach a brand's motion before anyone animates anything: what good looks like for this brand, measured
rather than guessed.

### Running it

```
slate analyze <reference-film>
```

- extracts the audio and splits voice from music (Demucs) when they're mixed;
- transcribes the voice with word timestamps;
- breaks the film into scenes and grabs a frame at each change and a settled frame;
- reads on-screen text by OCR;
- measures eases: clean moves fitted to cubic-bezier curves, frame by frame, with their fit error and the nearest
  standard curve.

### Method

- **Record a method table** (each step, what ran, what came out) so every result can be re-derived.
- **Study the best moments at full frame rate** (or dense samples), as moment sheets: what happens, when, and what to take
  and leave for this brand.
- **Fit only clean moves.** A move blurred, clipped at the frame's edge or contaminated by other motion is read
  qualitatively ("a long deceleration"), not fitted.
- **Take the voice's text from the transcript**, with a second model agreeing on disputed lines. A generation vendor's
  scene analysis is fine for segmentation and visual notes, but its per-scene audio field once paraphrased the on-screen
  text instead of the voice.

### What a review of a reference records

- **What to keep and what to fix.** Common faults in references: deck-like pacing, on-screen text repeating the voice,
  hard cuts, tiny body copy, a master far under its loudness target (one was 16 LU low), and no call to action.
- **Claims that conflict** with the brand's current website or product, in a table, for the claim authority.
- **The measured curves**, and what they prove: good references use hand-tuned curves, nowhere near a template's
  default ease.

### Feeding the motion law

The fitted curves, the product's own motion tokens and the brand's taste become the brand's named eases, each with its
lineage (which reference move or product token it came from). Keep the fits in a measured-eases file with their errors,
so the law's numbers can always be traced back to what was measured.

---

## Reference: The sound reference

The brand's sound is the fourth reference: its own palette, and a short proof that shows it, with its levels measured
against the brand's voice.

### The palette

Every brand starts from the owner's starting palette (pads, small soft felt notes, hollow wood clicks and clacks, air, a
sub for the one big landing; no chimes; designed, not stock) and gets its own from its world (slate-sound, palette.md):
- **key and tempo range**: pitched effects sit on the key's pentatonic, so they never clash with the score;
- **materials**: what the effects are made of (the score never plays them);
- **banned timbres**: what the brand never sounds like;
- **the motif**: a few notes that belong to the brand or its character, and the instrument that plays them;
- **instrumentation** for the brand's scores;
- **levels**: where each stem sits against the voice.

In `brand.json` → `sound`: `palette` (overriding the starting palette key by key), `materials`, `banned_timbres`, `key`,
`tempo`, `instrumentation`, `motif`, `reference_levels`.

### The proof

A 10 to 20 second piece of film (often the look test's own picture) with the brand's voice, its sound design and, if the
brand will use one, a short score passage, mixed to the film's targets.
- **Levels measured against the voice**: each stem's loudness relative to the voice, recorded as the brand's reference
  levels. Later films are checked against them (`sound.reference`, `sound.levels`).
- **Made locally**: the proof's effects use Apple's sampled instruments installed on the machine, never redistributed.
- **Approved by ear**, and recorded with its SHA-256 as the brand's sound reference.

### Rules

- Taste stays the owner's: the voice first, sound locked to the picture, one sound per kind of interaction, restraint
  and silence.
- Changing the palette after approval is a perfecting change, measured against the approved proof.

---

## Reference: The truth reference

The brand's truth is the first of its four references, and nothing is scripted before it exists. Every film's own truth
pack (slate-story) builds on it.

### What it holds

| Part | What it is |
|---|---|
| **Claim authority** | the named person who rules on claims for this brand (and often on brand use). For a brand the owner doesn't own, someone at that company. |
| **Sources of truth** | where facts come from, in order of authority, each pinned (a commit, a date, a hash) |
| **Approved claims** | the claims the authority has approved, each with its id, text and any numbers it contains |
| **Never claim** | phrases and claims the brand never makes, even when true in the code |
| **Banned words** | one list, used by every check (script, act files, captions, OCR of the picture, the transcript of the mix) |
| **Sample data** | the invented sample company, people and numbers films use, always labelled as sample data |

### Who decides what's true

- **The owner names the source of truth for product claims.** Retired prototypes, old demos and earlier films are layout
  references only.
- **The product's code is the only product truth**, read in place at a pinned commit; it wins over docs, demos and old
  films.
- **The claim authority's rulings win over the code for what's claimed.** A feature can exist in code and still be
  ruled out.

### Fidelity passes

Before a wide fidelity pass (making everything match the product), propose its scope and ask whether it's the pressing
stuff; record the ruling. The product's core surfaces must match exactly; secondary surfaces only need to feel right
unless something is plainly wrong.

### Autonomous films

Autonomous films use approved claims only. A sourced claim that isn't on the approved list parks the film with a
question for the owner; it isn't used until approved. So the approved-claims list is worth making generous and precise at
onboarding.

### Keeping it current

When the product changes, re-pin its source and re-check the claims that depend on it. When the authority rules on a new
claim, add it (with its id) and record the ruling. The truth reference is re-approved when its claims change.

---

## Reference: Type in the brand's films

### Roles

The pack names type roles (hero, headline, body, label, numeral, mono…) and maps each to a family and weight. The kit's
type scale sets sizes as fractions of the frame's short side, so type holds across aspects; a brand can override a role's
size.

### Rules

- **When the guidelines and the shipped product disagree on type weights, the film follows the product.** A weight the
  guidelines list but the product never ships stays out.
- **Keep the product's hierarchy**: an eyebrow in the product stays an eyebrow in the film, not a big heading.
- **Tabular figures** on every number that changes, as good products do.
- **Body text at least 28 px at a 1080-line frame**; hero lines are short (six words or fewer) and at most two per act
  write on per character.
- **Film type and product copy are separate layers**: the script's line is set in film type beside the product's own
  copy, never rewritten into it.

### Legibility

Text contrast comes from the brand's colour pairs: at least 4.5:1 for body text and 3:1 for large text. The kit derives
missing roles with contrast guaranteed; `slate qa access` checks the pack's pairs. Over footage, a soft brand-colour grade
behind the type, never a box.

---

## Reference: The voice reference

The brand's voice is the third reference: one approved take, with its model, settings and seed, and a voice profile in
the pack that every film starts from.

### Making it

1. **Cast or design** (slate-voice): a shootout of library voices, or a designed voice from a brief grounded in the
   brand's own words.
2. **Direct it** with the full-voice rule (never whisper, soft, quiet or gentle tags) and a small tag vocabulary that
   fits the voice's character.
3. **Clean it** the way the owner picks by ear, and record the chain.
4. **Approve one take** by ear, the one that sounds like the brand, and record it with its SHA-256.

### The profile in the pack

`brand.json` → `voice` (the voice profile schema):
- `provider`, `source` (library, designed, clone or recording), `voice_id`, `voice_name`, `model`;
- `settings` (stability and similarity to start), `seed`, `output_format`, `language`;
- `lexicon`: the brand's own words, which every take must say in full;
- `tag_policy`: extra banned words for this brand, the allowed vocabulary, a cap on tags per line;
- for a clone: `clone_of` (`owner` for the owner's own voice), `clone_kind` (professional), `verified_by_owner`;
- for recordings: `speaker`;
- `pace` and `clean` defaults for this voice.

A film pins what it uses at first use, so the brand's profile can evolve without changing films in progress.

### Rules

- Designed or library voices by default; the owner's own verified professional clone is allowed; anyone else's voice
  only as a real recording, never a clone, never a public figure's (slate-voice, voice-policy.md).
- A voice brief that quotes the company's internal material stays with the company's material.
- Designed voice ids belong to the vendor account that made them.
- Never ship the brand's character voice as a demo outside its films.
